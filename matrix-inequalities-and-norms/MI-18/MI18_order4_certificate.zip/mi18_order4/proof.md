# An exact certificate for the order-four q-permanent monotonicity conjecture

**Working research note — 16 September 2026**

## Scope and status

This note and the accompanying rational certificate give a computer-assisted proof of the entire order-four case of MI-18. They do not settle arbitrary matrix order. The certificate has been checked using exact rational arithmetic, including a separate standard-library-only verifier. No independent human review, novelty certification, or Lean formalization is claimed.

The literature checked includes Mitchell [2], which records the order-three result, proves the rank-one case in arbitrary order, and gives the reduction through singular matrices. A search of the repository and relevant literature did not locate a previous general order-four proof; that is not an exhaustive novelty determination.

## 1. Statement

For a square matrix \(A=(a_{ij})\), define
\[
 P_q(A)=\sum_{\sigma\in S_n}q^{\ell(\sigma)}m_\sigma(A),\qquad
 m_\sigma(A)=\prod_{i=1}^n a_{i,\sigma(i)},
\]
where \(\ell(\sigma)\) is the inversion number in the displayed ordering.

**Theorem.** If \(A\in\mathbb C^{4\times4}\) is Hermitian positive semidefinite, then
\[
 P'_q(A)\ge0\qquad(-1\le q\le1).
\]
If, in addition, every diagonal entry is positive and \(A\) is not diagonal, then \(q\mapsto P_q(A)\) is strictly increasing on \([-1,1]\).

No permutation of the matrix indices, real-entry restriction, or normalization of the diagonal is assumed.

## 2. Bernstein reduction

Write \(\beta_k(t)=\binom5k t^k(1-t)^{5-k}\), \(0\le k\le5\). On an interval \([a,b]\), put \(q=a+(b-a)t\). For \(1\le\ell\le6\), define
\[
 h_k^{[a,b]}(\ell)=
 \ell\sum_{r=0}^{\min(k,\ell-1)}
 \binom{\ell-1}{r}a^{\ell-1-r}(b-a)^r
 \frac{\binom{k}{r}}{\binom5r},
 \qquad h_k^{[a,b]}(0)=0.
\]
Then the exact polynomial identity
\[
 \ell q^{\ell-1}=\sum_{k=0}^5\beta_k(t)h_k^{[a,b]}(\ell)
\]
holds, with the zero polynomial on the left when \(\ell=0\). Consequently
\[
 P'_q(A)=\sum_{k=0}^5\beta_k(t)F_k^{[a,b]}(A),\quad
 F_k^{[a,b]}(A)=\sum_{\sigma\in S_4}
 h_k^{[a,b]}(\ell(\sigma))m_\sigma(A).
\]
It is enough to prove the six coefficient functions nonnegative. This checks a continuum of parameter values, not a finite sample of values of \(q\).

We use three intervals: \([-1,-3/4]\), \([-3/4,3/4]\), and \([3/4,1]\).

## 3. Contraction-square certificates

Let \(A\) be the Gram matrix of vectors \(v_1,v_2,v_3,v_4\) in a complex Hilbert space, with inner product conjugate-linear in the first argument. For \(i\ne j\), let \(k<l\) be the two remaining indices, and define
\[
 w_{ij}^{\varepsilon}=\frac{\langle v_i,v_j\rangle}{\sqrt2}
 (v_k\otimes v_l+\varepsilon v_l\otimes v_k),
 \qquad\varepsilon\in\{+1,-1\}.
\]
For each \(i\), order the three choices \(j\ne i\) increasingly. If \(K_i^\varepsilon\) is a real symmetric positive semidefinite \(3\times3\) matrix, then
\[
 \sum_{r,s=1}^3(K_i^\varepsilon)_{rs}
 \langle w_{i,j_r}^{\varepsilon},w_{i,j_s}^{\varepsilon}\rangle\ge0.
\]
Indeed, factoring \(K_i^\varepsilon=R^TR\) expresses this quantity as a sum of squared norms. This works without restricting the Gram vectors to be real.

We also use three scalar-pair Gram matrices. For each \(I\in\{\{1,2\},\{1,3\},\{1,4\}\}\), list \(I\) and its complement increasingly, and enumerate the two bijections \(\tau_1,\tau_2:I\to I^c\) lexicographically. Put
\[
 z_{I,r}=\prod_{i\in I}\langle v_i,v_{\tau_r(i)}\rangle.
\]
For any real symmetric \(L_I\succeq0\),
\[
 \sum_{r,s=1}^2(L_I)_{rs}\overline{z_{I,r}}z_{I,s}\ge0.
\]
Denote the sum of these tensor and scalar expressions by \(\mathcal Q_{K,L}(A)\).

Each term in the expansion of \(\mathcal Q_{K,L}\) is a permutation monomial. For example, before symmetrizing the two tensor factors,
\[
 \langle a_{ij}v_k\otimes v_l, a_{ij'}v_{k'}\otimes v_{l'}\rangle
 =a_{ji}a_{ij'}a_{kk'}a_{ll'}.
\]
The four row indices and four column indices are each distinct. Thus an identity \(F=\mathcal Q_{K,L}\) can be checked by matching its 24 permutation coefficients. No appeal to sampled Gram matrices is involved.

### 3.1 Exact coefficient data

For each of the six coefficient functions on \([0,3/4]\), `certificate.json` supplies four rational matrices in the order
\[
 K_1^+,\ K_1^-,\ K_2^+,\ K_2^-.
\]
The remaining matrices are defined by
\[
 K_4^\varepsilon=JK_1^\varepsilon J,\qquad
 K_3^\varepsilon=JK_2^\varepsilon J,
\]
where \(J\) reverses three coordinates. There are no scalar-pair terms on this interval. The exact checked identities are
\[
 F_k^{[0,3/4]}(A)=\mathcal Q_{K^{(k)},0}(A),\qquad 0\le k\le5,
\]
with every matrix positive semidefinite.

For \([3/4,1]\), the data provide the same four tensor matrices and three scalar-pair matrices for each \(k\), with exact identities
\[
 F_k^{[3/4,1]}(A)=\mathcal Q_{\widetilde K^{(k)},L^{(k)}}(A).
\]
Again all the matrices are positive semidefinite. The JSON file uses zero-based indices, with its conventions stated explicitly. Its numerators are integers and its denominators are positive integers.

For an elementary example, the first coefficient on \([0,3/4]\) is
\[
 F_0=|a_{12}|^2a_{33}a_{44}
      +|a_{23}|^2a_{11}a_{44}
      +|a_{34}|^2a_{11}a_{22}.
\]
The associated stored matrices are
\[
 K_1^+=K_1^-=\tfrac14\operatorname{diag}(1,0,0),\qquad
 K_2^+=K_2^-=\tfrac14\operatorname{diag}(1,1,0).
\]
The full data handle the remaining coefficients, including complex cycle products.

### 3.2 The negative central interval

Define the linear operation on permutation expressions
\[
 \mathcal T(m_\sigma)=-\operatorname{sgn}(\sigma)m_\sigma.
\]
For \(t\ge0\), applying \(\mathcal T\) to the coefficient expression for \(P'_t\) gives the expression for \(P'_{-t}\), since
\[
 -\operatorname{sgn}(\sigma)\ell(\sigma)t^{\ell(\sigma)-1}
 =\ell(\sigma)(-t)^{\ell(\sigma)-1}.
\]
This includes the zero coefficient when \(\ell(\sigma)=0\).

For contraction-square expressions without scalar-pair terms, \(\mathcal T\) is implemented by
\[
 K_i^+\longmapsto DK_i^-D,\qquad
 K_i^-\longmapsto DK_i^+D,\qquad D=\operatorname{diag}(1,-1,1).
\]
This follows by expanding the two tensor orientations; the verifier also checks each of the six resulting identities directly. These transformations preserve positive semidefiniteness. Therefore the certificate on \([0,3/4]\) also proves \(P'_q(A)\ge0\) on \([-3/4,0]\).

Combining these coefficient identities establishes \(P'_q(A)\ge0\) on \([-3/4,1]\) for every Hermitian PSD matrix of order four, with no rank restriction.

## 4. The interval near minus one

Now suppose \(\operatorname{rank}A\le3\), and choose Gram vectors in \(\mathbb C^3\). On \((\mathbb C^3)^{\otimes4}\), let
\[
 U_\sigma(v_1\otimes\cdots\otimes v_4)
 =v_{\sigma(1)}\otimes\cdots\otimes v_{\sigma(4)},\qquad
 T(q)=\sum_{\sigma\in S_4}\ell(\sigma)q^{\ell(\sigma)-1}U_\sigma,
\]
where terms of inversion number zero are omitted. Then
\[
 P'_q(A)=\langle v_1\otimes\cdots\otimes v_4,
 T(q)(v_1\otimes\cdots\otimes v_4)\rangle.
\]

For \(q=-1+t/4\), use the exact degree-five Bernstein expansion
\[
 T(q)=\sum_{k=0}^5\beta_k(t)Z_k,\qquad
 Z_k=\sum_{\sigma\in S_4}h_k^{[-1,-3/4]}(\ell(\sigma))U_\sigma.
\]
**Finite matrix lemma.** Each rational matrix \(Z_k\) is positive semidefinite on \((\mathbb C^3)^{\otimes4}\).

Here is the complete finite verification procedure. In the standard tensor basis, permutations preserve the multiplicity of each of the three coordinate symbols. The 81-dimensional space is the orthogonal sum of 15 such weight spaces. Their dimensions are 1, 4, 6, or 12. The checker constructs each block from the displayed formula, using exact fractions, and verifies all \(6\cdot15=90\) blocks by exact Schur complements. No representation-theoretic decomposition is assumed. For the 12-dimensional block with multiplicities \((2,1,1)\), the six exact ranks are
\[
 3,\quad9,\quad12,\quad12,\quad12,\quad12.
\]

The Schur test is elementary. A real symmetric matrix
\[
 \begin{pmatrix}d&b^T\\b&C\end{pmatrix}
\]
is positive semidefinite exactly when either \(d>0\) and \(C-bb^T/d\succeq0\), or \(d=0\), \(b=0\), and \(C\succeq0\). A negative pivot fails the test. Thus the block checks reduce to signs and equalities of rational numbers. The verifier tests the singular cases explicitly rather than using a floating-point tolerance.

This proves the matrix lemma and hence \(P'_q(A)\ge0\) for \(\operatorname{rank}A\le3\) on \([-1,-3/4]\).

## 5. Removing the rank restriction

This is the Gram-vector reduction underlying Mitchell's singular-matrix argument [2]; the present proof uses only its fixed-order version.

Write \(A=\operatorname{Gram}(x,v_1,v_2,v_3)\), \(B=\operatorname{Gram}(v_1,v_2,v_3)\), and decompose \(x=u+w\), where \(u\) belongs to the span of the other three vectors and \(w\) is orthogonal to that span. Let
\[
 A_0=\operatorname{Gram}(u,v_1,v_2,v_3).
\]
Then \(\operatorname{rank}A_0\le3\) and
\[
 P_q(A)=P_q(A_0)+\|w\|^2P_q(B).
\]
To see this directly, the off-diagonal entries involving the first index are unchanged; the first diagonal entry increases by \(\|w\|^2\). Only permutations fixing the first index contribute to the difference, and deleting that fixed first index leaves the inversion count unchanged.

The order-three inequality \(P'_q(B)\ge0\) is established in the literature [1,2]. For completeness it has a short sum-of-squares proof. After scaling the first Gram vector and changing orthonormal coordinates, it suffices to use
\[
 e_1,\quad ae_1+ce_2,\quad be_1+de_2+fe_3.
\]
For the corresponding Gram matrix,
\[
\begin{aligned}
 P'_q(B)={}&|(1+q)a\overline b+c\overline d|^2
 +|a|^2|b|^2(1+q)^2+|ad+qbc|^2\\
 &+(|a|^2+2|c|^2)|b|^2q^2+|a|^2|f|^2\ge0.
\end{aligned}
\]
The zero-vector case is immediate; a non-unit first vector supplies a positive scaling factor. The identity holds for every real \(q\).

Differentiating the decomposition therefore gives
\[
 P'_q(A)=P'_q(A_0)+\|w\|^2P'_q(B)\ge0
\]
also on \([-1,-3/4]\). Together with Section 3 this proves the derivative assertion for all Hermitian PSD matrices of order four.

## 6. Strict monotonicity

Suppose the diagonal is positive and \(A\) is not diagonal. By the strict equality condition in the Gram form of Hadamard's determinant inequality,
\[
 P_{-1}(A)=\det A<\prod_i a_{ii}=P_0(A).
\]
Hence \(P_q(A)\) is not a constant polynomial. A polynomial whose derivative is nonnegative throughout an interval is nondecreasing. If it took the same value at two distinct points of the interval, it would be constant between them, and thus constant as a polynomial. This contradiction proves strict increase on \([-1,1]\).

## 7. Reproducibility and exact scope

Keep `check_certificate.py` and `certificate.json` in the same directory and run

```sh
python3 check_certificate.py
```

The checker requires Python 3.10 or later and only the standard library. It contains no optimizer, numerical eigenvalue test, or floating-point arithmetic. It checks the Bernstein conversion by independent polynomial expansion, 18 full contraction identities, all principal minors as well as Schur complements for the small Gram matrices, and all 90 tensor coefficient blocks. The accompanying `verification.txt` records a successful run.

The matrices were discovered using numerical semidefinite-feasibility searches, then replaced by rational matrices satisfying the coefficient identities exactly. Discovery does not enter the proof: the supplied checker needs neither the search code nor a numerical solver.

These results settle the order-four case within this computer-assisted argument. The conjecture for unrestricted order remains unresolved here. Independent mathematical review, verification of novelty, and a proof-assistant formalization are separate tasks, not claims of this note.

## References

[1] R. B. Bapat, *Interpolating the determinantal and permanental Hadamard inequality*, Linear and Multilinear Algebra **32** (1992), 335–337.

[2] L. Mitchell, *A note on Bapat's q-permanent conjecture*, Operators and Matrices **14** (2020), 915–919. In particular, Theorems 1–3 and the order-three sum-of-squares identity on p. 918.

[3] *OpenProblemsInNLA*, entry MI-18, “Bapat's q-permanent monotonicity conjecture”; repository status read on 16 September 2026. The entry's displayed last-check date was 10 September 2026.
