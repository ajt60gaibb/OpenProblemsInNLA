#!/usr/bin/env python3
"""Exact checker for an order-four case of Bapat's q-permanent conjecture.

Usage: python3 check_certificate.py [certificate.json]
Python 3.10+; standard library only. There is no optimizer and no floating-point
arithmetic in this checker. See proof.md for the mathematical reduction.

The checker verifies polynomial identities coefficient-by-coefficient in all
24 permutation monomials, rational positive semidefiniteness of the contraction
certificates, and positivity of all tensor-operator Bernstein coefficient
blocks near q=-1. It is not a proof-assistant formalization of the reduction.
"""
from __future__ import annotations

from collections import defaultdict
from fractions import Fraction as F
from itertools import permutations, product, combinations
from math import comb
from pathlib import Path
import json
import sys

Perm = tuple[int, ...]
Matrix = list[list[F]]
P = tuple(permutations(range(4)))
PINDEX = {p: i for i, p in enumerate(P)}


def require(ok: bool, message: str) -> None:
    if not ok:
        raise ValueError(message)


def inversions(p: Perm) -> int:
    return sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4))


LENGTH = tuple(inversions(p) for p in P)


def zeros(n: int) -> Matrix:
    return [[F(0) for _ in range(n)] for _ in range(n)]


def bernstein_weight(length: int, k: int, a: F, b: F) -> F:
    """Coefficient k of length*q**(length-1) in degree-5 Bernstein form."""
    if length == 0:
        return F(0)
    degree = length - 1
    return length * sum(
        F(comb(degree, r) * comb(k, r), comb(5, r))
        * a ** (degree - r) * (b - a) ** r
        for r in range(min(k, degree) + 1)
    )


def target(k: int, a: F, b: F) -> list[F]:
    return [bernstein_weight(ell, k, a, b) for ell in LENGTH]


def validate_bernstein_formula() -> None:
    """Independently expand beta_k after substituting q=a+(b-a)*t."""
    for a, b in [(F(0), F(3, 4)), (F(3, 4), F(1)),
                 (F(-1), F(-3, 4))]:
        for ell in range(7):
            recovered = [F(0)] * 6
            for k in range(6):
                c = bernstein_weight(ell, k, a, b)
                for s in range(6 - k):
                    recovered[k + s] += c * comb(5, k) * comb(5-k, s) * (-1)**s
            expected = [F(0)] * 6
            if ell:
                for r in range(ell):
                    expected[r] = ell * comb(ell - 1, r) * a**(ell-1-r) * (b-a)**r
            require(recovered == expected, 'Bernstein conversion identity failed')


def psd_pivots(A: Matrix, name: str) -> list[F]:
    """Exact Schur-complement PSD test, including singular pivots.

    [d b*; b C] >= 0 iff either d>0 and C-b b*/d>=0,
    or d=0, b=0 and C>=0. The matrices here are real symmetric.
    """
    n = len(A)
    require(all(len(row) == n for row in A), name + ': not square')
    require(all(A[i][j] == A[j][i] for i in range(n) for j in range(n)),
            name + ': not symmetric')
    S = [row[:] for row in A]
    pivots: list[F] = []
    while S:
        d = S[0][0]
        require(d >= 0, name + ': negative exact Schur pivot ' + str(d))
        pivots.append(d)
        if d == 0:
            require(all(x == 0 for x in S[0][1:]),
                    name + ': zero diagonal with nonzero off-diagonal')
            S = [row[1:] for row in S[1:]]
        else:
            S = [[S[i][j] - S[i][0]*S[0][j]/d
                  for j in range(1, len(S))] for i in range(1, len(S))]
    return pivots


def determinant_small(A: Matrix) -> F:
    """Independent Leibniz determinant, used only for size <= 3."""
    n = len(A)
    ans = F(0)
    for p in permutations(range(n)):
        term = F((-1)**sum(p[i] > p[j] for i in range(n) for j in range(i+1, n)))
        for i in range(n):
            term *= A[i][p[i]]
        ans += term
    return ans


def verify_small_psd(A: Matrix, name: str) -> None:
    require(len(A) <= 3, name + ': expected a small matrix')
    psd_pivots(A, name)
    # A second exact criterion, independent of the Schur calculation.
    for size in range(1, len(A)+1):
        for I in combinations(range(len(A)), size):
            sub = [[A[i][j] for j in I] for i in I]
            require(determinant_small(sub) >= 0, name + ': negative principal minor')


def parse_matrices(entry: dict) -> tuple[list[Matrix], list[Matrix]]:
    d = entry['denominator']
    require(isinstance(d, int) and d > 0, 'Invalid certificate denominator')
    def parse(raw: list) -> list[Matrix]:
        require(all(isinstance(x, int) for A in raw for row in A for x in row),
                'Certificate numerators must be integers')
        return [[[F(x, d) for x in row] for row in A] for A in raw]
    K, L = parse(entry['K']), parse(entry['L'])
    require(len(K) == 4 and all(len(A) == 3 and all(len(r)==3 for r in A) for A in K),
            'Expected four 3-by-3 K matrices')
    require(len(L) in (0, 3) and all(len(A) == 2 and all(len(r)==2 for r in A) for A in L),
            'Expected zero or three 2-by-2 L matrices')
    return K, L


def reverse(A: Matrix) -> Matrix:
    return [list(reversed(row)) for row in reversed(A)]


def full_K(K: list[Matrix]) -> dict[tuple[int, int], Matrix]:
    # Key: (distinguished index, symmetry sign).
    return {(0, 1): K[0], (0, -1): K[1],
            (1, 1): K[2], (1, -1): K[3],
            (2, 1): reverse(K[2]), (2, -1): reverse(K[3]),
            (3, 1): reverse(K[0]), (3, -1): reverse(K[1])}


def perm_from_factors(factors: list[tuple[int, int]]) -> Perm:
    """Identify prod a_ij with a permutation monomial, without cancellations."""
    require(sorted(i for i, _ in factors) == list(range(4)), 'Repeated/missing row')
    require(sorted(j for _, j in factors) == list(range(4)), 'Repeated/missing column')
    p = [-1]*4
    for i, j in factors:
        p[i] = j
    return tuple(p)


def contraction_coefficients(K: list[Matrix], L: list[Matrix]) -> list[F]:
    """Fully expand the displayed Hilbert-space squared-norm expressions.

    w_ij^s = a_ij (v_k tensor v_l + s v_l tensor v_k)/sqrt(2), k<l.
    This uses all four terms of each inner product, rather than relying on
    the two-term simplification used when discovering the certificate.
    """
    coeff = [F(0)] * 24
    for (i, sign), Q in full_K(K).items():
        js = [j for j in range(4) if j != i]
        for r, j in enumerate(js):
            left = [h for h in range(4) if h not in (i, j)]
            for s, jp in enumerate(js):
                right = [h for h in range(4) if h not in (i, jp)]
                for alpha, beta in product(range(2), repeat=2):
                    u = left if alpha == 0 else list(reversed(left))
                    v = right if beta == 0 else list(reversed(right))
                    factors = [(j, i), (i, jp), (u[0], v[0]), (u[1], v[1])]
                    p = perm_from_factors(factors)
                    coeff[PINDEX[p]] += Q[r][s] * F(sign**(alpha+beta), 2)
    for h, Q in enumerate(L, start=1):
        I = [0, h]
        J = [j for j in range(4) if j not in I]
        words = [list(zip(I, order)) for order in permutations(J)]
        for r, s in product(range(2), repeat=2):
            factors = [(j, i) for i, j in words[r]] + words[s]
            p = perm_from_factors(factors)
            coeff[PINDEX[p]] += Q[r][s]
    return coeff


def sign_transform(K: list[Matrix]) -> list[Matrix]:
    d = (1, -1, 1)
    def conjugate(A: Matrix) -> Matrix:
        return [[d[i]*A[i][j]*d[j] for j in range(3)] for i in range(3)]
    return [conjugate(K[1]), conjugate(K[0]),
            conjugate(K[3]), conjugate(K[2])]


def verify_contractions(data: dict) -> None:
    checks = 0
    for field, a, b in [('central_positive', F(0), F(3, 4)),
                        ('upper_positive', F(3, 4), F(1))]:
        section = data[field]
        require(list(map(F, section['interval'])) == [a, b], 'Incorrect interval')
        entries = section['coefficients']
        require(len(entries) == 6, 'Expected six Bernstein coefficients')
        for k, entry in enumerate(entries):
            K, L = parse_matrices(entry)
            require(len(L) == (0 if field == 'central_positive' else 3),
                    'Incorrect number of scalar-pair blocks')
            for j, A in enumerate(K + L):
                verify_small_psd(A, f'{field}[{k}].block[{j}]')
            require(contraction_coefficients(K, L) == target(k, a, b),
                    f'{field}[{k}]: polynomial coefficient mismatch')
            checks += 1
            if field == 'central_positive':
                NK = sign_transform(K)
                for j, A in enumerate(NK):
                    verify_small_psd(A, f'central_negative[{k}].block[{j}]')
                expected = [(-1)**(ell+1)*c for ell, c in zip(LENGTH, target(k, a, b))]
                require(contraction_coefficients(NK, []) == expected,
                        f'central_negative[{k}]: polynomial coefficient mismatch')
                checks += 1
    print(f'PASS: {checks} exact contraction polynomial identities (24 coefficients each).')
    print('PASS: every 2-by-2 and 3-by-3 certificate matrix is PSD,')
    print('      by both exact Schur complements and all principal minors.')


def verify_near_minus_one() -> None:
    # Permutations preserve each coordinate-multiplicity subspace of (C^3)^tensor4.
    # Check every such subspace: no irreducible-representation assumption needed.
    weight_spaces: dict[tuple[int, ...], list[Perm]] = defaultdict(list)
    for word in product(range(3), repeat=4):
        weight_spaces[tuple(word.count(j) for j in range(3))].append(word)
    require(len(weight_spaces) == 15, 'Wrong weight-space count')
    require(sum(map(len, weight_spaces.values())) == 81, 'Incomplete tensor decomposition')
    representative_ranks: list[int] = []
    checked = 0
    for k in range(6):
        c = target(k, F(-1), F(-3, 4))
        for count, words in sorted(weight_spaces.items()):
            lookup = {word: j for j, word in enumerate(words)}
            A = zeros(len(words))
            for p, value in zip(P, c):
                for col, word in enumerate(words):
                    image = tuple(word[p[j]] for j in range(4))
                    A[lookup[image]][col] += value
            pivots = psd_pivots(A, f'near_minus_one[{k}], weight={count}')
            if count == (2, 1, 1):
                representative_ranks.append(sum(d > 0 for d in pivots))
            checked += 1
    require(representative_ranks == [3, 9, 12, 12, 12, 12],
            'Unexpected representative ranks')
    print(f'PASS: all {checked} exact tensor Bernstein blocks are PSD (6 x 15).')
    print('      Largest blocks: 12-by-12; representative ranks:', representative_ranks)


def main() -> None:
    require(len(sys.argv) <= 2, 'Usage: python3 check_certificate.py [certificate.json]')
    path = Path(sys.argv[1]) if len(sys.argv) == 2 else Path(__file__).with_name('certificate.json')
    data = json.loads(path.read_text(encoding='utf-8'))
    require(data['schema'] == 'mi18-order4-exact-certificate-v1', 'Unknown schema')
    validate_bernstein_formula()
    print('PASS: exact Bernstein conversion checked by polynomial expansion.')
    verify_contractions(data)
    verify_near_minus_one()
    print('ALL EXACT CHECKS PASSED.')
    print('Together with the Gram-vector reduction and strictness argument in proof.md,')
    print('these certificates establish the 4-by-4 case, not the arbitrary-order conjecture.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print('FAIL:', exc, file=sys.stderr)
        sys.exit(1)
