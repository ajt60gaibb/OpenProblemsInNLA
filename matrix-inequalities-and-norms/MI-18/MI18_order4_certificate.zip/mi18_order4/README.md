# MI-18: exact order-four certificate

This package contains a computer-assisted argument for the complete 4-by-4 case
of Bapat's q-permanent monotonicity conjecture, including complex Hermitian PSD
matrices and the entire parameter interval [-1,1]. It does not prove the
arbitrary-order conjecture. It has not been independently reviewed or formally
verified in Lean, and novelty is not independently certified.

Read `proof.pdf` or `proof.md` for the mathematics. The proof uses the exact
identities in `certificate.json`; `check_certificate.py` verifies them with
Python's standard library and exact rational arithmetic.

Run:

    python3 check_certificate.py

Python 3.10+ is sufficient. No third-party packages, network connection,
optimization solver, or floating-point calculation are required.

`verification.txt` is the recorded output of the checker. `proof.tex` is the
LaTeX source for the PDF.
