# MI-18 literature and repository check

**Date:** 16 September 2026. **Purpose:** check for overlap with the claimed
complete complex Hermitian PSD order-four monotonicity theorem on [-1,1].
**Conclusion:** no overlapping general order-four result was located in the
accessible sources checked. This is a bounded search result, not a priority
certification or an assertion that no such result exists.

## Directly reviewed primary sources

### L. Mitchell, 2020

*A note on Bapat's q-permanent conjecture*, Operators and Matrices 14,
915–919. DOI: 10.7153/oam-2020-14-56.

```
https://files.ele-math.com/articles/oam-14-56.pdf
```

The full five-page paper was inspected, including the displayed order-three
identity. The introduction explicitly describes order four as difficult;
Theorem 2 gives rank one in arbitrary order, and Theorem 3 gives the
nullity-one reduction. The end of page 918 gives the order-three SOS argument.
The Gram-vector reduction and order-three base case in our proof are not new.
No general order-four theorem appears in this paper.

### C. M. da Fonseca, 2018 preprint

*The mu-permanent revisited*, arXiv:1804.02231 (nine-page preprint).

```
https://arxiv.org/pdf/1804.02231
```

The monotonicity discussion and graph-ordering corrections were inspected.
Section 4 records n <= 3, tridiagonal cases, and graph-labeling-restricted
cases. Its related subset and eigenvalue conjectures are not the monotonicity
statement. No general order-four result was located. The 2018 nine-page
preprint should not be silently identified with the two-page 2019 published
note with the same title, listed in Mitchell's bibliography.

### E. Marques de Sa, 2019 paper / departmental preprint

*Linear preservers for the q-permanent, cycle q-permanent expansions, and
positive crossings in digraphs*, Linear Algebra and its Applications 561,
228–252. DOI: 10.1016/j.laa.2018.09.027.

```
https://www.mat.uc.pt/preprints/ps/p1809.pdf
```

The relevant expansion/correction discussion was inspected. It warns against
unqualified cycle-expansion identities used in earlier work. Our fixed-first-
index deletion identity is separately proved and checked; no arbitrary
permutation similarity is assumed. No general order-four monotonicity result
was found in the inspected material.

### N.-E. Fahssi, 2026 preprint (screened for overlap)

*The limits of Schur multipliers in Polya conversion problems for the
q-permanent function*, arXiv:2605.24349v2, 31 May 2026.

```
https://arxiv.org/pdf/2605.24349
```

The abstract, introduction, contents, and target statements were screened.
This concerns conversion/preserver problems; its order-four thresholds are not
a proof of PSD monotonicity. Full-text searches for "monoton" and "Bapat"
returned no matches. This is an overlap screen, not an audit of its theorems.

## Sources located but not fully available in this audit

R. B. Bapat, *Interpolating the determinantal and permanental Hadamard
inequality*, Linear and Multilinear Algebra 32 (1992), 335–337; R. B. Bapat
and A. K. Lal, *Inequalities for the q-permanent*, Linear Algebra and its
Applications 197/198 (1994), 397–409; and A. K. Lal, *Inequalities for the
q-permanent II*, Linear Algebra and its Applications 274 (1998), 1–16, were
identified through the primary bibliographies. The original full texts were
not directly reviewed in this audit. The 1994 DOI is
10.1016/0024-3795(94)90497-9; the 1998 DOI is
10.1016/S0024-3795(97)00083-9.

E. Marques de Sa, *Noncrossing partitions, noncrossing graphs, and
q-permanental equations*, Linear Algebra and its Applications 541 (2018),
36–53, was located through the university index, primary publisher abstract,
and Mitchell's references. The departmental PDF endpoint below repeatedly
failed to load; a complete direct review is not claimed.

```
https://www.mat.uc.pt/preprints/ps/p1722.pdf
https://www.sciencedirect.com/science/article/pii/S0024379517306523
```

These access limits leave room for missed results and citations. No exhaustive
MathSciNet/Zentralblatt/Scopus forward-citation audit was completed.

## Repository check

The canonical MI-18 README was read on 16 September 2026. It still displayed
**Partially resolved**, with its own last-check date **2026-09-10**, and listed
rank-one and order-three progress. It did not record a general order-four
proof.

```
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/matrix-inequalities-and-norms/MI-18/README.md
https://github.com/ajt60gaibb/OpenProblemsInNLA/pulls
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/CONTRIBUTING.md
```

The visible open-PR list showed seven entries, numbers 274–280, concerning
MF-24, IE-04, MF-12, IE-14, MF-22, KE-05, and IV-03. None was titled as
MI-18 progress. This is not a search of all closed PRs, branches, forks, or
private/unpublished work. The local container could not resolve github.com;
a git clone failed. Public reads were made through the web tool. No repository
build or commit-pinned full-history audit was completed, and no submission was
made.

The contribution guidelines require exact scopes and distinguish partial
results from the original arbitrary-order question. An order-four contribution
must retain the problem's partially resolved status rather than mark MI-18
solved or Lean verified.

## Search strategy and limitations

Queries varied "q-permanent", "mu-permanent", "Bapat", "Mitchell",
"monotonicity", "four", "order four", "4x4", "proof", "counterexample",
and 2025/2026. Representative exact queries included:

```
"q-permanent" "monotonicity" "four"
"Bapat" "monotonicity" "2025"
"Bapat" "q-permanent" "2026"
"q-permanent" "Mitchell" "4"
```

Searches often returned sparse or irrelevant results. Absence from these
results is weak evidence by itself. The affirmative basis for possible novelty
is the comparison with the directly reviewed mathematical sources, combined
with the absence of an overlapping result in this bounded search. The proper
public wording is: **"No prior general order-four proof was located in the
sources checked as of 16 September 2026; novelty remains provisional."**
