---
title: "MI-18 order-four certificate: audit"
date: "16 September 2026"
fontsize: 11pt
geometry: "a4paper,margin=23mm"
colorlinks: true
linkcolor: black
urlcolor: blue
header-includes:
  - \usepackage{amsmath,amssymb,booktabs,microtype}
  - \setlength{\emergencystretch}{2em}
---

# 1. Finding and exact scope

**No mathematical gap was identified in the order-four argument.** The original
exact checker passes, and a separately written implementation reproduces the
finite identities and positive-semidefiniteness claims using different algebra
and a different positivity test. The original rational certificate and proof
files did not need repair and remain unchanged in this package.

This is a fresh audit and an independent *code path*, **not independent external
or human review**: the same AI assistant produced the original argument and
this audit. No proof-assistant formalization, certification of novelty, or
resolution in arbitrary order is claimed.

The precise result supported by the argument is the following. For
$A\in\mathbb C^{4\times4}$ Hermitian positive semidefinite, let
$$
 P_q(A)=\sum_{\sigma\in S_4}q^{\ell(\sigma)}
              \prod_{i=1}^4 a_{i,\sigma(i)},
$$
where $\ell$ counts inversions in the fixed displayed order. Then
$$
 P'_q(A)\ge0\qquad(-1\le q\le1).
$$
If $A$ has positive diagonal and is not diagonal, $P_q(A)$ is strictly
increasing on $[-1,1]$. Zero diagonal entries are allowed in the derivative
assertion; real entries, nonsingularity, and special graph patterns are not
assumptions. This settles only the $n=4$ subcase within the supplied
computer-assisted argument.

The novelty check found no prior general order-four proof in the accessible
sources examined. That conclusion is bounded by the sources and access limits
listed below. The appropriate next public use is a **claimed order-four partial
result for specialist review**, not a claim that MI-18 is solved.

# 2. Integrity and reproduction

All seven entries in the original SHA-256 manifest matched the untouched
extraction. The original checker was rerun successfully. The original
`certificate.json`, checker, proof sources/PDF, and original verification log
are unchanged; the original README is retained under `README.original.md`.

The new implementation, `audit_verify.py`, does not import the original
checker. It was executed on Python 3.13.5 with SymPy 1.14.0 and uses exact
symbolic/rational arithmetic throughout. No optimizer, random matrix sample,
parameter grid, floating-point eigenvalue, or numerical tolerance enters it.
The original checker needs only Python's standard library.

\newpage

# 3. The finite checks and how they differ

The new code reconstructs whole polynomial identities in 16 independent
commutative matrix-entry variables. Thus equality is verified before imposing
Hermitian symmetry or positive semidefiniteness, rather than inferred from
examples on a subset of matrices.

The original verifier compares 24 permutation coefficients, obtains Bernstein
coefficients from a closed formula, and checks PSD by rational Schur
complements, with principal-minor checks for the small matrices. The audit
uses a different implementation for each of these steps.

**Contraction identities.** It differentiates the full symbolic $q$-permanent
and recombines the supplied coefficient expressions with degree-five Bernstein
polynomials. The resulting whole-polynomial equality is checked on
$[0,3/4]$, $[-3/4,0]$, and $[3/4,1]$. This reproduces the content of all 18
coefficient identities. The tensor expansion uses a two-term inner-product
formula instead of the original four-orientation expansion.

**Small PSD matrices.** All 66 stored rational matrices are checked by their
characteristic polynomials: 24 central-interval tensor matrices and 42
upper-interval tensor/scalar matrices. The remaining reversed or reflected
matrices are congruent to these. For a real symmetric matrix $M$,
$$
 M\succeq0\quad\Longleftrightarrow\quad
 \text{every coefficient of }\det(XI+M)\text{ is nonnegative}.
$$
Indeed, necessity follows by multiplying the factors $X+\lambda_j$. For
sufficiency, a negative eigenvalue would give a positive root of a monic
polynomial with nonnegative coefficients, which is impossible. Symmetry is
checked explicitly, and singular matrices are included. This test shares no
Schur-complement or principal-minor code with the original implementation.

**Tensor Bernstein matrices near $-1$.** The audit obtains the coefficients
by solving an exact six-by-six polynomial change-of-basis system. It constructs
matrix entries using Kronecker-delta conditions on tensor words, rather than
the original permutation-image lookup. All 90 blocks (six coefficients on 15
weight spaces, total tensor dimension 81 per coefficient) pass the
characteristic-polynomial PSD test. Every matrix entry is also recombined to
recover the derivative operator polynomial on $[-1,-3/4]$.

**Checks linking mathematics to algebra.** Exact symbolic expansions verify
complex conjugation in the tensor forms, the first-diagonal perturbation
identity used in the rank reduction, the order-three SOS identity for five
arbitrary complex variables, and the endpoint determinant/diagonal-product
identities. The geometric and strictness arguments are reviewed in Section 4.

**Sensitivity checks.** Both verifiers reject six deliberately corrupted
certificates: an altered but still PSD coefficient matrix, a changed
denominator, a negative diagonal, asymmetry, a missing Bernstein coefficient,
and a wrong interval. These are 12 successful rejection tests, not a proof of
software correctness.

The package includes the actual execution logs and every exact tensor
characteristic polynomial. The README identifies each file. No run is merely
proposed or simulated.

\newpage

# 4. Review of the non-finite mathematical steps

## Complex Gram forms

The convention is $a_{ij}=\langle v_i,v_j\rangle$, conjugate-linear in the
first argument. If $k<l$ and $k'<l'$ are the complementary indices, then
$$
\begin{aligned}
\langle w_{ij}^{\varepsilon},w_{ij'}^{\varepsilon}\rangle
={}&a_{ji}a_{ij'}
  (a_{kk'}a_{ll'}+\varepsilon a_{kl'}a_{lk'}),\\
w_{ij}^{\varepsilon}
={}&\frac{a_{ij}}{\sqrt2}
(v_k\otimes v_l+\varepsilon v_l\otimes v_k).
\end{aligned}
$$
For a real PSD coefficient matrix $K=R^TR$, its weighted Gram expression is
$\sum_\alpha\|\sum_r R_{\alpha r}w_r\|^2$. This remains nonnegative for
complex vectors. The scalar blocks are ordinary complex Gram forms
$\sum_{rs}L_{rs}\overline z_rz_s$ with $L\succeq0$. There is no hidden
real-matrix restriction.

The negative-interval sign transformation is asserted only for the tensor
contraction expressions without scalar blocks. The audit verifies the
reflected identities directly; it does not assume that a sign twist preserves
positivity of every polynomial on the PSD cone.

## Tensor operator and rank reduction

For real $q$, the derivative operator is Hermitian because
$U_\sigma^*=U_{\sigma^{-1}}$ and
$\ell(\sigma)=\ell(\sigma^{-1})$. Its expectation on
$v_1\otimes\cdots\otimes v_4$ is exactly $P'_q(A)$.
On $[-1,-3/4]$ operator positivity is proved in $(\mathbb C^3)^{\otimes4}$,
so this part initially applies to rank at most three, not to arbitrary rank.

To remove this restriction, write
$A=\operatorname{Gram}(x,v_1,v_2,v_3)$ and $x=u+w$, with $u$ in the span
of the other vectors and $w$ orthogonal to that span. Put
$A_0=\operatorname{Gram}(u,v_1,v_2,v_3)$ and
$B=\operatorname{Gram}(v_1,v_2,v_3)$. Then
$$
 P_q(A)=P_q(A_0)+\|w\|^2P_q(B),\qquad \operatorname{rank}A_0\le3.
$$
This is the known Gram-vector reduction underlying Mitchell [1], not a new
contribution. It changes only the **first** diagonal entry. Permutations fixing
that index have the same inversion count after its deletion. No arbitrary
row/column relabeling or interior-index cofactor identity is used. The formal
identity for an arbitrary matrix $G$ was checked:
$$
 P_q(G+\rho E_{11})-P_q(G)-\rho P_q(G[2{:}4,2{:}4])=0.
$$
This distinction matters because ordering issues caused errors in earlier
$q$-permanent arguments; see [2,3].

\newpage

## Order-three base and strictness

For Gram vectors
$e_1,\ ae_1+ce_2,\ be_1+de_2+fe_3$, the identity used is
$$
\begin{aligned}
P'_q(B)={}&|(1+q)a\overline b+c\overline d|^2
 +|a|^2|b|^2(1+q)^2+|ad+qbc|^2\\
&+(|a|^2+2|c|^2)|b|^2q^2+|a|^2|f|^2.
\end{aligned}
$$
It was checked in independent real and imaginary parts of all five complex
variables. It holds for every real $q$. A zero first vector gives a zero row;
a nonunit first vector introduces only a positive scaling factor. Thus it
covers every order-three Hermitian PSD matrix. This is the known order-three
argument [1], with the orthogonal $f$-component made explicit.

Finally $P_q(A)$ is real for Hermitian $A$, since conjugating a permutation
monomial replaces its permutation by the inverse without changing its
inversion count. Positive diagonal and non-diagonality give
$$
 P_{-1}(A)=\det A<\prod_i a_{ii}=P_0(A)
$$
by the strict equality condition in Hadamard's inequality. Hence the
polynomial is nonconstant. A nondecreasing polynomial taking equal values at
two distinct points would be constant between them and therefore identically
constant. This proves strict increase without requiring a strictly positive
derivative at every point.

# 5. A smaller tensor certificate for reviewers

The audit also yielded a simplification of the near-$-1$ matrix lemma. Only
the six 12-dimensional blocks with symbol multiplicities $(2,1,1)$ need to be
checked; the other weight types follow by merging coordinate symbols.

Let $\Omega$ be the 12 words with two copies of symbol 0 and one each of
symbols 1 and 2. The other multiplicity types, up to renaming symbols, are
$(3,1,0)$, $(2,2,0)$, and $(4,0,0)$. They result from maps of symbols
$(0,1,2)\mapsto(0,0,1)$, $(0,1,1)$, and $(0,0,0)$, respectively. Their
fibres have constant sizes 3, 2, and 12.

The pullback $J$ along such a word map intertwines every permutation of tensor
positions, and $J^*J=mI$ for the fibre size $m$. Therefore, if $Z$ and $Y$ are
the source and target coefficient blocks, $ZJ=JY$, so
$$
 m\langle v,Yv\rangle=\langle Jv,ZJv\rangle\ge0.
$$
Renaming coordinate symbols gives the remaining blocks. This is a tensor
basis argument, not an assertion that reordering the four matrix indices
preserves the $q$-permanent.

`tensor_addendum.py` verifies all these intertwiners and the factorizations
in Section 6. It reuses the new audit's coefficient-generation routine and
is **not a third independent verifier**. The two full 90-block verifications
remain in place, so the original result does not depend on this simplification.

\newpage

# 6. Explicit characteristic-polynomial factors

Let $Z_k$ denote the $(2,1,1)$ block of the $k$th degree-five Bernstein
coefficient of $T(-1+t/4)$, with $0\le k\le5$. Choose positive integer scales
$$
 (d_0,d_1,d_2,d_3,d_4,d_5)=(1,10,160,160,1280,512)
$$
and put $\chi_k(X)=\det(XI+d_kZ_k)$. The following exact factorizations have
only nonnegative coefficients. Symmetry of $Z_k$ therefore proves its PSD
property by Section 3. The ranks are $3,9,12,12,12,12$.

\begin{align*}
\chi_0(X)={}&X^9(X+4)^2(X+20),\\[3pt]
\chi_1(X)={}&X^3(X+2)(X+4)^2(X+12)(X+30)^2(X+150)\\
&\quad\cdot(X^2+16X+16),\\[3pt]
\chi_2(X)={}&(X+52)(X+104)^2(X+312)\\
&\quad\cdot(X^2+380X+4380)^2(X^2+416X+10816)\\
&\quad\cdot(X^2+1780X+37980),\\[3pt]
\chi_3(X)={}&(X+65)(X+129)^2(X+379)\\
&\quad\cdot(X^2+320X+8475)^2(X^2+508X+17641)\\
&\quad\cdot(X^2+1300X+67275),\\[3pt]
\chi_4(X)={}&(X+593)(X+1159)^2(X+3261)\\
&\quad\cdot(X^2+2290X+723135)^2\\
&\quad\cdot(X^2+4420X+1570297)(X^2+7430X+4824855),\\[3pt]
\chi_5(X)={}&(X+261)(X+497)^2(X+1309)\\
&\quad\cdot(X^2+862X+133721)^2\\
&\quad\cdot(X^2+1806X+320901)(X^2+2054X+659393).
\end{align*}

`tensor_six_block_data.json` records all six integer matrices $d_kZ_k$ and
their factorizations. Its basis is the lexicographic order on the 12 words
of multiplicity $(2,1,1)$ in $\{0,1,2\}^4$. The generating script constructs
every entry from the 24 position permutations and the exact Bernstein
coefficients; it does not read the factors as proof assumptions.

This reduces the finite tensor lemma to six explicitly reproducible integer
matrix computations. The contraction-square certificates on the other
intervals are unchanged.

\newpage

# 7. Literature comparison and novelty limits

Mitchell's 2020 paper [1] directly records the order-three result, proves rank
one in arbitrary dimension, and gives the singular-matrix reduction. Its
introduction explicitly treats order four as a difficult outstanding case.
The full paper was inspected, and no unrestricted order-four theorem appears.
The nine-page 2018 preprint of da Fonseca [2] records low-order, tridiagonal,
and graph-labeling-restricted cases, not the present generic order-four claim.
The relevant correction discussion in de Sa [3] was also checked.

A recent paper by Fahssi [4] was screened for overlap. Its results concern
$q$-permanent preservers/converters, including low-dimensional thresholds, not
this PSD monotonicity assertion. It does not supply an overlapping result.
This was an overlap screen, not a verification of that paper's proofs.

The potentially new content here is the **complete order-four theorem and the
specific interval-wise finite positivity certificates**. The Gram-vector
reduction, the order-three base case, the Bernstein basis, and elementary PSD
tests must not be presented as newly discovered general techniques.

There are material search limits. The original 1992/1994/1998 papers were
identified through primary bibliographies but their full texts were not
directly reviewed in this audit. The departmental PDF for de Sa's 2018
noncrossing paper did not load, although its publisher abstract and other
primary references were located. No exhaustive citation-database search or
private/unpublished-work survey was completed. Search-engine results were
sometimes sparse or irrelevant. Consequently, **novelty remains provisional**.

As read on 16 September 2026, the repository's MI-18 README [5] still displays
*Partially resolved* and a last-check date of 10 September. The visible open-PR
list [6] did not contain an MI-18 entry. Those observations do not cover closed
PRs, all branches, or unsubmitted work. A local clone failed because the
container could not resolve GitHub; public pages were read through the web
tool. No repository build or commit-pinned full-history audit was completed.

# 8. Readiness and remaining review

The argument is ready to be circulated as an exact computer-assisted
**order-four partial result pending external review**, with the proof and
both checkers together. No mathematical repair was needed in this audit.
The remaining substantive checks are independent specialist review of the
mathematical-to-code correspondence and a stronger priority check with the
relevant literature/authors. A Lean proof would be a separate verification
project; these Python computations are not formal verification in that sense.

For any contribution, retain the original arbitrary-order target and
*Partially resolved* status, disclose the AI provenance and this audit's
same-assistant limitation, and separate the theorem from the provisional
novelty statement. This follows the repository's scope rules [7]. Neither a
PR nor external correspondence has been submitted in this audit.

\newpage

# 9. Reproduction and references

The original certificate can be checked without third-party libraries:

```sh
python3 check_certificate.py
```

The second implementation and supplementary checks can be run as follows:

```sh
python3 -m pip install -r requirements-audit.txt
python3 audit_verify.py --report tensor_charpolys.json
python3 audit_mutations.py
python3 tensor_addendum.py
```

The first complete new run ends with
`ALL SECOND-IMPLEMENTATION CHECKS PASSED.` The mutation run ends with
`ALL 12 CORRUPTION-REJECTION TESTS PASSED.` The optional tensor supplement ends
with `ALL SIX-BLOCK ADDENDUM CHECKS PASSED.` The package includes the actual
logs, not only these summary statements.

The original proof is preserved as `proof.pdf`, `proof.tex`, and `proof.md`.
This report is an audit addendum, not a replacement proof. The original README
and manifest are retained; the new `SHA256SUMS.txt` covers the audited package.

## References and direct access

[1] L. Mitchell, *A note on Bapat's q-permanent conjecture*, Operators and
Matrices **14** (2020), 915--919. DOI: 10.7153/oam-2020-14-56.
[Full primary paper](https://files.ele-math.com/articles/oam-14-56.pdf).
Theorems 1--3 and the identity on p. 918 are especially relevant.

[2] C. M. da Fonseca, *The $\mu$-permanent revisited*,
[arXiv:1804.02231](https://arxiv.org/pdf/1804.02231), 2018 preprint, nine pages.
Do not conflate this with the two-page 2019 published note of the same title.

[3] E. Marques de Sa, *Linear preservers for the q-permanent, cycle
q-permanent expansions, and positive crossings in digraphs*, Linear Algebra
and its Applications **561** (2019), 228--252.
DOI: 10.1016/j.laa.2018.09.027.
[Departmental preprint](https://www.mat.uc.pt/preprints/ps/p1809.pdf).

[4] N.-E. Fahssi, *The limits of Schur multipliers in Polya conversion problems
for the q-permanent function*,
[arXiv:2605.24349v2](https://arxiv.org/pdf/2605.24349), 31 May 2026.
Screened for overlap only.

[5] *OpenProblemsInNLA*,
[MI-18 README](https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/matrix-inequalities-and-norms/MI-18/README.md),
read 16 September 2026; displayed last-check date 10 September 2026.

[6] *OpenProblemsInNLA*,
[visible open pull requests](https://github.com/ajt60gaibb/OpenProblemsInNLA/pulls),
read 16 September 2026. This is not a full repository-history audit.

[7] *OpenProblemsInNLA*,
[contribution guidelines](https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/CONTRIBUTING.md),
read 16 September 2026. Partial cases do not resolve the original full target.

See the accompanying literature-search log for further bibliographic details,
queries, and access failures.
