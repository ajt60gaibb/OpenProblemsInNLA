#!/usr/bin/env python3
"""Reproduce the optional six-block tensor simplification.

Requires SymPy and audit_verify.py. This is an explanatory supplement to that
verifier, not a third independent implementation. All computations are exact.
"""
from itertools import product
from math import lcm
from pathlib import Path
import json
import sympy as s
import audit_verify as a


def words_of_type(count):
    return [w for w in product(range(3), repeat=4)
            if tuple(w.count(i) for i in range(3)) == count]


def operator(words, weights):
    return s.Matrix(len(words), len(words), lambda r, c: sum(
        weights[a.length(p)] for p in a.PERMS
        if all(words[r][j] == words[c][p[j]] for j in range(4))))


def main():
    source = words_of_type((2, 1, 1))
    h = a.bernstein_change_of_basis()
    Z = [operator(source, [h[ell][k] for ell in range(7)]) for k in range(6)]
    # Entry J[w,v]=1 exactly when the symbol-merging map sends w to v.
    maps = [((0, 0, 0), (4, 0, 0), 12),
            ((0, 0, 1), (3, 1, 0), 3),
            ((0, 1, 1), (2, 2, 0), 2)]
    for mapping, target_type, fibre_size in maps:
        target = words_of_type(target_type)
        J = s.Matrix(len(source), len(target), lambda r, c:
                     int(tuple(mapping[u] for u in source[r]) == target[c]))
        a.require(J.T * J == fibre_size * s.eye(len(target)), 'wrong fibre size')
        # Check intertwining for every permutation, not just the six sums.
        for p in a.PERMS:
            Ps = s.Matrix(len(source), len(source), lambda r, c:
                          int(all(source[r][j] == source[c][p[j]] for j in range(4))))
            Pt = s.Matrix(len(target), len(target), lambda r, c:
                          int(all(target[r][j] == target[c][p[j]] for j in range(4))))
            a.require(Ps * J == J * Pt, 'intertwining failed')
        print(f'PASS: symbol merge to {target_type}, fibre size {fibre_size}, all 24 permutations.')
    records = []
    for k, M in enumerate(Z):
        scale = lcm(*(int(v.q) for v in M))
        N = scale * M
        polynomial = (-N).charpoly(a.X).as_expr()
        coefficient, factors = s.factor_list(polynomial)
        a.require(coefficient > 0, 'nonpositive factor coefficient')
        for f, exponent in factors:
            a.require(exponent > 0 and all(v >= 0 for v in s.Poly(f).all_coeffs()),
                      'factor has negative coefficient')
        a.require(s.expand(coefficient * s.prod(f**e for f, e in factors) - polynomial) == 0,
                  'factorization mismatch')
        factorized = s.factor(polynomial)
        print(f'PASS: k={k}, scale={scale}, det(X I + scale Z_k) = {factorized}')
        records.append({'k': k, 'scale': scale,
                        'integer_matrix': [[int(N[r,c]) for c in range(12)] for r in range(12)],
                        'characteristic_polynomial_factored': str(factorized),
                        'characteristic_polynomial_factored_latex': s.latex(factorized)})
    Path(__file__).with_name('tensor_six_block_data.json').write_text(
        json.dumps(records, indent=2) + '\n', encoding='utf-8')
    print('ALL SIX-BLOCK ADDENDUM CHECKS PASSED.')


if __name__ == '__main__':
    main()
