# MI-18: audited order-four certificate

**Audit date: 16 September 2026.** This package gives a computer-assisted argument
for the complete 4-by-4 case of Bapat's q-permanent monotonicity conjecture,
including complex Hermitian positive-semidefinite matrices and every q in
[-1,1]. It does **not** settle the arbitrary-order conjecture.

The original argument survived a fresh mathematical audit and a separately
written exact verification implementation. Both audit passes were performed by
the **same AI assistant**. This is not independent human/external review, not a
Lean formalization, and not a certification of novelty. No repository submission
or external correspondence has been made as part of this audit.

## Read first

- `audit_report.pdf` / `audit_report.md`: findings, mathematical/code audit,
  smaller tensor certificate, literature comparison, and limitations.
- `proof.pdf` / `proof.md`: original mathematical argument, unchanged.
- `literature_search.md`: dated sources, queries, direct-access limitations,
  and bounded novelty conclusion.

## Reproduce the original check

```sh
python3 check_certificate.py
```

This requires Python 3.10+ and only the standard library. The supplied verifier
uses exact rational arithmetic; it does not require the numerical discovery
search, an optimizer, random examples, or a network connection.

## Reproduce the second implementation

```sh
python3 -m pip install -r requirements-audit.txt
python3 audit_verify.py --report tensor_charpolys.json
python3 audit_mutations.py
python3 tensor_addendum.py
```

The audit was run on Python 3.13.5 with SymPy 1.14.0. The new verifier does not
import the old checker. It expands whole polynomials in independent matrix
entries, reconstructs the tensor matrices by a different procedure, and checks
PSD via exact characteristic polynomials, rather than Schur complements.

The last command reproduces an optional simplification to six 12-by-12 blocks
and their factored characteristic polynomials. It uses `audit_verify.py`; it is
**not a third independent implementation**. The mutation script deliberately
corrupts temporary copies and confirms both verifiers reject six error types.
These are limited sensitivity checks, not a proof of software correctness.

## Files and provenance

`certificate.json`, `check_certificate.py`, the three original proof files,
and `verification.txt` are unchanged from the original release. The original
README is preserved as `README.original.md`. `ORIGINAL_SHA256SUMS.txt` records
the original release manifest (where the README was named `README.md`).
`integrity_verification.txt` records checking that manifest in the untouched
original extraction. `SHA256SUMS.txt` is the manifest for this audited package.

`original_checker_rerun.txt`, `audit_verification.txt`,
`mutation_verification.txt`, and `tensor_addendum_verification.txt` are actual
successful execution logs. `tensor_charpolys.json` gives the exact
characteristic polynomials of all 90 tensor blocks; `tensor_six_block_data.json`
gives the six representative integer matrices, scales, and factorizations.

For a prospective repository contribution, preserve the original MI-18 target
and its **Partially resolved** status. State the exact order-four scope, AI
provenance, and review/novelty limitations. A case of the problem is not the
full arbitrary-order result.
