#!/usr/bin/env python3
"""Check that both exact verifiers reject deliberately corrupted certificates.
These tests are a limited sensitivity check, not a proof of software correctness.
"""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'certificate.json').read_text())


def mutate(name, data):
    e=data['central_positive']['coefficients'][0]
    if name=='changed_valid_psd_entry':
        e['K'][0][0][0]+=1  # Still PSD, but the identity is no longer correct.
    elif name=='wrong_denominator':
        e['denominator']+=1
    elif name=='negative_diagonal':
        e['K'][0][0][0]=-1
    elif name=='asymmetric_matrix':
        e['K'][0][0][1]=1
    elif name=='missing_coefficient':
        data['upper_positive']['coefficients'].pop()
    elif name=='wrong_interval':
        data['upper_positive']['interval'][0]='1/2'
    else:
        raise ValueError(name)


def main():
    cases=['changed_valid_psd_entry','wrong_denominator','negative_diagonal',
           'asymmetric_matrix','missing_coefficient','wrong_interval']
    total=0
    with tempfile.TemporaryDirectory(prefix='mi18-audit-') as tmp:
        for name in cases:
            data=deepcopy(DATA)
            mutate(name,data)
            path=Path(tmp)/(name+'.json')
            path.write_text(json.dumps(data))
            for script in ['check_certificate.py','audit_verify.py']:
                cmd=[sys.executable,str(ROOT/script),str(path)]
                if script=='audit_verify.py':
                    cmd.append('--only-contractions')
                result=subprocess.run(cmd,text=True,capture_output=True,timeout=45)
                if result.returncode==0 or 'FAIL:' not in result.stderr:
                    raise RuntimeError(f'Unexpected acceptance/crash: {name}, {script}\n'
                                       +result.stdout+result.stderr)
                print('PASS:',name,'rejected by',script)
                print('     ',result.stderr.strip())
                total+=1
    print(f'ALL {total} CORRUPTION-REJECTION TESTS PASSED.')

if __name__=='__main__':
    main()
