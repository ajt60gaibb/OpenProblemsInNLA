#!/usr/bin/env python3
"""Second implementation of the MI-18 order-four finite checks.

Requires Python 3.10+ and SymPy 1.14.0. This file does NOT import the original
checker. It independently expands the entire polynomial in q (not a list of
permutation coefficients), obtains tensor Bernstein matrices by solving a
polynomial change-of-basis system, and tests PSD by characteristic polynomials
rather than Schur complements. All arithmetic is exact.

For a real symmetric M, all eigenvalues are real, and M is PSD iff every
coefficient of det(x I + M) is nonnegative: a negative eigenvalue would give a
strictly positive root, impossible for a nonzero polynomial with nonnegative
coefficients. This criterion includes singular matrices.

The implementation was written in a separate audit pass by the same AI
assistant, not by an independent human reviewer. It is not a Lean proof.
"""
from __future__ import annotations
import argparse
from collections import defaultdict
from itertools import permutations, product
import json
from pathlib import Path
import sys
from typing import Any
import sympy as s

q, t, X = s.symbols('q t X', real=True)
PERMS = tuple(permutations(range(4)))
G = s.Matrix(4, 4, lambda i, j: s.Symbol(f'g{i}{j}'))
# Independent Hermitian parametrization for conjugation checks.
H = s.zeros(4)
for i in range(4):
    H[i, i] = s.Symbol(f'd{i}', real=True)
    for j in range(i+1, 4):
        u, v = s.symbols(f'r{i}{j} y{i}{j}', real=True)
        H[i, j], H[j, i] = u+s.I*v, u-s.I*v
BETA = [s.binomial(5,k)*t**k*(1-t)**(5-k) for k in range(6)]


def require(condition: Any, message: str) -> None:
    if not bool(condition):
        raise ValueError(message)


def length(p: tuple[int, ...]) -> int:
    """Lehmer digit sum, via successively removing values from a sorted list."""
    remaining = list(range(len(p)))
    total = 0
    for v in p:
        digit = remaining.index(v)
        total += digit
        remaining.pop(digit)
    return total


def permanent_q(A: s.Matrix) -> s.Expr:
    return s.Add(*(q**length(p)*s.prod(A[i,p[i]] for i in range(A.rows))
                   for p in permutations(range(A.rows))))


def parse_entry(entry: dict[str, Any]) -> tuple[list[s.Matrix],list[s.Matrix]]:
    den = entry['denominator']
    require(type(den) is int and den>0, 'denominator is not a positive integer')
    out = []
    for field, count, size in [('K',4,3),('L',None,2)]:
        values = entry[field]
        require(len(values)==count if count is not None else len(values) in (0,3),
                f'wrong number of {field} matrices')
        mats=[]
        for raw in values:
            require(len(raw)==size and all(len(row)==size for row in raw),
                    f'wrong {field} shape')
            require(all(type(v) is int for row in raw for v in row),
                    'non-integer matrix numerator')
            mats.append(s.Matrix(raw)/den)
        out.append(mats)
    return out[0],out[1]


def psd_charpoly(M: s.Matrix, label: str) -> list[s.Expr]:
    require(M==M.T, f'{label}: matrix is not real symmetric')
    require(all(v.is_Rational for v in M), f'{label}: nonrational entry')
    coefficients = (-M).charpoly(X).all_coeffs()  # det(X*I+M)
    require(all(c>=0 for c in coefficients),
            f'{label}: negative coefficient in det(X*I+M)')
    return coefficients


def full_tensor_matrices(K: list[s.Matrix]) -> list[tuple[int,int,s.Matrix]]:
    # Explicit index relabeling for the recorded reversal symmetry. No claim
    # that a general simultaneous row/column permutation preserves P_q.
    J=s.Matrix([[0,0,1],[0,1,0],[1,0,0]])
    return [(0,+1,K[0]),(0,-1,K[1]),(1,+1,K[2]),(1,-1,K[3]),
            (2,+1,J*K[2]*J),(2,-1,J*K[3]*J),
            (3,+1,J*K[0]*J),(3,-1,J*K[1]*J)]


def contraction(A: s.Matrix, K: list[s.Matrix], L: list[s.Matrix],
                reflected: bool=False) -> s.Expr:
    """Use the two-term inner-product formula, not the original four-term code."""
    terms=[]
    for i,eps,M in full_tensor_matrices(K):
        js=[j for j in range(4) if j!=i]
        if reflected:
            eps=-eps
        for r,j in enumerate(js):
            k,l=[h for h in range(4) if h not in (i,j)]
            for u,jp in enumerate(js):
                kp,lp=[h for h in range(4) if h not in (i,jp)]
                weight=M[r,u]*((-1)**(r+u) if reflected else 1)
                terms.append(weight*A[j,i]*A[i,jp]*
                             (A[k,kp]*A[l,lp]+eps*A[k,lp]*A[l,kp]))
    require(not (reflected and L), 'reflection only asserted without scalar blocks')
    for h,M in enumerate(L,1):
        I=(0,h)
        J=tuple(v for v in range(4) if v not in I)
        matching=(J,tuple(reversed(J)))
        for r,u in product(range(2),repeat=2):
            terms.append(M[r,u]*s.prod(A[matching[r][a],I[a]]*
                                            A[I[a],matching[u][a]] for a in range(2)))
    return s.Add(*terms)


def inner_product_identity_checks() -> None:
    """Check conjugation in the complex Hermitian variables directly."""
    for i,j,jp,eps in product(range(4),range(4),range(4),(1,-1)):
        if i==j or i==jp:
            continue
        k,l=[u for u in range(4) if u not in (i,j)]
        kp,lp=[u for u in range(4) if u not in (i,jp)]
        # Four-term expansion of <(u+eps Fu)/sqrt2,(v+eps Fv)/sqrt2>.
        four=s.conjugate(H[i,j])*H[i,jp]*(
            H[k,kp]*H[l,lp]+eps*H[k,lp]*H[l,kp]+
            eps*H[l,kp]*H[k,lp]+H[l,lp]*H[k,kp])/2
        two=H[j,i]*H[i,jp]*(H[k,kp]*H[l,lp]+eps*H[k,lp]*H[l,kp])
        require(s.expand(four-two)==0,'complex tensor conjugation mismatch')
    print('PASS: complex-conjugation tensor identities in real/imaginary variables.')


def check_contractions(data: dict[str, Any]) -> None:
    derivative=s.diff(permanent_q(G),q)
    checked_psd=0
    for field,a,b in [('central_positive',s.S.Zero,s.Rational(3,4)),
                      ('upper_positive',s.Rational(3,4),s.S.One)]:
        section=data[field]
        require([s.Rational(v) for v in section['interval']]==[a,b],'wrong interval')
        require(len(section['coefficients'])==6,'wrong coefficient count')
        ordinary=[]
        reflected=[]
        for k,entry in enumerate(section['coefficients']):
            K,L=parse_entry(entry)
            require(len(L)==(0 if field=='central_positive' else 3),'wrong scalar blocks')
            for j,M in enumerate(K+L):
                psd_charpoly(M,f'{field}/{k}/{j}')
                checked_psd+=1
            ordinary.append(contraction(G,K,L))
            if field=='central_positive':
                reflected.append(contraction(G,K,L,reflected=True))
        rhs=sum(beta*value for beta,value in zip(BETA,ordinary))
        require(s.expand(rhs-derivative.subs(q,a+(b-a)*t))==0,
                f'{field}: whole-polynomial identity failed')
        print(f'PASS: whole-polynomial certificate on [{a}, {b}].')
        if field=='central_positive':
            rhs=sum(beta*value for beta,value in zip(BETA,reflected))
            require(s.expand(rhs-derivative.subs(q,-b*t))==0,
                    'central_negative: whole-polynomial identity failed')
            print(f'PASS: whole-polynomial certificate on [-{b}, 0].')
    print(f'PASS: {checked_psd} stored small matrices PSD by characteristic polynomials.')


def bernstein_change_of_basis() -> dict[int,list[s.Expr]]:
    # Solve B h = power coefficients; do not use the original closed formula.
    columns=[s.Matrix([s.expand(beta).coeff(t,r) for r in range(6)]) for beta in BETA]
    basis=s.Matrix.hstack(*columns)
    require(basis.det()!=0,'singular polynomial change of basis')
    out={0:[s.S.Zero]*6}
    for ell in range(1,7):
        p=s.Poly(ell*(-1+t/4)**(ell-1),t)
        rhs=s.Matrix([p.nth(r) for r in range(6)])
        h=basis.inv()*rhs
        require(s.expand(sum(BETA[k]*h[k] for k in range(6))-p.as_expr())==0,
                'change of basis reconstruction failed')
        out[ell]=list(h)
    return out


def check_tensor_blocks(report_path: Path | None = None) -> None:
    weights=bernstein_change_of_basis()
    words=tuple(product(range(3),repeat=4))
    by_type: dict[tuple[int,...],list[tuple[int,...]]]=defaultdict(list)
    for w in words:
        by_type[tuple(w.count(i) for i in range(3))].append(w)
    require(len(words)==81 and len(by_type)==15,'incomplete tensor space')
    records=[]
    representative=[]
    for count,block_words in sorted(by_type.items()):
        d=len(block_words)
        # Read matrix entries by the Kronecker-delta formula, rather than
        # applying a permutation to a column and using an image lookup.
        matrices=[s.zeros(d) for _ in range(6)]
        for r,v in enumerate(block_words):
            for c,w in enumerate(block_words):
                compatible=[p for p in PERMS if all(v[j]==w[p[j]] for j in range(4))]
                for k in range(6):
                    matrices[k][r,c]=sum(weights[length(p)][k] for p in compatible)
        for k,M in enumerate(matrices):
            coefficients=psd_charpoly(M,f'tensor {count}, {k}')
            zero_multiplicity=0
            for c in reversed(coefficients):
                if c!=0:
                    break
                zero_multiplicity+=1
            rank=d-zero_multiplicity
            record={'multiplicities':count,'k':k,'dimension':d,'rank':rank,
                    'det_XI_plus_M_coefficients':[str(v) for v in coefficients]}
            records.append(record)
            if count==(2,1,1):
                representative.append(rank)
        # Directly verify the operator polynomial, including all entries.
        for r,v in enumerate(block_words):
            for c,w in enumerate(block_words):
                direct=sum(length(p)*q**(length(p)-1) for p in PERMS
                           if length(p)>0 and all(v[j]==w[p[j]] for j in range(4)))
                rebuilt=sum(BETA[k]*matrices[k][r,c] for k in range(6))
                require(s.expand(rebuilt-direct.subs(q,-1+t/4))==0,
                        'tensor entry polynomial reconstruction mismatch')
    require(len(records)==90,'wrong tensor-block count')
    print('PASS: all 90 tensor blocks PSD by characteristic polynomials.')
    print('PASS: entrywise tensor polynomial reconstruction on [-1, -3/4].')
    print('Representative ranks:',representative)
    if report_path:
        report_path.write_text(json.dumps(records,indent=2)+'\n',encoding='utf-8')


def check_reduction_and_base() -> None:
    rho=s.Symbol('rho',real=True)
    perturbed=G.copy()
    perturbed[0,0]+=rho
    residual=permanent_q(perturbed)-permanent_q(G)-rho*permanent_q(G[1:,1:])
    require(s.expand(residual)==0,'first-diagonal/rank reduction identity failed')
    print('PASS: first-diagonal perturbation identity as a polynomial in arbitrary entries.')
    ar,ai,br,bi,cr,ci,dr,di,fr,fi=s.symbols('ar ai br bi cr ci dr di fr fi',real=True)
    a,b,c,d,f=[r+s.I*i for r,i in [(ar,ai),(br,bi),(cr,ci),(dr,di),(fr,fi)]]
    V=s.Matrix([[1,a,b],[0,c,d],[0,0,f]])
    A=V.conjugate().T*V
    abs2=lambda z:s.expand(s.conjugate(z)*z)
    rhs=(abs2((1+q)*a*s.conjugate(b)+c*s.conjugate(d))+
         abs2(a)*abs2(b)*(1+q)**2+abs2(a*d+q*b*c)+
         (abs2(a)+2*abs2(c))*abs2(b)*q**2+abs2(a)*abs2(f))
    require(s.expand(s.diff(permanent_q(A),q)-rhs)==0,'complex order-three SOS failed')
    print('PASS: order-three SOS identity for arbitrary complex a,b,c,d,f and real q.')
    # Strictness proof uses the usual determinant and the diagonal product.
    require(s.expand(permanent_q(G).subs(q,-1)-G.det())==0,'P_-1 is not determinant')
    require(s.expand(permanent_q(G).subs(q,0)-s.prod(G[i,i] for i in range(4)))==0,
            'P_0 is not the diagonal product')
    print('PASS: endpoint identities used in the strictness argument.')


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('certificate',nargs='?',type=Path,
                        default=Path(__file__).with_name('certificate.json'))
    parser.add_argument('--report',type=Path,help='write exact tensor characteristic polynomials')
    parser.add_argument('--only-contractions',action='store_true',help='quick mutation-test mode')
    args=parser.parse_args()
    data=json.loads(args.certificate.read_text(encoding='utf-8'))
    require(data['schema']=='mi18-order4-exact-certificate-v1','unexpected data schema')
    print('Audit implementation:',sys.version.split()[0],'; SymPy',s.__version__)
    check_contractions(data)
    if not args.only_contractions:
        inner_product_identity_checks()
        check_tensor_blocks(args.report)
        check_reduction_and_base()
    print('ALL SECOND-IMPLEMENTATION CHECKS PASSED.')


if __name__=='__main__':
    try:
        main()
    except (ValueError,KeyError,TypeError,OSError) as exc:
        print('FAIL:',exc,file=sys.stderr)
        sys.exit(1)
