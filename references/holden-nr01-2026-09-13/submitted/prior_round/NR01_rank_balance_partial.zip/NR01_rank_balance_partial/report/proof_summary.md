# Rank balance for regular-polygon slack matrices

**Partial resolution of NR-01.** This note proves the general lower bound below and the exact values `rank_+(S_n)=11` for `43 <= n <= 48`. It does not resolve the universal conjecture; n=17 remains between eight and nine. The full proof, construction, references, and exact-check explanation are in `nr01_rank_balance.pdf`.

## Theorem

For integers `r>d>=2`, let

\[
F(r,2a)=\binom{r-a}{a}+\binom{r-a-1}{a-1},\qquad
F(r,2a+1)=2\binom{r-a-1}{a}.
\]

If

\[
S_n(i,j)=\cos(\pi/n)-\cos((2i+1-2j)\pi/n)
\]

and `r=rank_+(S_n)`, then

\[
n\le F\left(r,\left\lfloor\frac{r+1}{2}\right\rfloor\right).
\]

## Proof

Write a minimum nonnegative factorization `S_n=WH`, and let `p=rank(W)` and `q=rank(H)` be the ordinary ranks. Every column of W and every row of H is nonzero; otherwise a zero outer-product term could be removed.

Set `theta=pi/n` and `c=cos(theta)`. Define vectors

\[
a_i=(\cos((2i+1)\theta),\sin((2i+1)\theta)),\qquad
b_j=(\cos(2j\theta),\sin(2j\theta)).
\]

The affine map `x -> c*1 - (a_i dot x)_i` takes the regular polygon with vertices b_j onto the convex hull of the columns of S_n. Its entire affine image intersects the nonnegative orthant in exactly that convex hull. This is because the inequalities `a_i dot x <= c` are precisely the polygon's supporting inequalities. The image has n vertices. The same statement for S_n transposed follows from the inequalities `b_j dot x <= c`, whose polygon has vertices a_i.

All row and column sums of S_n equal `kappa=n*cos(pi/n)>0`. The column affine hull has dimension two and lies in a nonzero constant-sum hyperplane, so `rank(S_n)=3`.

Let h_j denote the columns of H and set

\[
Q_H=\operatorname{aff}\{h_j\}\cap\mathbb R_+^r.
\]

The vector `ell=W^T*1` is strictly positive and `ell^T*h_j=kappa` for every j. Thus each point y of Q_H satisfies `0<=y_a<=kappa/ell_a`. The set is bounded. Its affine dimension is q−1, because the h_j span a q-dimensional linear space and lie in a nonzero constant-value hyperplane. Their average is strictly positive, so intersecting their affine hull with the orthant does not reduce dimension.

Within its affine hull, Q_H is defined by r coordinate inequalities and has at most r facets. Its linear image under W is exactly the column polygon: the image is nonnegative and in the correct affine hull, and it contains every column of S_n. Applying the same reasoning to `S_n^T=H^T W^T` yields a second bounded polytope Q_W of dimension p−1, with at most r facets, whose image is an n-vertex polygon.

McMullen's upper-bound theorem, after polarity, gives

\[
n\le F(r,q-1),\qquad n\le F(r,p-1).
\]

The ordinary-rank inequality gives

\[
3=\operatorname{rank}(WH)\ge p+q-r.
\]

Therefore `d=min(p−1,q−1)` satisfies `2<=d<=floor((r+1)/2)`. We have `n<=F(r,d)`.

On that dimension interval, F is nondecreasing. For consecutive even-to-odd and odd-to-even steps, respectively, its ratios are

\[
\frac{F(r,2a+1)}{F(r,2a)}=\frac{2(r-2a)}r,
\qquad
\frac{F(r,2a+2)}{F(r,2a+1)}
=\frac{r(r-2a-1)}{2(a+1)(r-a-1)}.
\]

The first is at least one when `r>=4a+1`. For the second, the numerator minus the denominator is `r^2−(4a+3)r+2(a+1)^2>0` when `r>=4a+3`. These are exactly the required endpoint conditions. This proves the theorem.

## Consequences and limits

The capacity at r=10 is `F(10,5)=2*binom(7,2)=42`. Since the known upper construction uses eleven terms for `33<=n<=48`, the exact value is eleven for every `43<=n<=48`.

The capacity B(r) in the theorem satisfies

\[
B(r)=\Theta(r^{-1/2}\rho^r),\qquad \rho=(27/4)^{1/4}.
\]

Consequently

\[
\operatorname{rank}_+(S_n)\ge
\frac{\log_2n}{\log_2\rho}
+\frac{\log_2\log_2n}{2\log_2\rho}-O(1),
\]

whose leading coefficient is approximately 1.4519649158. This is below the conjectured coefficient two.

At n=17 the bound gives only eight. Any hypothetical eight-term factorization must have `(p,q)` equal to `(5,5)`, `(5,6)`, or `(6,5)`. The present argument does not exclude those pairs. Failed numerical searches do not exclude them either.

## Sources

McMullen's upper-bound theorem is the external geometric theorem used in the proof: P. McMullen, *The maximum numbers of faces of a convex polytope*, Mathematika 17 (1970), 179–184, https://doi.org/10.1112/S0025579300002850.

The upper construction is due to A. Vandaele, N. Gillis, and F. Glineur, *On the Linear Extension Complexity of Regular n-gons*, Linear Algebra and its Applications 521 (2017), 217–239, https://arxiv.org/html/1505.08031.

The unrestricted-dimension counting bound and its asymptotic analysis are given by A. P. Goucha, J. Gouveia, and P. M. Silva, *On ranks of regular polygons*, https://arxiv.org/html/1610.09868v2. The original NR-01 statement and additional references are listed in `../sources.json`.
