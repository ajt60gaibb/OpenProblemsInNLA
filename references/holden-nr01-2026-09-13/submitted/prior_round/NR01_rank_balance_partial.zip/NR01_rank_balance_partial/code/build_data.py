"""Regenerate integer bound tables and the supplied exact-factor JSON files."""
from __future__ import annotations
import csv
import json
from pathlib import Path
from regular_polygon import (exact_expressions, balanced_capacity, balanced_lower,
                             ubt_capacity, geometric_lower, upper_bound)

ROOT = Path(__file__).resolve().parents[1]

def main() -> None:
    target = ROOT / 'data'
    target.mkdir(exist_ok=True)
    certdir = target / 'exact_factors'
    certdir.mkdir(exist_ok=True)
    for n in [17, *range(43,49)]:
        W,H = exact_expressions(n)
        record = {
            'format': 'NR01-exact-factorization-v1', 'n': n,
            'inner_dimension': len(H),
            'matrix': 'S[i,j]=cos(pi/n)-cos((2*i+1-2*j)*pi/n); zero-based indices',
            'entry_grammar': {
                'zero': '0', 'one': '1', 'sin': 'sin(angle*pi/n)',
                '2sin': '2*sin(angle*pi/n)',
                'c': 'cos(pi/n)-cos((2*angle+1)*pi/n)'
            },
            'W': [[[e.kind,e.angle] for e in row] for row in W],
            'H': [[[e.kind,e.angle] for e in row] for row in H]
        }
        (certdir/f'n{n}_rank{len(H)}.json').write_text(json.dumps(record,indent=2)+'\n')
    with (target/'rank_capacity.csv').open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['r','balanced_dimension','rank_balance_capacity_B','unrestricted_UBT_capacity_M'])
        for r in range(3,129):
            writer.writerow([r,(r+1)//2,balanced_capacity(r),ubt_capacity(r)])
    with (target/'bounds_n3_to4096.csv').open('w',newline='') as f:
        writer=csv.writer(f)
        writer.writerow(['n','rank_balance_lower','unrestricted_UBT_lower','known_upper_U','bounds_match'])
        for n in range(3,4097):
            lo,up=balanced_lower(n),upper_bound(n)
            writer.writerow([n,lo,geometric_lower(n),up,int(lo==up)])
    print('Wrote seven exact factor certificates and two integer bound tables.')

if __name__=='__main__':
    main()
