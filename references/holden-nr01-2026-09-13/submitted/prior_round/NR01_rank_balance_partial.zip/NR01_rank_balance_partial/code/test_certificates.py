"""Regression checks. These supplement, and do not replace, the written proof."""
from __future__ import annotations
import unittest
from pathlib import Path
from math import comb
import numpy as np
from regular_polygon import *
from verify_exact import verify, verify_file, verify_factors

ROOT=Path(__file__).resolve().parents[1]

class Certificates(unittest.TestCase):
    def test_invalid_n(self):
        for n in (0,1,2,-1,3.5,True):
            with self.assertRaises(ValueError):
                upper_bound(n)

    def test_upper_fold_count(self):
        for n in range(3,8193):
            ell=n; terms=0
            while ell>4:
                ell=(ell+1)//2; terms+=2
            self.assertEqual(terms+ell,upper_bound(n))

    def test_monotonic_dimension_window(self):
        for r in range(3,257):
            values=[cyclic_facets(r,d) for d in range(2,(r+1)//2+1)]
            self.assertEqual(values,sorted(values))
            self.assertLessEqual(balanced_capacity(r),ubt_capacity(r))
            self.assertLessEqual(balanced_capacity(r),balanced_capacity(r+1))

    def test_parity_formulas(self):
        for m in range(1,65):
            self.assertEqual(3*balanced_capacity(4*m),4*comb(3*m,m))
            self.assertEqual(balanced_capacity(4*m+1),2*comb(3*m,m))
            self.assertEqual(balanced_capacity(4*m+2),2*comb(3*m+1,m))
            self.assertEqual((3*m+2)*balanced_capacity(4*m+3),
                             (4*m+3)*comb(3*m+2,m+1))

    def test_finite_result_and_remaining_gap(self):
        self.assertEqual(balanced_capacity(10),42)
        for n in range(43,49):
            self.assertEqual(balanced_lower(n),11)
            self.assertEqual(upper_bound(n),11)
        self.assertEqual((balanced_lower(17),upper_bound(17)),(8,9))
        for n in range(3,4097):
            self.assertLessEqual(geometric_lower(n),balanced_lower(n))
            self.assertLessEqual(balanced_lower(n),upper_bound(n))

    def test_exact_small_cases(self):
        for n in range(3,33):
            self.assertTrue(verify(n)['exact_polynomial_identity'])

    def test_supplied_certificates(self):
        names=list((ROOT/'data'/'exact_factors').glob('*.json'))
        self.assertEqual(len(names),7)
        for name in names:
            self.assertTrue(verify_file(str(name))['exact_polynomial_identity'])

    def test_tampered_factor_is_rejected(self):
        W,H=exact_expressions(17)
        W[0]=[ZERO]*len(H)
        with self.assertRaises(AssertionError):
            verify_factors(17,W,H)

    def test_floating_point_sanity_not_a_proof(self):
        for n in range(3,65):
            W,H=factorization(n)
            self.assertGreaterEqual(W.min(),0)
            self.assertGreaterEqual(H.min(),0)
            self.assertLess(np.max(np.abs(W@H-slack(n))),1e-11)

if __name__=='__main__':
    unittest.main(verbosity=2)
