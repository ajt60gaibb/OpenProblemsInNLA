"""Reproducible heuristic only. Failure is NOT a nonnegative-rank lower bound.

Cyclic HALS from random starts, followed by bounded L-BFGS polishing.
No floating-point output of this script is an exact-factorization certificate.
"""
from __future__ import annotations
import argparse, json, time
from pathlib import Path
import numpy as np
from numba import njit
from scipy.optimize import minimize
from regular_polygon import slack, factorization, upper_bound

@njit(cache=True)
def hals(S, W, H, sweeps):
    n, r = W.shape
    R = S - W @ H
    for it in range(sweeps):
        for k in range(r):
            den = 0.0
            for j in range(n): den += H[k,j]*H[k,j]
            if den > 1e-28:
                for i in range(n):
                    z=0.0
                    for j in range(n): z += R[i,j]*H[k,j]
                    v=max(0.0,W[i,k]+z/den)
                    d=v-W[i,k]; W[i,k]=v
                    for j in range(n): R[i,j]-=d*H[k,j]
        for k in range(r):
            den = 0.0
            for i in range(n): den += W[i,k]*W[i,k]
            if den > 1e-28:
                for j in range(n):
                    z=0.0
                    for i in range(n): z+=R[i,j]*W[i,k]
                    v=max(0.0,H[k,j]+z/den)
                    d=v-H[k,j]; H[k,j]=v
                    for i in range(n): R[i,j]-=W[i,k]*d
        if it%100==0:
            # Rescale to avoid pathological column/row magnitudes.
            for k in range(r):
                a=0.0; b=0.0
                for i in range(n): a += W[i,k]*W[i,k]
                for j in range(n): b += H[k,j]*H[k,j]
                if a>1e-28 and b>1e-28:
                    z=(b/a)**.25
                    for i in range(n): W[i,k]*=z
                    for j in range(n): H[k,j]/=z
            R=S-W@H
    return W,H


def polish(S,W,H,maxiter):
    n,r=W.shape; m=n*r
    def objective(x):
        w=x[:m].reshape(n,r); h=x[m:].reshape(r,n)
        res=w@h-S
        return .5*np.sum(res*res), np.r_[(res@h.T).ravel(),(w.T@res).ravel()]
    ans=minimize(objective,np.r_[W.ravel(),H.ravel()],jac=True,method='L-BFGS-B',
                 bounds=[(0,None)]*(2*m),
                 options={'maxiter':maxiter,'ftol':1e-15,'gtol':1e-12,'maxls':40,'maxcor':30})
    return ans.x[:m].reshape(n,r), ans.x[m:].reshape(r,n), bool(ans.success)


def run(n,r,starts,sweeps,polish_iters,seed):
    S=slack(n); norm=np.linalg.norm(S); rng=np.random.default_rng(seed)
    W0,H0=factorization(n)
    records=[]; best=None; t0=time.perf_counter()
    for start in range(starts):
        if start < W0.shape[1] and r==W0.shape[1]-1:
            inds=[j for j in range(W0.shape[1]) if j!=start]
            W=W0[:,inds].copy()+1e-4*rng.random((n,r))
            H=H0[inds,:].copy()+1e-4*rng.random((r,n))
            init='remove_known_term'
        else:
            W=rng.random((n,r)); H=rng.random((r,n))
            z=(S.mean()/((W@H).mean()))**.5; W*=z; H*=z
            init='random'
        W,H=hals(S,W,H,sweeps)
        W,H,success=polish(S,W,H,polish_iters)
        rel=float(np.linalg.norm(W@H-S)/norm)
        records.append({'start':start,'initialization':init,'relative_frobenius_residual':rel,
                        'optimizer_success':success})
        if best is None or rel<best[0]: best=(rel,W.copy(),H.copy())
        print(f'n={n} r={r} start={start} residual={rel:.12g} best={best[0]:.12g}',flush=True)
    result={'n':n,'target_inner_dimension':r,'seed':seed,'starts':starts,'hals_sweeps':sweeps,
            'polish_maxiter':polish_iters,'elapsed_seconds':time.perf_counter()-t0,
            'best_relative_frobenius_residual':best[0],'runs':records,
            'status':'heuristic only; no lower-bound conclusion; no exact certificate'}
    return result,best[1],best[2]

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('n',type=int); ap.add_argument('r',type=int)
    ap.add_argument('--starts',type=int,default=32); ap.add_argument('--sweeps',type=int,default=10000)
    ap.add_argument('--polish',type=int,default=3000); ap.add_argument('--seed',type=int,default=17012026)
    ap.add_argument('--out',required=True)
    a=ap.parse_args()
    result,W,H=run(a.n,a.r,a.starts,a.sweeps,a.polish,a.seed)
    Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
    np.savez_compressed(str(Path(a.out).with_suffix('.npz')),W=W,H=H,n=a.n,r=a.r)
