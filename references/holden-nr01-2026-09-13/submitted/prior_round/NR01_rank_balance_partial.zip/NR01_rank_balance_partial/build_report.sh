#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error -output-directory report report/nr01_rank_balance.tex
pdflatex -interaction=nonstopmode -halt-on-error -output-directory report report/nr01_rank_balance.tex
