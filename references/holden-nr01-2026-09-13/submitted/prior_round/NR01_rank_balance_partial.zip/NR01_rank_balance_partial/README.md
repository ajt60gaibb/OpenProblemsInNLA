# NR-01 — rank-balance proof package

**Status: partial resolution, not a complete solution of NR-01.**

The main result proved in this package is

\[
\operatorname{rank}_+(S_n)=11\qquad(43\le n\le48),
\]

where `S_n(i,j) = cos(pi/n) - cos((2*i+1-2*j)*pi/n)` with zero-based indices. A general rank-balance lower bound and its asymptotic consequence are proved as well. The universal conjecture is not proved or disproved here; in particular the remaining example is `8 <= rank_+(S_17) <= 9`.

## Start here

Read **`report/nr01_rank_balance.pdf`**, the ten-page mathematical report. Its LaTeX source is included. `report/proof_summary.md` is a shorter readable statement of the main proof.

The report gives the full orthant-section argument, the ordinary-rank coupling, the upper-bound-theorem calculation, the finite exact-rank corollary, the asymptotic estimate, and an explicit trigonometric construction of the known upper factors. It distinguishes the proof from numerical experiments and identifies the missing universal inequality.

There is no claim of priority or external peer review. The lower bound is a written mathematical proof, not a proof-assistant formalization.

## Results

For

\[
F(r,2a)=\binom{r-a}{a}+\binom{r-a-1}{a-1},\qquad
F(r,2a+1)=2\binom{r-a-1}{a},
\]

define `B(r) = F(r, floor((r+1)/2))`. The proved implication is

\[
r=\operatorname{rank}_+(S_n)\quad\Longrightarrow\quad n\le B(r).
\]

Since `B(10)=42` and the known upper construction uses eleven terms for `33 <= n <= 48`, the exact value eleven follows for all six values `43 <= n <= 48`.

Writing `rho=(27/4)^(1/4)`, the asymptotic consequence is

\[
\operatorname{rank}_+(S_n)\ge
\frac{\log_2n}{\log_2\rho}
+\frac{\log_2\log_2n}{2\log_2\rho}-O(1).
\]

The leading coefficient is approximately `1.451964915757438`, rather than the conjectured coefficient two. The comparison is with the unrestricted-dimension upper-bound-theorem counting bound, not a claim to dominate every other lower bound.

## Reproduce the certificates

Use Python 3.10 or later. From this directory:

```bash
python -m pip install -r requirements.txt
python code/test_certificates.py
python code/verify_exact.py --certificate data/exact_factors/n48_rank11.json
python code/verify_exact.py --through 256 --json checks/recomputed_exact.json
```

The retained exact check covers **254 matrices and 5,625,211 entry identities**, namely every `3 <= n <= 256`. All nine regression tests passed, including all supplied certificate files and deliberate rejection of a corrupted factor.

The checker reduces integer polynomials modulo `z^(2*n)+1`, with `z=exp(pi*i/(2*n))`. It verifies `(2W)(2H)=4S_n` exactly and checks nonnegativity by integer angle ranges. It does not infer exactness from a floating-point residual. The trigonometric proof in the report covers all n; the finite check is not extrapolated into a universal proof.

Seven algebraic factor files are included under `data/exact_factors/`: nine-term factors for `n=17`, and eleven-term factors for `n=43,44,45,46,47,48`. An entry is stored as `[kind, angle]`, with its grammar stated in each file. **The n=17 certificate is an upper-bound witness, not a proof of minimality.**

To regenerate these files and the bound tables:

```bash
python code/build_data.py
python code/regular_polygon.py 48 --save data/factors_n48_numeric.npz
```

The NPZ output contains floating-point approximations for convenience. Its exact counterpart is the JSON expression file.

## Optional heuristic searches

```bash
python -m pip install -r requirements-search.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/search_numeric.py 17 8 \
  --starts 32 --sweeps 20000 --polish 10000 --seed 17012026 \
  --out checks/search_n17_r8_recomputed.json
```

The retained eight-term search for n=17 found best relative Frobenius residual `0.003743350210148726`. A completed eleven-term n=49 search found `0.0005890675385643861`. An eight-start, nine-term n=17 random benchmark also failed, despite nine-term exact factors being explicitly available. These results illustrate the limits of the heuristic. They are not lower-bound certificates, counterexamples, or proofs of nonexistence.

Individual starts, initialization types, optimization budgets, seeds, and termination flags are in the search JSON files. Floating-point results and elapsed times may differ across platforms. No global infeasibility solver was used.

## File roles

| Path | Contents |
|---|---|
| `report/nr01_rank_balance.pdf` | Complete mathematical report, with explicit partial-status statement |
| `report/nr01_rank_balance.tex` | Editable LaTeX source |
| `report/proof_summary.md` | Short statement and proof of the main lower bound |
| `code/regular_polygon.py` | Exact angle-expression construction; numerical evaluation; integer bounds |
| `code/verify_exact.py` | Exact integer-polynomial identity checker |
| `code/test_certificates.py` | Nine regression tests |
| `code/build_data.py` | Regenerates algebraic factor files and bound tables |
| `code/search_numeric.py` | Optional heuristic only |
| `data/exact_factors/` | Seven exact algebraic upper-bound witnesses |
| `data/bounds_n3_to4096.csv` | Bounds from this note and the known upper formula; not all best-known ranks |
| `data/rank_capacity.csv` | Exact integer capacities for r=3 through 128 |
| `checks/` | Verification results, test output, heuristic output, environment metadata |
| `sources.json` | Primary-source titles, versions, URLs, and roles |
| `MANIFEST.sha256` | Checksums for the files in this package |

To compile the report, run `bash build_report.sh` with a LaTeX installation providing the packages listed in its source. The PDF is already included; no compilation is necessary to read it.

The substantive external geometric input is McMullen's upper-bound theorem. The upper construction is credited to Vandaele–Gillis–Glineur. Bibliographic details and the repository statement are in the report and `sources.json`. No remote repository files were modified.
