# Source and search notes

Source-check date: 2026-09-12 (the conversation date).

The canonical NM-01 entry and repository contribution/status criteria were read through the public website. No GitHub plugin was used and no repository write was performed. The live canonical page was consulted; this package does not claim to be pinned to an immutable repository commit.

The search concentrated on the exact NM-01 model, sufficient-scattering identifiability, facet-based recovery, maximum-volume inscribed ellipsoids, and rational bit complexity. It was targeted rather than exhaustive. Representative queries included polynomial minimum-volume factorization under sufficient scattering, the SSC-checking problem, and the complexity of maximum-volume inscribed ellipsoids.

The note distinguishes prior ingredients from the developments proved in the package. In particular, simplex-facet information under SSC and the facet-enumeration/MVIE framework are established literature, not discoveries first claimed here.

## Access limits

The author-hosted Gillis book PDF could not be retrieved successfully. The exact SSC convention and the book definition/theorem/page locators were checked against the canonical repository entry, and the relevant identifiability facts were proved directly in the note. The book is not represented as having been read in full.

For Grötschel–Lovász–Schrijver, the publisher record and chapter locations were checked. The general rounded rational ellipsoid procedure is explicitly stated as a standard external algorithmic dependency. Its entire book proof is not reproduced or claimed to have been reverified here; the note proves that its input-size, boundedness, interior-ball, and rational-oracle requirements hold for the reduced problem.

Lin et al., Abdolali–Gillis, Barbarino–Gillis–Saha, and the SSC-checking work were inspected through their arXiv pages. Vandenberghe–Boyd–Wu was read through the author-hosted PDF; its relevant pages were also rendered through the web screenshot tool. Primary publisher information was used for the Anstreicher result.

A recent polarity-process preprint, arXiv:2609.10888v1, was checked as an additional status search. It starts from an inequality-described polytope and its outer convergence estimates are instance dependent. It is not used as a proof dependency or as an algorithm that resolves NM-01.

No located source supplied a complete resolution of the exact target. This search result is not a proof that no such work exists. The reason this package is partial is the explicit remaining algorithmic dependence, not the age or open status of the question.

No third-party books or papers are redistributed in this ZIP. `SOURCE_MAP.json` contains bibliographic locators and usage notes.
