# Exact examples

Regenerate these JSON files with `python3 code/make_examples.py` from the package root.
All rational numbers are stored as exact strings. The solver inputs have `X`, `r`,
and `tau` keys. Support indices are zero-based original column indices.

| Input or construction | Purpose and associated files |
|---|---|
| `capped_rank3.json` | Strongly SSC, six columns, optimum exactly 1. `_result.json` includes optimal factors and a support certificate; `_certificate_check.json` accepts it at equality. |
| `capped_rank3_below.json` | The same data with threshold `1-2^-80`. The result is NO and the value-one support certificate is rejected. |
| `local_trap_rank3.json` | Explicit factors for the same data at a strict nonglobal local minimum of value `625/256`, compared with global value 1. This is a construction record, not a solver input. Strictness is proved in Theorem 6.2. |
| `weak_ssc_rank3.json` | Satisfies the repository's SSC but not the stronger dual-boundary convention. The result has optimum 1; `_check.json` records four boundary vertices and the two SSC verdicts. |
| `fixed_surplus_rank8.json` | A nonseparable, strongly SSC rank-eight instance with nine columns. The optimum is 1. Both exact solution and small-instance SSC checks are included. |
| `signed_rectangular_rank3.json` | A rational 5-by-6 data matrix generated from a signed, rectangular W. The threshold equals its Gram determinant. `_known_factors.json` supplies the generating factors and certificate check. |
| `many_facets_rank7.json` | Strongly SSC rank-seven data with 54 columns. The construction certificate lists and exactly checks 20 distinct additional facets. This does not enumerate every facet. The global value is 1 by the proved construction. |

The supplied reference solver is exponential in variable rank. In particular, do
not use the many-facet input as a casual benchmark for complete enumeration. Its
construction certificate can instead be regenerated with `make_examples.py` or
checked with `families.certify_extra_facets(3)`.

A feasible support certificate is **not** an independent global-optimality
certificate. The promised-input theorem and exhaustive reference search justify
the solver's optimum on the small solved examples. The many-facet example uses
the separate mathematical construction theorem.
