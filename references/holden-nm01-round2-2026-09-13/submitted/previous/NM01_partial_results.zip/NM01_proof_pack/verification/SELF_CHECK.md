# Self-check record and limits

This is a record of checks performed by the same assistant that produced the
argument. It is **not** an independent audit, external peer review, or formal
proof-assistant verification.

## Mathematical correspondence checks

The written argument retains the exact orthogonal-cone SSC2 in the repository.
It does not substitute the stronger dual-boundary condition, presume rational
hidden factors, presume supplied factors, or impose nonnegativity on W. The
extra-boundary-ray example explicitly separates the SSC conventions.

The rationality argument was checked through the full chain: SSC1 forces rank
r-1 on each hidden facet; rational data give rational facet normal directions;
column normalization determines all positive row scales by a rational linear
system; the inverse factor and Gram determinant have polynomial bit lengths.
The finite threshold gap includes equality and uses the input threshold's own
encoding length.

The exact algorithm's uniform exponent was checked separately from the size of
its facet list. Its polynomial fixed-surplus bound uses
`binomial(n,r-1) = binomial(n,n-r+1)` and is a statement about the theoretical
ellipsoid algorithm, not the executable facet-set enumeration.

The convex optimization reduction includes an explicit full-dimensional interior
ball, bounded eigenvalues, rational LMI separation, and a rational strong cut for
determinant superlevel sets. It distinguishes a thin feasible set from an empty
one and allows the standard rounded ellipsoid routine to return a no-interior-
ball conclusion. No general exact-SDP claim is made. The rounded ellipsoid
primitive itself is cited from standard literature and is not implemented here.

The strict local-trap proof checks the whole linearized feasible cone, not only
a sampled direction. The exponential-facet construction checks affine
independence and exact supporting equalities, not merely candidate hyperplanes.
Neither result is interpreted as a hardness proof for arbitrary algorithms.

## Executed checks

`test_run.log` records a successful run of 16 test methods. Its parameterized
subcases include exact factor recovery, signed rectangular rational factors,
threshold equality and offsets of 2^-80, invalid inputs and certificates, weak
versus strong SSC, local-trap feasibility and directional identities, and the
ellipsoid determinant formula.

The many-facet construction is checked directly for ranks 3, 5, 7, 9, and 11,
certifying respectively 2, 6, 20, 70, and 252 distinct additional facets. These
are counts of specifically certified facets, not full hull counts. The general
exponential statement is justified by the paper's proof rather than tests.

`example_generation.log` records generation of 18 JSON example files.
`cli_checks.log` records actual command-line certificate acceptance at value one
and rejection at the threshold 1-2^-80. All mathematical computations in these
checks use exact rational arithmetic.

`pdf_check.json` records a successful 20-page PDF build, no undefined references
or overfull boxes, and visual inspection of the final rendered pages. Rendering
checks do not establish mathematical correctness.

## Remaining target

Uniform polynomial-time exact decision in total input length L alone is not
proved. No promise-preserving hardness reduction is proved. The sharper rational
ellipsoid algorithm is not implemented. No complete-solution or formal-
verification status is justified by this package.
