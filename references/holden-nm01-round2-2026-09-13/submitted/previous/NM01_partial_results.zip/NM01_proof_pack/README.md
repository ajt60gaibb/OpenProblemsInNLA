# NM-01: exact arithmetic, tractable regimes, and obstructions

**This is a partial-results package, not a complete solution of NM-01.**

The full question—uniform polynomial-time exact decision when rank is part of the input—is not settled here. The package contains written proofs, an exact rational reference implementation, certificates, counterexample families, and reproducible checks. No repository changes have been made.

## Read first

Start with **`paper/nm01_note.pdf`**. Its executive statement and Section 9 distinguish established results from the remaining question. The editable source is **`paper/nm01_note.tex`**. **`STATUS.md`** gives a compact claim-and-gap assessment.

The strongest theoretical algorithm proved in the note has bit complexity

\[
\left(L+\binom{n}{r-1}\right)^{O(1)},
\]

where the exponent is universal and `L` is the binary input length. This is polynomial for any fixed rank, and also for any fixed surplus `n-r`, with rank unrestricted in the latter case. It is **not** uniformly polynomial for arbitrary rank and surplus.

The proof also establishes rational optimal factors and a polynomial-bit rational optimum on every promised input; short polynomial-time-verifiable YES certificates; and a precise reduction between exact threshold decision and high-precision value approximation. The rationality proof does not assume that the real factors in the promise are supplied or rational.

Two explicit strongly scattered families rule out shortcuts: one has strict nonglobal local minima; another has polynomial-size rational input but exponentially many data-hull facets. These are not a hardness proof for the general decision problem.

## Executable scope

`code/nm01_exact.py` implements the **slower reference search** of Proposition 3.3, not the sharper theoretical algorithm of Theorem 5.2. It enumerates facet supports and sets of `r` facets, doing all arithmetic with Python's standard-library `fractions.Fraction`. Its general bound is

\[
\binom{n}{r-1}^{r}\operatorname{poly}(L).
\]

The rounded rational ellipsoid subroutine used in the sharper algorithm is **not implemented** here. The paper explicitly checks the assumptions of that standard algorithmic primitive and gives a rational separating oracle for determinant superlevel sets.

The reference solver does not check the SSC promise. Its correctness guarantee applies on promised inputs. On unpromised inputs, any candidate it returns is feasible, but the reported minimum among its facet-supported candidates need not be the unrestricted global optimum.

The support-certificate verifier checks **feasibility and the supplied threshold**, not optimality or SSC. The optional `check_ssc_small` function is an exponential small-instance checker used in tests, not part of a claimed polynomial-time algorithm.

## Run

Python 3.10 or later is sufficient; no third-party package is required. The recorded tests used the Python version in `verification/environment.json`.

From this directory:

```sh
python3 code/test_nm01.py
python3 code/make_examples.py
python3 code/nm01_exact.py examples/capped_rank3.json --output /tmp/nm01_result.json
python3 code/nm01_exact.py examples/capped_rank3.json --verify /tmp/nm01_result.json
```

The last command should report `"accepted": true` and `"candidate_value": "1"`. A certificate for value one is correctly rejected if the threshold is lowered below one.

Input JSON has the form:

```json
{
  "r": 3,
  "tau": "1",
  "X": [
    ["3/4", "3/4", "1/4", "0", "1/4", "0"],
    ["1/4", "0", "3/4", "3/4", "0", "1/4"],
    ["0", "1/4", "0", "1/4", "3/4", "3/4"]
  ]
}
```

Use integers or rational strings. Floating-point JSON numbers are rejected to avoid silently changing exact data. Support indices in certificates are **zero-based** and refer to original input columns. `tau` is optional for optimization but required for certificate verification.

`code/families.py` generates the capped simplex, the weak-but-not-strong SSC example, a nonseparable fixed-surplus-one family, and the explicitly certified exponential-facet family.

## Examples and verification

`examples/INDEX.md` describes the supplied JSON inputs, results, and construction certificates. The exact tests cover threshold equality, thresholds separated by `2^-80`, signed rectangular factors, duplicate data, invalid input/certificates, both SSC conventions, the local-trap identities, and the extra-facet construction.

The recorded test run passes **16 test methods**, with multiple parameterized cases. `verification/test_run.log` is actual terminal output and `verification/test_results.json` records the computed values. The extra-facet checks certify respectively 2, 6, 20, 70, and 252 proposed facets for ranks 3, 5, 7, 9, and 11. The general statements are supported by the proofs in the paper, not by extrapolation from tests.

This is self-checked AI-generated work. It has not been independently audited, peer reviewed, or formally verified. The reference algorithms and examples are supplementary evidence, not a proof-assistant certificate.

## Rebuild the PDF

From `paper/`, run twice:

```sh
pdflatex -interaction=nonstopmode -halt-on-error nm01_note.tex
```

The source uses standard LaTeX packages and contains no external figures. The delivered PDF was compiled and visually inspected using rendered pages. `verification/pdf_check.json` records the final checks.

## Provenance and status

The canonical NM-01 statement was read through the website, not a GitHub plugin. The note preserves sign-unrestricted `W`, column-normalized nonnegative `H`, the exact orthogonal-cone form of SSC2, real hidden factors, and the rational bit model. It does not replace the repository's second condition with a stronger dual-boundary assumption.

`sources/SOURCE_MAP.json` and `sources/SEARCH_NOTES.md` list primary sources, locations, and access limitations. The facet and ellipsoid frameworks have substantial prior literature; this package does not claim invention of those frameworks or exhaustive novelty checking.

The unresolved issue is **uniform polynomial complexity**, not rational representability or threshold equality. A partial-resolution submission could be considered after mathematical review; this package does not justify marking NM-01 solved.

`MANIFEST.sha256` lists SHA-256 hashes of packaged files. It excludes itself. The outer ZIP checksum, when supplied, is separate. Re-running tests or rebuilding the PDF can change logs or PDF metadata, so check the manifest before regenerating artifacts.
