"""Exact rational families used in the NM-01 note and tests."""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from math import comb
from nm01_exact import Matrix, eye, transpose, matmul, rank


def capped_simplex(r: int, u: F = F(3, 4)) -> Matrix:
    """Vertices of {h>=0, sum h=1, h_i<=u}; requires 1/2<u<1."""
    if r < 3 or not F(1, 2) < u < 1:
        raise ValueError('Require r>=3 and 1/2<u<1.')
    columns = []
    for i in range(r):
        for j in range(r):
            if i == j:
                continue
            col = [F(0)]*r
            col[i], col[j] = u, 1-u
            columns.append(col)
    return transpose(columns)


def one_cap_weak_ssc(r: int) -> Matrix:
    """SSC in Gillis's orthogonal sense but not the stronger dual-boundary sense."""
    if r < 3:
        raise ValueError('Require r>=3.')
    cols = []
    for j in range(1, r):
        v = [F(0)]*r
        v[j] = F(1)
        cols.append(v)
        v = [F(0)]*r
        v[0], v[j] = F(2, r), F(r-2, r)
        cols.append(v)
    return transpose(cols)


def local_trap(r: int, u: F = F(3, 4)) -> tuple[Matrix, Matrix, F]:
    alpha = r*u-1
    if r < 3 or not max(F(1, 2), F(2, r)) < u < 1:
        raise ValueError('Require max(1/2,2/r)<u<1.')
    t = [[u-(alpha if i == j else 0) for j in range(r)] for i in range(r)]
    a = [[(u-(1 if i == j else 0))/alpha for j in range(r)] for i in range(r)]
    return t, a, alpha**(2*(r-1))


def polynomial_from_roots(roots: list[int]) -> list[int]:
    """Coefficients c_0,...,c_d of prod(t-root)."""
    coeff = [1]
    for root in roots:
        new = [0]*(len(coeff)+1)
        for j, c in enumerate(coeff):
            new[j] -= root*c
            new[j+1] += c
        coeff = new
    return coeff


def many_facets(k: int) -> tuple[Matrix, dict]:
    """Rank r=2k+1, O(r^2) vertices, >=binom(2k,k) explicit extra facets.

    The matrix contains capped_simplex(r,3/4), hence satisfies the stronger
    SSC. Construction and all scale bounds are proved in the paper.
    """
    if k < 1:
        raise ValueError('Require k>=1.')
    d, r, ncurve = 2*k, 2*k+1, 4*k
    u, delta = F(3, 4), F(1, 16)
    eta = F(1, 64*r*ncurve**d)
    zeta = eta/F(64*(ncurve+1)**d)
    base = capped_simplex(r, u)
    cols = transpose(base)
    base_count = len(cols)
    for t in range(1, ncurve+1):
        w = delta-zeta*t**d
        rest = (1-u-w)/d
        col = [u+w]+[rest+eta*t**j for j in range(1, d)]
        col.append(rest-eta*sum(t**j for j in range(1, d)))
        assert sum(col) == 1 and min(col) > 0
        cols.append(col)
    return transpose(cols), {
        'k': k, 'r': r, 'd': d, 'ncurve': ncurve,
        'u': u, 'delta': delta, 'eta': eta, 'zeta': zeta,
        'base_count': base_count, 'guaranteed_extra_facets': comb(2*k, k)
    }


def explicit_extra_facets(k: int):
    """Yield rational homogeneous normals and their known support indices."""
    h, info = many_facets(k)
    r, d = info['r'], info['d']
    u, delta, eta, zeta = (info[s] for s in ('u','delta','eta','zeta'))
    for blocks in combinations(range(1, 2*k+1), k):
        roots = [t for b in blocks for t in (2*b-1, 2*b)]
        coeff = polynomial_from_roots(roots)
        def slack(col):
            w = col[0]-u
            z = [col[j]-(1-col[0])/d for j in range(1, d)]
            return delta+zeta*coeff[0]+(zeta/eta)*sum(
                coeff[j]*z[j-1] for j in range(1, d))-w
        normal = [slack(col) for col in eye(r)]
        support = [info['base_count']+t-1 for t in roots]
        yield normal, support, roots


def certify_extra_facets(k: int) -> dict:
    h, info = many_facets(k)
    cols = transpose(h)
    count = 0
    normals = set()
    for normal, support, roots in explicit_extra_facets(k):
        slacks = [sum(a*b for a,b in zip(normal,col)) for col in cols]
        assert min(slacks) >= 0
        assert {i for i, s in enumerate(slacks) if s == 0} == set(support)
        assert rank([[h[i][j] for j in support] for i in range(info['r'])]) == info['d']
        scale = next(x for x in normal if x)
        normalized = tuple(x/scale for x in normal)
        assert normalized not in normals
        normals.add(normalized)
        count += 1
    assert count == info['guaranteed_extra_facets']
    return {'rank': info['r'], 'columns': len(h[0]),
            'extra_facets_exactly_certified': count,
            'ssc_reason': 'contains the strictly SSC capped-simplex base',
            'optimal_value': '1'}


def fixed_surplus_one(r: int) -> Matrix:
    """A nonseparable, strongly SSC family with n=r+1 and arbitrary r>=3."""
    if r < 3:
        raise ValueError('Require r>=3.')
    base = [[F(0),F(0),F(3,4),F(3,4)],
            [F(1),F(0),F(1,4),F(0)],
            [F(0),F(1),F(0),F(1,4)]]
    out = [[F(0)]*(r+1) for _ in range(r)]
    for i in range(3):
        out[i][:4] = base[i]
    for i in range(3,r):
        out[i][i+1] = F(1)
    return out
