#!/usr/bin/env python3
"""Exact arithmetic tests; not formal proof or independent mathematical audit."""
from __future__ import annotations
import json
from fractions import Fraction as F
from pathlib import Path
import random
import unittest
from math import comb
from nm01_exact import *
from families import *

ROOT = Path(__file__).resolve().parents[1]
RECORDS = []


def record(name, **kwargs):
    RECORDS.append({'test': name, **kwargs})


def sorted_columns(a):
    return sorted(tuple(col) for col in transpose(a))


class ExactTests(unittest.TestCase):
    def test_01_linear_algebra(self):
        a=matrix([[2,1,0],[-1,3,2],[4,0,1]])
        self.assertEqual(matmul(a,inverse(a)),eye(3))
        self.assertEqual(determinant(a),F(15))
        self.assertEqual(rank(a),3)

    def test_02_rank_two_signed_embedding(self):
        w=matrix([[2,-3],[-1,2],[4,1]])
        h=matrix([[1,0,'1/3','4/5'],[0,1,'2/3','1/5']])
        x=matmul(w,h)
        value=determinant(matmul(transpose(w),w))
        out=solve(x,2,value)
        self.assertEqual(F(out['value']),value)
        self.assertEqual(out['answer'],'YES')
        self.assertEqual(sorted_columns(matrix(out['W'])),sorted_columns(w))
        record('rank_two_signed',value=str(value))

    def test_03_capped_simplex_exact(self):
        for r in (3,4,5):
            with self.subTest(r=r):
                h=capped_simplex(r)
                out=solve(h,r,F(1))
                self.assertEqual(out['value'],'1')
                self.assertTrue(check_ssc_small(h)['strong_ssc'])
                self.assertEqual(out['facets'],2*r)
                self.assertTrue(verify_support_certificate(h,r,F(1),out['support_certificate'])['accepted'])
                self.assertFalse(verify_support_certificate(h,r,F(999,1000),out['support_certificate'])['accepted'])
                record('capped_simplex',rank=r,value=out['value'],facets=out['facets'],candidate_sets=out['candidate_sets_examined'])

    def test_04_weak_not_strong(self):
        for r in (3,4,5):
            h=one_cap_weak_ssc(r)
            check=check_ssc_small(h)
            self.assertTrue(check['weak_ssc'])
            self.assertFalse(check['strong_ssc'])
            self.assertEqual(check['boundary_vertices'],r+1)
            out=solve(h,r)
            self.assertEqual(out['value'],'1')
            record('weak_not_strong',rank=r,**check)

    def test_05_boundary_nonuniqueness(self):
        h=capped_simplex(3,F(2,3))
        check=check_ssc_small(h)
        self.assertTrue(check['ssc1'])
        self.assertFalse(check['weak_ssc'])
        self.assertEqual(solve(h,3)['value'],'1')
        record('ssc1_without_weak_ssc',**check)

    def test_06_failed_ssc1(self):
        h=matrix([['1/2','1/2',0],['1/2',0,'1/2'],[0,'1/2','1/2']])
        self.assertFalse(check_ssc_small(h)['ssc1'])

    def test_07_exact_thresholds(self):
        h=capped_simplex(3)
        for delta,ans in ((-F(1,2**80),'NO'),(F(0),'YES'),(F(1,2**80),'YES')):
            self.assertEqual(solve(h,3,F(1)+delta)['answer'],ans)
        record('thresholds',values=['1-2^-80','1','1+2^-80'],answers=['NO','YES','YES'])

    def test_08_signed_rational_recovery(self):
        rng=random.Random(91827)
        for r in (3,4,5):
            for trial in range(2):
                top=[[F(0)]*r for _ in range(r)]
                for i in range(r):
                    for j in range(i+1):
                        top[i][j]=F((i+2) if i==j else rng.randrange(-4,5),i+j+2)
                bottom=[[F(rng.randrange(-5,6),j+2) for j in range(r)] for _ in range(2)]
                w=top+bottom
                h=capped_simplex(r)
                x=matmul(w,h)
                val=determinant(matmul(transpose(w),w))
                out=solve(x,r,val)
                self.assertEqual(F(out['value']),val)
                self.assertEqual(sorted_columns(matrix(out['W'])),sorted_columns(w))
                self.assertEqual(out['answer'],'YES')
                record('signed_rational_recovery',rank=r,trial=trial,value=str(val))

    def test_09_invalid_input(self):
        with self.assertRaises(InputError):matrix([[0.1,1],[1,0]])
        for bad in (None, 3, 'bad', [1, 2], [[1], [1, 2]]):
            with self.assertRaises(InputError):matrix(bad)
        self.assertFalse(check_ssc_small(matrix([[1,1],[0,0]]))['ssc1'])
        with self.assertRaises(InputError):reduce_input(matrix([[1,2],[2,4]]),2)
        with self.assertRaises(InputError):reduce_input(matrix([[1,0,1],[0,1,1]]),2)

    def test_10_unpromised_square(self):
        x=matrix([[0,1,1,0],[0,0,1,1],[1,1,1,1]])
        out=solve(x,3)
        self.assertEqual(out['status'],'no_facet_supported_simplex')
        record('unpromised_square',status=out['status'])

    def test_11_duplicate_data(self):
        h=capped_simplex(3)
        h2=[row+row[:2] for row in h]
        self.assertEqual(solve(h2,3)['value'],'1')

    def test_12_bad_certificate(self):
        h=capped_simplex(3)
        out=solve(h,3)
        cert=out['support_certificate']
        cert[0]=[0,0]
        self.assertFalse(verify_support_certificate(h,3,F(1),cert)['accepted'])

    def test_13_local_trap_identities(self):
        for r in (3,4,6,9):
            h=capped_simplex(r)
            t,a,value=local_trap(r)
            self.assertEqual(matmul(t,a),eye(r))
            ht=matmul(a,h)
            self.assertTrue(all(v>=0 for row in ht for v in row))
            self.assertTrue(all(sum(col)==1 for col in transpose(ht)))
            self.assertEqual(determinant(matmul(transpose(t),t)),value)
            self.assertGreater(value,1)
            # Check the exact directional derivative along a feasible segment.
            dd=[[F(i==j)-a[i][j] for j in range(r)] for i in range(r)]
            active=[F(3,4)*dd[i][i]+F(1,4)*dd[i][j] for i in range(r) for j in range(r) if i!=j]
            alpha=F(3*r,4)-1
            derivative=sum(matmul(t,dd)[i][i] for i in range(r))
            self.assertEqual(derivative,-sum(active))
            self.assertLess(derivative,0)
            record('local_trap',rank=r,global_value='1',strict_local_value=str(value),feasibility_exact=True)

    def test_14_exponential_facets(self):
        for k in range(1,6):
            result=certify_extra_facets(k)
            self.assertEqual(result['extra_facets_exactly_certified'],comb(2*k,k))
            record('exponential_facets',**result)

    def test_15_fixed_surplus_nonseparable(self):
        for r in (3,5,8,12):
            h=fixed_surplus_one(r)
            self.assertEqual(len(h[0])-r,1)
            self.assertTrue(check_ssc_small(h)['strong_ssc'])
            out=solve(h,r)
            self.assertEqual(out['value'],'1')
            self.assertNotIn(tuple(eye(r)[0]),sorted_columns(h))
            record('fixed_surplus_nonseparable',rank=r,columns=r+1,value=out['value'])

    def test_16_ellipsoid_determinant_identity(self):
        for r in range(2,8):
            d=r-1
            # An arbitrary invertible affine map, homogenized to T.
            z=[[F(i+2) if i==j else F(0) for j in range(d)]+[F(i-2,3)] for i in range(d)]
            t=z+[[1-sum(z[i][j] for i in range(d)) for j in range(r)]]
            self.assertNotEqual(determinant(t),0)
            p=[[F(i==j)-F(1,r) for j in range(r)] for i in range(r)]
            g=matmul(matmul(z,p),transpose(z))
            g=[[v/F(r*(r-1)) for v in row] for row in g]
            self.assertEqual(r*(r*(r-1))**d*determinant(g),determinant(t)**2)
        record('ellipsoid_value_identity',ranks=list(range(2,8)),arithmetic='exact rationals')


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(ExactTests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    payload={'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
             'verification_level':'exact computational checks; not formal verification or independent audit',
             'records':RECORDS}
    (ROOT/'verification'/'test_results.json').write_text(json.dumps(payload,indent=2)+'\n')
    raise SystemExit(0 if result.wasSuccessful() else 1)
