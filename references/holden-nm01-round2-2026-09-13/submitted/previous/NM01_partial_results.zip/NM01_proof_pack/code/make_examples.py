#!/usr/bin/env python3
"""Regenerate the exact JSON examples. No third-party dependencies.

This exercises the reference search only on small instances. The rank-seven
many-facet construction is certified directly, not solved by exhaustive search.
"""
from __future__ import annotations
from fractions import Fraction as F
from pathlib import Path
import json
from typing import Any
from nm01_exact import (matrix, matmul, transpose, determinant, solve,
                        check_ssc_small, verify_support_certificate)
from families import (capped_simplex, local_trap, one_cap_weak_ssc,
                      fixed_surplus_one, many_facets, explicit_extra_facets,
                      certify_extra_facets)

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'examples'


def encode(value: Any) -> Any:
    if isinstance(value, F):
        return str(value)
    if isinstance(value, dict):
        return {str(k): encode(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    return value


def write(name: str, value: Any) -> None:
    (OUT / name).write_text(json.dumps(encode(value), indent=2) + '\n')


def instance(name: str, h, r: int, tau: F = F(1)) -> dict:
    write(name + '.json', {'r': r, 'tau': tau, 'X': h})
    result = solve(h, r, tau)
    write(name + '_result.json', result)
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    h = capped_simplex(3)
    result = instance('capped_rank3', h, 3)
    write('capped_rank3_certificate_check.json',
          verify_support_certificate(h, 3, F(1), result['support_certificate']))
    below = F(1)-F(1, 2**80)
    instance('capped_rank3_below', h, 3, below)
    write('capped_rank3_below_certificate_check.json',
          verify_support_certificate(h, 3, below, result['support_certificate']))

    t, a, local_value = local_trap(3)
    write('local_trap_rank3.json', {
        'rank': 3, 'u': F(3,4), 'X': h,
        'global_W': [[F(i == j) for j in range(3)] for i in range(3)],
        'global_H': h, 'global_value': F(1),
        'strict_local_W': t, 'inverse_change_of_coordinates': a,
        'strict_local_H': matmul(a, h), 'strict_local_value': local_value,
        'claim': 'Strict nonglobal local minimum; proof is Theorem 6.2, not just these identities.'
    })
    weak = one_cap_weak_ssc(3)
    instance('weak_ssc_rank3', weak, 3)
    write('weak_ssc_rank3_check.json', check_ssc_small(weak))

    surplus = fixed_surplus_one(8)
    instance('fixed_surplus_rank8', surplus, 8)
    write('fixed_surplus_rank8_check.json', check_ssc_small(surplus))

    w = matrix([[2, 0, 0], [-1, '3/2', 0],
                ['1/3', '-2/5', '5/4'], [1, -2, 3], [-1, 0, '1/2']])
    x = matmul(w, h)
    optimum = determinant(matmul(transpose(w), w))
    result = instance('signed_rectangular_rank3', x, 3, optimum)
    assert F(result['value']) == optimum
    write('signed_rectangular_rank3_known_factors.json', {
        'W': w, 'H': h, 'value': optimum,
        'certificate_check': verify_support_certificate(
            x, 3, optimum, result['support_certificate'])
    })

    k = 3
    many, info = many_facets(k)
    write('many_facets_rank7.json', {'r': info['r'], 'tau': F(1), 'X': many})
    facet_records = [{'normal': normal, 'support': support, 'roots': roots}
                     for normal, support, roots in explicit_extra_facets(k)]
    write('many_facets_rank7_construction_certificate.json', {
        'construction_parameters': info,
        'exact_checks': certify_extra_facets(k),
        'extra_facets': facet_records,
        'scope': 'Each listed facet is checked. No full hull enumeration is claimed.',
        'global_optimum_reason': 'Contains a strongly SSC capped-simplex base and lies in the standard simplex.'
    })
    print(json.dumps({'example_json_files': len(list(OUT.glob('*.json'))),
                      'status': 'generated; exact assertions passed'}, indent=2))


if __name__ == '__main__':
    main()
