# Status assessment

**Full NM-01 target: NOT RESOLVED BY THIS PACKAGE.**

## Established in the written argument

| Claim | Scope | Paper location |
|---|---|---|
| Minimum-volume identifiability under the precise repository SSC | Real promised factors; unrestricted-sign W | Theorem 2.2 |
| Full rank of the data on each hidden simplex facet | SSC1 alone | Lemma 2.3 |
| Rational optimal factors and a polynomial-bit rational optimum | All promised rational inputs | Theorem 3.1 |
| Explicit nonzero threshold gap | All promised rational inputs | Corollary 3.2 |
| Exact exhaustive rational reference search | Exponential in variable rank | Proposition 3.3 |
| Polynomial-size YES certificates; PromiseNP | Certificates certify feasibility/threshold, not optimality | Theorem 3.4 |
| Exact decision/high-precision value reduction | Bit complexity; equality handled; no factor-recovery equivalence | Proposition 3.5 |
| Ellipsoid determinant formula | SSC1 suffices; extra contacts allowed | Theorem 4.2 |
| Exact decision in `(L + binomial(n,r-1))^O(1)` time | Theoretical algorithm with a universal exponent | Theorem 5.2 |
| Fixed rank and fixed surplus `n-r` are polynomial-time regimes | Polynomial runtime on all inputs for each restricted promise problem | Theorem 5.2 |
| Strict nonglobal local minima | Explicit strongly SSC inputs, all r >= 3 | Theorem 6.2 |
| Exponentially many facets for polynomial-size promised inputs | Does not prove general decision hardness | Theorem 7.1 |
| Weak SSC need not have only coordinate dual-boundary rays | Explicit normalized rational examples | Proposition 8.1 |

## Exact remaining gap

No algorithm in the package decides the entire promise problem in time polynomial in `L` alone. The best theoretical running time still depends polynomially on `binomial(n,r-1)`, which can be exponential in variable rank. The package also does not establish a promise-preserving NP-hardness reduction or another negative resolution of the full complexity question.

The exponential-facet family disproves a polynomial output-size bound for full enumeration. It does not show that an algorithm must enumerate the facets. Its optimal value is intentionally easy. The strict local-trap family disproves a benign-landscape argument, not the existence of every possible global algorithm.

## Implementation and evidence level

The executable implements exhaustive rational facet-set search, not the sharper ellipsoid-based algorithm. The sharper proof uses the standard rounded rational ellipsoid feasibility method with explicit radius, size, and oracle bounds. That general primitive has not been implemented here.

Sixteen exact-arithmetic test methods pass. This is not formal verification, an independent audit, or external peer review. Source and mathematical provenance are recorded; no claim of exhaustive novelty checking is made.

## Repository interpretation

The relevant result is a **partial-resolution candidate for review**, not a complete-resolution claim. The repository's exact status vocabulary is `Partially resolved` for established partial cases and `Solved` for a complete published or independently audited resolution. The package does not justify `Solved`, `Solution claimed` for the full target, or `Lean verified`.

The repository has not been edited. Any status change should preserve the original problem and explicitly record the still-unresolved variable-rank polynomial-time target.
