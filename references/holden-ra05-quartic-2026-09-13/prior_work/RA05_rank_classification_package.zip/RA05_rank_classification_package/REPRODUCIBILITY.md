# Reproducing the package

## Environment used

The recorded full suite used Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, and SymPy 1.14.0. The exact quartic certificate checker requires only the Python standard library. The code uses a fixed random seed (20260913). Floating-point values may differ slightly across hardware or library versions; exact Fraction/SymPy identities must agree exactly.

LaTeX: pdfTeX from TeX Live, with geometry, lmodern, microtype, amsmath, amssymb, amsthm, mathtools, bm, booktabs, array, longtable, enumitem, fancyhdr, xcolor, hyperref, and needspace. The shipped PDF has 21 pages. Compiling can change PDF metadata and therefore its hash even without a mathematical change.

## Verify shipped bytes first

    python code/check_manifest.py

This checks every path listed in SHA256SUMS and makes no file changes. The manifest deliberately does not hash itself. Files generated later under an additional output directory are not part of the manifest.

## Exact finite lower-bound witness

    python code/check_exact_certificate.py

The checker reads `results/exact_group_certificate.json`. It verifies all four projectors, their integer identities, actual Euclidean residual costs, and exact relative errors. It also verifies that the tested support 12 is below the theorem's bound 36 at epsilon=1/56. It uses integer arithmetic and Python Fraction; NumPy and SymPy are not involved in this independent computational route. This is a separate checker, not independent human review.

Do not use `python -O`, because assertion statements are intentional test failures.

## Full finite suite

    python -m pip install -r requirements.txt
    OPENBLAS_NUM_THREADS=1 python code/verify.py --out /tmp/ra05_rank_recheck

This generates a fresh report and all small certificates at the supplied location. Using a separate output directory preserves the hashes of the shipped records. `./run_checks.sh` combines manifest verification, the exact certificate check, and the full suite; an optional first argument chooses the fresh output directory.

Expected result: `passed: true`, `checks: 1881`.

The elapsed runtime is informational and is not expected to reproduce exactly. The recorded report enumerates the check counts by category; they are not independent checks of the entire proof.

## Build the manuscript

    make pdf

Run three passes to resolve cross-references and the table of contents. `make clean` removes build intermediates and Python bytecode without deleting the manuscript PDF. Because recompilation changes file hashes, verify the shipped manifest before compiling or retain an untouched copy of the archive.

## Reference construction APIs

`mub_groups(h)` produces the explicit quartic core and assigned orthonormal auxiliary bases. `group_matrix` materializes the resulting rows, while `group_cost` evaluates a hyperplane cost without requiring a dense projector.

`quartic_witness` assumes a complete real MUB core, as returned by `mub_groups`. It uses the factorized MUB kernel identity and does not allocate the M-by-M kernel. This structural precondition is not established by merely passing arbitrary arrays of the correct shape. The witness's four candidate normals are unit normals of actual hyperplanes.

`conic_reduce_exact(points,p)` uses SymPy rationals to preserve the full homogeneous degree-p moment vector, for even p. It is a small-instance reference implementation and has no claimed efficient worst-case running time.

`dense_cubic_core()` constructs 20 rational unit vectors in four dimensions with independent cubic feature vectors. This is a finite illustration of denser cores; it does not instantiate the conservative asymptotic random-core conditions.

## What is not computationally reproduced

The code does not implement a general restricted-invertibility algorithm, BSS sparsification, or Banaszczyk coloring. It does not certify all vectors in a continuum by random sampling. The proof of positive-probability core and Haar-basis events is analytic. The uniform upper/lower theorems rest on the manuscript and identified external premises, not on empirical success of small examples.

## Prior work

The previous continuation ZIP is preserved byte-for-byte and contains its own sources, results, and nested earlier package. Its old test counts are not added to the 1,881 new checks. This continuation reruns the new suite; retention of a prior archive is not a claim that every old test was rerun in the final packaging step.
