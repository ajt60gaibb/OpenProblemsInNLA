# The unresolved part of RA-05

## Distinguish the two functions

S_p(k,epsilon) allows arbitrary input rank. T_p(k,epsilon) restricts rank(A) to at most k+1. Both use the same nonnegative original-row model and the same rank-at-most-k queries.

For even p=2s>=4, the package determines T_p up to p-dependent constants:

    min{k^s epsilon^-2, k^(s+1/2) epsilon^-1, k^(2s)}.

The equivalence with all linear-form preservation depends on the intrinsic-rank assumption. For arbitrary input rank q, a hyperplane inside the row span has dimension q-1, which may exceed k. Consequently the equivalence does not identify the full strong-coreset class with a (k+1)-dimensional embedding problem.

## Concrete surviving separations

Ignoring constants and logarithms in the imported upper bound:

| p | epsilon | proved lower for S_p | imported upper for S_p |
|---|---------|----------------------|------------------------|
| 4 | k^(-1/4) | k^(5/2) | k^(5/2) |
| 4 | k^(-1) | k^(7/2) | k^4 |
| 4 | k^(-2) | k^5 | k^6 |
| 6 | k^(-1) | k^(9/2) | k^5 |

The second and third rows have genuine polynomial rank gaps. The first row is a matching-order unrestricted regime already consistent with the earlier package. The rank-restricted classification fills its entire accuracy range, but does not eliminate those arbitrary-rank gaps.

## Why tempting transfers do not complete the proof

1. Projecting every input row into a low-rank subspace changes the rows and loses uncontrolled residual and interaction terms. A coreset for these modified points is not automatically a coreset of the original points.
2. Exact homogeneous moments give a bound depending on the actual row rank, not the query rank. The full problem permits that actual rank to grow with accuracy.
3. The earlier unbounded-noise construction keeps query rank fixed, but must reduce auxiliary amplitude to control baseline cost. Its derivative bound consequently loses a factor of the rank in the support lower bound. The new bounded-rank construction does not justify removing that loss for unbounded noise dimension.
4. For non-even p, the finite-difference proof still balances an epsilon/t observation error against a t^(p-1) Taylor remainder. Its exponent is 2-2/p, not 2. Even-power polynomial interpolation cannot simply be reused.
5. Constants in fixed-dimensional embedding theorems can depend on the dimension. Such results do not by themselves determine a joint bound with constants depending only on fixed p.

These are documented limitations, not asserted impossibility results. No upper bound matching the current maximum of lower bounds is claimed.
