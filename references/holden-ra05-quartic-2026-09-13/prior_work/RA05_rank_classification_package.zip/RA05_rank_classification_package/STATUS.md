# Status and claim boundaries

## Original RA-05 entry

**Proposed status: Partially resolved (PARTIAL), subject to mathematical review.**

The canonical target quantifies over arbitrary input matrices and every fixed real p > 2. This package does not give matching worst-case upper and lower bounds for that entire target. It does not authorize marking the entry SOLVED or treating the unrestricted size formula as determined.

The live canonical page was read through its public website, not a GitHub plugin. It reported Open during this continuation. No remote edits or pull requests were made.

## Complete restricted result supplied here

Theorem 1.1 determines, with constants depending only on p, the joint worst-case size at every accuracy for every even p >= 4, restricted to rank(A) <= k+1. Its proof includes both upper and lower bounds. All upper bounds use nonnegative original-row weights, preserve every legal subspace cost, and allow arbitrary ambient dimension with the stated intrinsic-rank restriction.

This is a mathematical completeness claim about the specified restricted theorem in the manuscript. It is not a claim that an independent reviewer has accepted the proof.

## Other results supplied here

Theorem 1.2 gives a lower envelope for all real p > 2. The explicit quartic theorem gives finite constants and actual hyperplane witnesses. The proposed subsidiary RA-05 formula is refuted separately for each fixed p > 2. The previous all-rank lower bound k/(144*4^p*epsilon^2) is reproved in Appendix C.

## What is not supplied

No matching arbitrary-rank upper bound in the surviving regimes; no non-even-power joint classification; no proof that the maximum of the available lower bounds is also an upper bound; no general polynomial-time implementation of the three imported structural theorems; no proof-assistant formalization; no independent peer review or priority certification.

## Evidence level

The manuscript supplies mathematical proofs with explicitly identified external dependencies. An internal proof audit and 1,881 finite checks were completed. A separate checker validates a concrete quartic violation using integer and rational arithmetic. These are author-side checks and must not be described as independent verification. The asymptotic random-core and Haar-basis existence lemmas are not numerically certified by those finite examples.
