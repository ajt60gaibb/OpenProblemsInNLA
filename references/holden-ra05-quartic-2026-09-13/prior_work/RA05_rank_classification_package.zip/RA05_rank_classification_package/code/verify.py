#!/usr/bin/env python3
"""Finite algebraic, geometric, and exact-arithmetic verification suite.

No test claims to verify an asymptotic existence event, a continuum theorem by
finite sampling, or an implementation of BSS/Banaszczyk/restricted invertibility.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
from itertools import product
import json
from math import comb
from pathlib import Path
import platform
import sys
import time

import numpy as np
import sympy as sp
import scipy

from rank_classification import (
    conic_reduce_exact, dense_cubic_core, exact_mub_certificate, fraction_string,
    group_cost, group_matrix, mean_errors, mub_groups, quartic_witness,
    rational_features, symmetric_features)
from check_exact_certificate import check as check_certificate
from prior_ra05 import derivative_stencil


class Checks:
    def __init__(self):
        self.passed = 0
        self.categories = {}
    def test(self, condition, category, label):
        if not bool(condition):
            raise AssertionError(f'{category}: {label}')
        self.passed += 1
        self.categories[category] = self.categories.get(category,0)+1
    def close(self, a,b,category,label,rtol=1e-9,atol=1e-10):
        self.test(np.allclose(a,b,rtol=rtol,atol=atol),category,label)


def projection_cost(A, z, p, weights=None):
    z = np.asarray(z,float)/np.linalg.norm(z)
    Q = np.outer(z,z)
    res = A@Q
    values = np.linalg.norm(res,axis=1)**p
    return float(values.sum() if weights is None else values@np.asarray(weights).reshape(-1))


def run(out: Path) -> dict:
    start = time.perf_counter()
    out.mkdir(parents=True,exist_ok=True)
    c = Checks()
    rng = np.random.default_rng(20260913)
    # Orthogonal noise is private to each group, unlike earlier product code.
    for p in (2.1,2.5,3.,3.7,4.,5.,6.,8.):
        for r,M in ((3,5),(4,7),(8,11)):
            U = rng.normal(size=(M,r)); U /= np.linalg.norm(U,axis=1)[:,None]
            V = np.stack([np.linalg.qr(rng.normal(size=(r,r)))[0].T for _ in range(M)])
            W = rng.uniform(0,3,size=(M,r)); W[rng.uniform(size=W.shape)<.5]=0
            H = mean_errors(V,W)
            c.close(np.sum(H*H),np.sum((W-1)**2)/r**2,'orthogonal_groups','exact isometry')
            B = np.einsum('jt,jtd->jd',W/r,V)
            c.close(np.sum(B*B),np.sum((W/r)**2),'orthogonal_groups','coefficient energy')
            masses=(W/r).sum(); m=np.count_nonzero(W)
            c.test(masses*masses <= m*np.sum(B*B)+1e-10,'orthogonal_groups','support Cauchy')
            A = group_matrix(U,V,p)
            for _ in range(12):
                x,y=rng.normal(size=(2,r)); z=np.r_[x,y]
                f=group_cost(U,V,x,y,p); fw=group_cost(U,V,x,y,p,W)
                c.close(f/np.linalg.norm(z)**p,projection_cost(A,z,p),
                        'geometry','original hyperplane cost')
                c.close(fw/np.linalg.norm(z)**p,projection_cost(A,z,p,W),
                        'geometry','weighted hyperplane cost')
                if p in (4.,6.,8.):
                    def g(t): return group_cost(U,V,x,t*y,p,W)-group_cost(U,V,x,t*y,p)
                    ds=derivative_stencil(int(p))
                    fd=sum(float(a)*g(j) for j,a in enumerate(ds))
                    der=p*np.sum((U@x)*np.abs(U@x)**(p-2)*(H@y))
                    # Polynomial extraction at several large nodes has expected
                    # cancellation; scale the tolerance by the sum of magnitudes.
                    sc=sum(abs(float(a)*g(j)) for j,a in enumerate(ds))
                    c.test(abs(fd-der)<=1e-10*max(sc,1),'even_extraction','derivative stencil')
    # Symmetric lifts used by the BSS and moment upper bounds.
    for d in (2,3,4):
        for degree in (2,3,4,6):
            A=rng.normal(size=(9,d)); B=rng.normal(size=(7,d))
            FA,FB=symmetric_features(A,degree),symmetric_features(B,degree)
            c.test(FA.shape[1]==comb(d+degree-1,degree),'tensor_lifts','dimension')
            c.close(FA@FB.T,(A@B.T)**degree,'tensor_lifts','Gram identity',rtol=1e-8,atol=1e-8)
            c.close(np.sum(FA*FA,axis=1),np.sum(A*A,axis=1)**degree,
                    'tensor_lifts','norm identity',rtol=1e-8,atol=1e-8)
    # Explicit complete-MUB lower bound and actual violating hyperplanes.
    witnesses=[]
    for h in (1,2):
        U,V,meta=mub_groups(h); M,r=U.shape
        E=(U@U.T)**3
        c.close(E,(1-1/r)*np.eye(M)+(U@U.T)/r,'mub','cubic kernel')
        for _ in range(24):
            x=rng.normal(size=r)
            c.close(np.sum((U@x)**4),1.5*np.linalg.norm(x)**4,'mub','core fourth moment')
            c.close(np.sum(np.einsum('jtd,d->jt',V,x)**4)/r,
                    1.5*np.linalg.norm(x)**4,'mub','aggregate noise fourth moment')
        for label in ('single_per_group','half','signed','all_one'):
            W=np.ones((M,r))
            if label=='single_per_group': W[:]=0; W[:,0]=r
            if label=='half': W[:]=0; W[:,:r//2]=2
            if label=='signed': W=rng.normal(1,2,size=(M,r));W[rng.uniform(size=W.shape)<.4]=0
            witness=quartic_witness(U,V,W)
            if label=='all_one':
                c.test(witness['zero_mixed_error'],'witnesses','all-one zero control')
                continue
            A=group_matrix(U,V,4)
            for q in witness['candidates']:
                c.close(projection_cost(A,q['normal'],4),q['normal_cost'],
                        'witnesses','geometric original cost')
                c.close(projection_cost(A,q['normal'],4,W),q['weighted_normal_cost'],
                        'witnesses','geometric weighted cost')
            mx=max(q['relative_error'] for q in witness['candidates'])
            c.test(mx+1e-10>=witness['mub_witness_lower_bound'],
                   'witnesses','constructive witness lower bound')
            witnesses.append({'h':h,'r':r,'M':M,'case':label,
                              'support':int(np.count_nonzero(W)),'maximum_relative_error':mx,
                              'derivative_witness_bound':witness['mub_witness_lower_bound']})
    # Exact conic reduction certifies genuine upper-bound examples.
    conic=[]
    for d,p,n in ((2,4,24),(3,4,24),(2,6,25)):
        raw=rng.integers(-3,4,size=(n,d))
        raw[np.all(raw==0,axis=1),0]=1
        pts=[[Fraction(int(a)) for a in row] for row in raw]
        w=conic_reduce_exact(pts,p)
        Phi=rational_features(pts,p)
        ws=sp.Matrix([sp.Rational(a.numerator,a.denominator) for a in w])
        c.test(all(a>=0 for a in w),'conic','nonnegative weights')
        c.test(sum(a!=0 for a in w)<=comb(d+p-1,p),'conic','support dimension')
        c.test(Phi.T*ws==Phi.T*sp.ones(n,1),'conic','exact full moment equality')
        for rank in range(d):
            for _ in range(8):
                Q,_=np.linalg.qr(rng.normal(size=(d,d)))
                P=Q[:,:rank]@Q[:,:rank].T
                vals=np.linalg.norm(raw@(np.eye(d)-P),axis=1)**p
                c.close(vals.sum(),vals@np.array([float(a) for a in w]),
                        'conic','Euclidean projection preservation',rtol=1e-8,atol=1e-8)
        cert={'p':p,'d':d,'n':n,'support':sum(a!=0 for a in w),
              'points':raw.tolist(),'weights':[fraction_string(a) for a in w]}
        path=out/f'exact_moment_coreset_d{d}_p{p}.json'
        path.write_text(json.dumps(cert,indent=2)+'\n')
        conic.append({k:cert[k] for k in ('p','d','n','support')})
    # A denser finite core has more groups than r^(p/2) at p=4.
    pts,meta=dense_cubic_core()
    Phi=rational_features(pts,3)
    c.test(Phi.rank()==20,'dense_core','exact rational cubic rank')
    c.test(all(sum(x*x for x in a)==1 for a in pts),'dense_core','exact unit norms')
    U=np.array([[float(a) for a in row] for row in pts]); E=(U@U.T)**3
    meta['numerical_minimum_cubic_gram_eigenvalue']=float(np.linalg.eigvalsh(E)[0])
    meta['asymptotic_event_certified']=False
    meta['unit_vectors']=[[fraction_string(a) for a in row] for row in pts]
    (out/'dense_cubic_core.json').write_text(json.dumps(meta,indent=2)+'\n')
    # Finite exhaustive balancing diagnostics, NOT a Banaszczyk implementation.
    balancing=[]
    for p in (4,6):
        d,n=3,12
        U=rng.normal(size=(n,d));U/=np.linalg.norm(U,axis=1)[:,None]
        F=symmetric_features(U,p)
        signs=np.array([[1]+list(v) for v in product((-1,1),repeat=n-1)],dtype=float)
        signs=signs[np.abs(signs.sum(axis=1))<=1]
        tensors=signs@F
        sq=np.sum(tensors*tensors,axis=1)
        j=int(np.argmin(sq)); chi=signs[j]
        disc=float(np.sqrt(sq[j]));count=int(chi.sum())
        c.test(abs(count)<=30,'balancing','cardinality discrepancy')
        # This Euclidean tensor bound certifies all unit x in this example.
        c.test(disc<=60*np.sqrt(p*d),'balancing','global polynomial bound via tensor norm')
        select=chi<0 if np.sum(chi<0)<=np.sum(chi>0) else chi>0
        c.test(np.count_nonzero(select)<=n/2,'balancing','minority support')
        for _ in range(20):
            x=rng.normal(size=d);x/=np.linalg.norm(x)
            error=2*np.sum((U[select]@x)**p)-np.sum((U@x)**p)
            c.test(abs(error)<=disc+1e-9,'balancing','actual halving error')
        balancing.append({'p':p,'d':d,'n':n,'support_after_halving':int(select.sum()),
                          'tensor_norm_discrepancy':disc,'cardinality_discrepancy':count,
                          'all_unit_queries_certified_by':'tensor Cauchy-Schwarz',
                          'algorithm':'exhaustive finite coloring, not an asymptotic implementation'})
    # Lewis-position inequalities for explicit isotropic data and its inverse image.
    U,_,meta=mub_groups(1);d=4;w=np.full(len(U),1/(d/2+1))
    T=rng.normal(size=(d,d))+4*np.eye(d)
    A=(U@np.linalg.inv(T).T)*(w**.25)[:,None]
    c.close(np.einsum('i,ij,ik->jk',w,U,U),np.eye(d),'lewis','isotropy')
    for _ in range(50):
        x=rng.normal(size=d)
        f=np.sum(w*(U@x)**4)
        c.test(d**-1*np.linalg.norm(x)**4-1e-9<=f<=np.linalg.norm(x)**4+1e-9,
               'lewis','two-sided norm bounds')
        c.close(np.sum((A@(T.T@x))**4),f,'lewis','invertible-coordinate transfer')
    # Dimension-free constant-free algebra of optimizing the variable-core bound.
    ratios=[]
    for p in (3.,4.,6.,8.):
        s=p/2; beta=2 if p%2==0 else 2-2/p
        for r in (16.,64.,256.):
            for eps in np.geomspace(1e-12,.49,60):
                t=eps**(beta/2)
                L=min(r**(p-1),max(r**s,r**(s-.5)/t))
                val=L/(t*t*(1+L/r**s)**2+1/r)
                target=min(r**s/t**2,r**(s+.5)/t,r**p)
                ratio=val/target;ratios.append(ratio)
                c.test(ratio>=.19,'optimization','three-regime lower envelope')
    cert=exact_mub_certificate()
    (out/'exact_group_certificate.json').write_text(json.dumps(cert,indent=2)+'\n')
    exact=check_certificate(out/'exact_group_certificate.json')
    c.test(exact['passed'],'exact_certificate','separate integer/Fraction checker')
    (out/'exact_group_certificate_check.json').write_text(json.dumps(exact,indent=2)+'\n')
    report={'passed':True,'checks':c.passed,'categories':c.categories,
            'elapsed_seconds':time.perf_counter()-start,'python':platform.python_version(),
            'numpy':np.__version__,'scipy':scipy.__version__,'sympy':sp.__version__,
            'witnesses':witnesses,'conic_examples':conic,'balancing_examples':balancing,
            'optimization_minimum_ratio':min(ratios),
            'limitations':[
                'Finite checks supplement, and do not replace, proofs.',
                'No asymptotic random-core or Haar-basis event is certified by numerical sampling.',
                'BSS, restricted invertibility, and Banaszczyk are imported mathematical theorems.',
                'The finite coloring search is not a claimed implementation of general Banaszczyk balancing.',
                'No independent human review or proof-assistant verification is claimed.']}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=Path(__file__).resolve().parents[1]/'results')
    args=parser.parse_args()
    print(json.dumps(run(args.out),indent=2))
