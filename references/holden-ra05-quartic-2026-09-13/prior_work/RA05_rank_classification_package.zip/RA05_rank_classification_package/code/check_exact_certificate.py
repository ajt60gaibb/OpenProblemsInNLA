#!/usr/bin/env python3
"""Check the saved finite quartic witness using only Python integers/Fractions."""
from fractions import Fraction
import json
from pathlib import Path
import sys


def check(path: Path) -> dict:
    c = json.loads(path.read_text())
    A, den, w = c['matrix_numerators'], c['matrix_denominator'], c['weights']
    n, d = len(A), len(A[0])
    assert n == c['n'] and d == c['d'] and len(w) == n
    assert all(len(a) == d for a in A)
    support = sum(a != 0 for a in w)
    assert support == c['support']
    eps = Fraction(c['epsilon'])
    r, M = c['r'], c['M']
    bound = Fraction(M*r) * (1-196*r*eps*eps)
    assert bound == Fraction(c['support_lower_bound']) and support < bound
    reports = []
    for query in c['queries']:
        z = query['normal_numerator']
        nz = sum(a*a for a in z)
        assert nz == query['projector_denominator'] and nz > 0
        P = [[nz*int(i==j)-z[i]*z[j] for j in range(d)] for i in range(d)]
        assert all(P[i][j] == P[j][i] for i in range(d) for j in range(d))
        assert all(sum(P[i][q]*P[q][j] for q in range(d)) == nz*P[i][j]
                   for i in range(d) for j in range(d))
        assert sum(P[i][i] for i in range(d)) == nz*c['k']
        f, fw = Fraction(0), Fraction(0)
        for a, wi in zip(A,w):
            # Direct Euclidean residual, not the polynomial extraction surrogate.
            residual_num = [nz*a[i]-sum(P[i][j]*a[j] for j in range(d))
                            for i in range(d)]
            dist_sq = Fraction(sum(v*v for v in residual_num), den*den*nz*nz)
            f += dist_sq*dist_sq
            fw += wi*dist_sq*dist_sq
        err = abs(fw-f)/f
        assert f == Fraction(query['cost'])
        assert fw == Fraction(query['weighted_cost'])
        assert err == Fraction(query['relative_error']) and err > eps
        reports.append({'cost':str(f),'weighted_cost':str(fw),'relative_error':str(err),
                        'projector_rank':c['k']})
    return {'passed':True,'arithmetic':'Python integers and Fraction only',
            'n':n,'d':d,'support':support,'epsilon':str(eps),'support_bound':str(bound),
            'queries':reports}


if __name__ == '__main__':
    path = Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).resolve().parents[1]/'results/exact_group_certificate.json'
    print(json.dumps(check(path),indent=2))
