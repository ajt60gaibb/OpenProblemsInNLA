"""Finite constructions accompanying the RA-05 rank-restricted classification.

The existence proofs for asymptotic cores, BSS sparsification, and Banaszczyk
balancing are in the manuscript. Numerical diagnostics are not implementations
or certificates of those existence theorems.
"""
from __future__ import annotations

from fractions import Fraction
from itertools import combinations_with_replacement, product
from math import comb, factorial, gcd, isfinite, isqrt, lcm
from typing import Sequence

import numpy as np
import sympy as sp
from numpy.typing import NDArray

from prior_ra05 import real_mub

Array = NDArray[np.float64]


def _validate(u: Array, bases: Array, weights: Array | None = None):
    u, bases = np.asarray(u, float), np.asarray(bases, float)
    if u.ndim != 2:
        raise ValueError('core must be a matrix')
    M, r = u.shape
    if r < 1 or bases.shape != (M, r, r):
        raise ValueError('one r by r row-basis is required per core group')
    if not np.isfinite(u).all() or not np.isfinite(bases).all():
        raise ValueError('all input entries must be finite')
    if weights is not None:
        weights = np.asarray(weights, float)
        if weights.shape != (M, r) or not np.isfinite(weights).all():
            raise ValueError('weights must be finite with shape (M,r)')
    return u, bases, weights


def group_cost(u: Array, bases: Array, x: Array, y: Array, p: float,
               weights: Array | None = None) -> float:
    """Unnormalized-normal cost for rows r^(-1/p)(u_j,v_jt)."""
    u, bases, weights = _validate(u, bases, weights)
    M, r = u.shape
    if not isfinite(p) or p <= 2:
        raise ValueError('p must be finite and greater than two')
    x, y = np.asarray(x, float), np.asarray(y, float)
    if x.shape != (r,) or y.shape != (r,):
        raise ValueError('x,y must belong to the core and noise spaces')
    values = np.abs((u @ x)[:, None] + np.einsum('jtd,d->jt', bases, y)) ** p
    if weights is not None:
        values = values * weights
    return float(values.sum() / r)


def group_matrix(u: Array, bases: Array, p: float, *, scaled: bool = True) -> Array:
    u, bases, _ = _validate(u, bases)
    M, r = u.shape
    if not isfinite(p) or p <= 2:
        raise ValueError('p must be finite and greater than two')
    A = np.concatenate((np.repeat(u, r, axis=0), bases.reshape(M*r, r)), axis=1)
    return A * (r ** (-1.0/p) if scaled else 1.0)


def mean_errors(bases: Array, weights: Array) -> Array:
    bases, weights = np.asarray(bases, float), np.asarray(weights, float)
    if bases.ndim != 3 or weights.shape != bases.shape[:2]:
        raise ValueError('incompatible bases and weights')
    r = bases.shape[1]
    return np.einsum('jt,jtd->jd', (weights-1.0)/r, bases)


def mub_groups(h: int) -> tuple[Array, Array, dict]:
    """Explicit balanced orthogonal groups. Each complete MUB basis is used r times."""
    T, _, meta = real_mub(h)
    r, M = int(meta['r']), len(T)
    u = T / isqrt(r)
    blocks = u.reshape(M//r, r, r)
    assignment = np.arange(M) // r
    bases = blocks[assignment].copy()
    return u, bases, dict(meta, M=M, n=M*r, d=2*r,
                          noise_assignment=assignment.tolist())


def quartic_witness(u: Array, bases: Array, weights: Array) -> dict:
    """Construct four actual hyperplanes using the cubic-linear coefficient.

    The core must be a complete real mutually unbiased basis family as returned
    by ``mub_groups``. That structural precondition is not tested on arbitrary
    input arrays. For this family, a nonzero selected row exists whenever the
    candidate weights are not all one. The factorized MUB identity avoids an
    M-by-M allocation. The quantitative error certificate is MUB-specific.
    """
    u, bases, weights = _validate(u, bases, weights)
    H = mean_errors(bases, weights)
    r = u.shape[1]
    EH = (1.0 - 1.0/r)*H + u @ (u.T @ H)/r
    row_norms = np.linalg.norm(EH, axis=1)
    i = int(np.argmax(row_norms))
    if row_norms[i] <= 1e-15:
        return {'zero_mixed_error': True, 'maximum_row_norm': float(row_norms[i]),
                'candidates': []}
    x, y = u[i], EH[i] / row_norms[i]
    candidates = []
    for a, b in ((1,1), (1,-1), (2,1), (2,-1)):
        z = np.r_[a*x, b*y]
        norm = np.linalg.norm(z)
        f = group_cost(u, bases, a*x, b*y, 4)
        fw = group_cost(u, bases, a*x, b*y, 4, weights)
        candidates.append({'x_scale': a, 'y_sign': b,
                           'normal': (z/norm).tolist(),
                           'normal_cost': f/norm**4,
                           'weighted_normal_cost': fw/norm**4,
                           'relative_error': abs(fw-f)/f})
    return {'zero_mixed_error': False, 'query_core_index': i,
            'maximum_row_norm': float(row_norms[i]),
            'mub_witness_lower_bound': float(2*row_norms[i]/21),
            'candidates': candidates}


def exponents(d: int, degree: int) -> list[tuple[int, ...]]:
    if d < 1 or degree < 0:
        raise ValueError('positive dimension and nonnegative degree required')
    out = []
    for inds in combinations_with_replacement(range(d), degree):
        e = [0] * d
        for i in inds:
            e[i] += 1
        out.append(tuple(e))
    return out


def symmetric_features(A: Array, degree: int) -> Array:
    """Orthonormal symmetric-tensor coordinates, with their multinomial factors."""
    A = np.asarray(A, float)
    if A.ndim != 2:
        raise ValueError('A must be a matrix')
    es = exponents(A.shape[1], degree)
    cols = []
    for e in es:
        coefficient = factorial(degree)
        for q in e:
            coefficient //= factorial(q)
        cols.append(np.sqrt(coefficient) * np.prod(A ** np.array(e)[None,:], axis=1))
    return np.column_stack(cols)


def rational_features(points: Sequence[Sequence[Fraction]], degree: int) -> sp.Matrix:
    if not points or not points[0]:
        raise ValueError('nonempty point matrix required')
    d = len(points[0])
    if any(len(row) != d for row in points):
        raise ValueError('ragged point matrix')
    es = exponents(d, degree)
    rows = []
    for a in points:
        row = []
        for e in es:
            value = Fraction(1)
            for ai, qi in zip(a,e):
                value *= Fraction(ai) ** qi
            row.append(sp.Rational(value.numerator, value.denominator))
        rows.append(row)
    return sp.Matrix(rows)


def conic_reduce_exact(points: Sequence[Sequence[Fraction]], degree: int) -> list[Fraction]:
    """Exact original-row moment reduction by linear-dependence elimination.

    For even degree p, this preserves every p-th-power Euclidean residual cost.
    This small-instance reference implementation prioritizes exactness over speed.
    """
    if degree < 2 or degree % 2:
        raise ValueError('even degree at least two required')
    Phi = rational_features(points, degree)
    n, D = Phi.shape
    w = [sp.Rational(1) for _ in range(n)]
    active = list(range(n))
    while len(active) > D:
        J = active[:D+1]
        relation = Phi[J,:].T.nullspace()[0]
        if not any(c > 0 for c in relation):
            relation = -relation
        step = min(w[j]/c for j,c in zip(J,relation) if c > 0)
        for j,c in zip(J,relation):
            w[j] -= step*c
            if w[j] < 0:
                raise ArithmeticError('a negative conic weight was produced')
        active = [j for j in active if w[j] != 0]
    if Phi.T * sp.Matrix(w) != Phi.T * sp.ones(n,1):
        raise ArithmeticError('exact moment preservation failed')
    return [Fraction(int(a.p), int(a.q)) for a in w]


def dense_cubic_core() -> tuple[list[list[Fraction]], dict]:
    """Twenty rational unit vectors spanning Sym^3(R^4).

    Independence is certified modulo a prime on integer cubic features; this
    proves rational independence. This is a finite illustration, not a draw
    meeting the asymptotic random-core event.
    """
    prime, d, degree = 1000003, 4, 3
    es = exponents(d, degree)
    pivots: dict[int,list[int]] = {}
    selected: list[list[Fraction]] = []
    for v in sorted(product(range(-2,3), repeat=3), key=lambda a:(sum(x*x for x in a),a)):
        q = sum(x*x for x in v)
        nums, den = [2*x for x in v] + [1-q], 1+q
        row = []
        for e in es:
            val = 1
            for a,b in zip(nums,e):
                val = val*pow(a,b,prime) % prime
            row.append(val)
        z = row[:]
        for pivot, base in sorted(pivots.items()):
            c = z[pivot]
            if c:
                z = [(a-c*b) % prime for a,b in zip(z,base)]
        nonzero = next((j for j,a in enumerate(z) if a), None)
        if nonzero is None:
            continue
        inv = pow(z[nonzero], -1, prime)
        pivots[nonzero] = [a*inv % prime for a in z]
        selected.append([Fraction(a,den) for a in nums])
        if len(selected) == comb(d+degree-1,degree):
            break
    if len(selected) != 20:
        raise ArithmeticError('failed to construct the cubic basis')
    return selected, {'dimension': d, 'groups': len(selected),
                      'symmetric_cubic_dimension': 20, 'certificate_prime': prime,
                      'modular_feature_rank': len(pivots)}


def integer_normal(z: Sequence[Fraction]) -> list[int]:
    den = lcm(*(a.denominator for a in z))
    nums = [int(a*den) for a in z]
    common = 0
    for a in nums:
        common = gcd(common, abs(a))
    if common == 0:
        raise ValueError('zero normal')
    return [a//common for a in nums]


def fraction_string(x: Fraction) -> str:
    return str(x.numerator) if x.denominator == 1 else f'{x.numerator}/{x.denominator}'


def exact_mub_certificate() -> dict:
    """An all-rational 48-row, dimension-eight quartic violation certificate."""
    T, _, _ = real_mub(1)
    r, M, den = 4, len(T), 2
    U = [[Fraction(int(a),den) for a in row] for row in T]
    V = [U[(j//r)*r:(j//r+1)*r] for j in range(M)]
    W = [[r if t == 0 else 0 for t in range(r)] for j in range(M)]
    H = [[sum((Fraction(W[j][t]-1,r)*V[j][t][q] for t in range(r)),Fraction(0))
          for q in range(r)] for j in range(M)]
    E = [[sum((a*b for a,b in zip(U[i],U[j])),Fraction(0))**3
          for j in range(M)] for i in range(M)]
    EH = [[sum((E[i][j]*H[j][q] for j in range(M)),Fraction(0))
           for q in range(r)] for i in range(M)]
    i = max(range(M),key=lambda i:sum(a*a for a in EH[i]))
    A = [U[j]+V[j][t] for j in range(M) for t in range(r)]
    A_num = [[int(a*den) for a in row] for row in A]
    wf = [w for row in W for w in row]
    queries = []
    for scale,sign in ((1,1),(1,-1),(2,1),(2,-1)):
        z = integer_normal([scale*a for a in U[i]]+[sign*a for a in EH[i]])
        nz = sum(a*a for a in z)
        powers = [sum(a*b for a,b in zip(row,z))**4 for row in A_num]
        f = Fraction(sum(powers), den**4 * nz**2)
        fw = Fraction(sum(w*a for w,a in zip(wf,powers)), den**4 * nz**2)
        queries.append({'core_scale':scale,'noise_sign':sign,'normal_numerator':z,
                        'projector_denominator':nz,'rank':2*r-1,
                        'cost':fraction_string(f),'weighted_cost':fraction_string(fw),
                        'relative_error':fraction_string(abs(fw-f)/f)})
    return {'description':'Unscaled rational version of the orthogonal-group construction.',
            'r':r,'M':M,'n':M*r,'d':2*r,'k':2*r-1,
            'matrix_denominator':den,'matrix_numerators':A_num,'weights':wf,
            'support':sum(w!=0 for w in wf),'epsilon':'1/56',
            'support_lower_bound':'36','query_core_index':i,'queries':queries,
            'scope':'Finite candidate certificate, not a universal proof or independent review.'}
