#!/usr/bin/env python3
"""Verify all recorded SHA-256 hashes without changing package files."""
from __future__ import annotations
import hashlib
from pathlib import Path


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    manifest = root / 'SHA256SUMS'
    count = 0
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        expected, relative = line.split('  ', 1)
        path = (root / relative).resolve()
        if root not in path.parents:
            raise ValueError(f'Unsafe manifest path: {relative}')
        if not path.is_file():
            raise FileNotFoundError(relative)
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError(f'SHA-256 mismatch: {relative}')
        count += 1
    print(f'All {count} recorded SHA-256 hashes match.')


if __name__ == '__main__':
    main()
