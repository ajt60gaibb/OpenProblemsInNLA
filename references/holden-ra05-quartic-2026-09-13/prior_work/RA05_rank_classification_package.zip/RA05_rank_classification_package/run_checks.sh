#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python code/check_manifest.py
python code/check_exact_certificate.py
OUT="${1:-$(mktemp -d -t ra05-rank-checks.XXXXXXXX)}"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
python code/verify.py --out "$OUT"
printf '\nFresh verification files: %s\n' "$OUT"
