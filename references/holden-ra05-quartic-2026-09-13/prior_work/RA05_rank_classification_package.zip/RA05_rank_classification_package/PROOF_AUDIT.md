# Internal proof audit

This is an author-side audit of the written argument, not independent review. The theorem statements, proofs, and external dependencies are in the manuscript. Finite checks are listed separately rather than treated as proofs of universal claims.

## 1. Quantifiers and the coreset model

**Checked:** S_p permits arbitrary input rank; T_p imposes rank(A) <= k+1. Both use original rows, nonnegative weights in their definitions, and every subspace of dimension at most k. Support counts row indices, not total weight. Input matrices in a worst-case lower bound may depend on accuracy.

**Guardrail:** The completed theorem concerns T_p for even p, not S_p. Section 11 and Appendix C give an explicit separation between the two functions.

## 2. Hyperplane and Gaussian transfers

For row-span dimension q <= k+1, R intersect z-perp has dimension q-1 <= k and is an actual permitted query. Its residual of a row in R is (a dot z)z. This gives all linear-form costs, by homogeneity.

In the other direction, integrating the linear-form inequality at z=B^T g gives the p-th power of every Euclidean linear-image norm. This proves sufficiency for arbitrary subspace projectors. The triangle inequality is used before canceling the Gaussian moment. Coordinate normalization is undone in the linear-form inequality, not by falsely treating a non-orthogonal map as an isometry of subspaces.

## 3. Variable core density

Lemma 3.2 takes L between order r^(p/2) and a_p r^(p-1). The uniform p-moment bound grows as 1+L/r^(p/2), so it is not treated as a constant when density grows. A Gaussian operator-norm bound is proved in Appendix A and used with separate norm and moment events.

The nonlinear kernel is real symmetric with diagonal one. It is NOT assumed positive semidefinite for general real p. Frobenius closeness to the identity gives many eigenvalues in [1/2,3/2]; truncation gives stable rank at least L/12. Restricted invertibility selects actual input columns. The remaining rectangular matrix still consists of evaluations at actual query vectors.

**Imported premise:** Spielman--Srivastava restricted invertibility in the form of MSS Theorem 1.1. The selected column count is at most one quarter of the stable rank, so the lower singular-value bound is positive.

## 4. Auxiliary bases

Each group has its own whole orthonormal basis. Independence is between bases, not between columns of the same basis. For a fixed direction, each basis contributes a variable in [0,1]. An exponential Markov estimate and a Euclidean net prove the aggregate p-moment bound with positive probability.

The mean norm is exactly 1/sqrt(r) in each basis, regardless of its orientation. The full coefficient norm is preserved by each orthonormal basis. No small-subset singular-value assumption is used.

## 5. Derivative extraction

All query costs are evaluated at real normals, and homogeneity permits the unnormalized normals used by interpolation. For even p, the error is a degree-p polynomial and the derivative stencil is exact. This permits signed weights in the even-power lower bound.

For non-even p, the uniform scalar remainder is proved using a Holder derivative and the beta integral. Nonnegative weights are used only where total variation is bounded by the sum of weighted and original noise costs. The balancing step is t=epsilon^(1/p), giving exponent beta=2-2/p, not 2.

## 6. Support conversion and optimization

The zero-subspace query gives total mass at least M/2 because all row norms are equal. Orthogonality gives the exact identity sum alpha_jt^2 = sum ||b_j||^2. Combining mean error and exact mean norms gives the finite-density support inequality of Proposition 5.3.

Cauchy--Schwarz is applied to actual nonzero coefficients and remains valid for signed coefficients. The number of groups is then optimized within its permitted range. Integer floors and the p-dependent endpoint constant change multiplicative constants, not the exponents. Zero padding gives arbitrary large k. Finitely many small ranks are covered by reducing a p-dependent lower constant, since the displayed minimum is at most k^p.

## 7. Spectral and exact upper bounds

**BSS:** The lifted vectors live in Sym^(p/2)(R^q), whose dimension is binomial(q+p/2-1,p/2). Testing their covariance approximation on x^(tensor p/2) gives the p-th power linear-form approximation. Singular covariances are whitened only on their range. The source theorem's spectral interval is rescaled to 1 +/- epsilon.

**Exact cone:** All degree-p moments are preserved by eliminating linear dependences among row feature vectors while keeping weights nonnegative. This yields at most binomial(q+p-1,p) original row indices. No synthetic vectors are introduced. For even p the moments preserve the entire linear-form polynomial, and Gaussian averaging preserves every Euclidean residual cost.

## 8. Gaussian width and Banaszczyk discrepancy

Pure symmetric powers span the tensor space, so the injective polynomial expression used to define the convex body is a genuine norm. The body is bounded, symmetric, convex, and has nonempty interior.

The covariance calculation uses 2(1-t^p) <= 2p(1-t) for t in [-1,1]. An extra zero index is added before Gaussian comparison. Positive and negative suprema are then bounded separately; an expected signed supremum is not silently substituted for an expected absolute supremum.

The body has Gaussian measure at least 11/16. Vectors (u_i^(tensor p),1)/(5 sqrt(2)) have Euclidean norm 1/5. Thus both hypotheses of the imported Banaszczyk theorem are met. The extra scalar coordinate controls cardinality discrepancy.

## 9. Isotropic normalization and halving

A determinant-one minimizer exists because the input spans its intrinsic space. Singular values are controlled on sublevel sets. Variations in traceless symmetric directions give a scalar identity matrix, which is rescaled to isotropy. Jensen provides the lower form bound q^(1-p/2)||x||^p; the upper form bound follows from unit directions and isotropy.

Initial weighted rounding loses at most n*eta on the unit sphere, with eta explicitly chosen small enough. Common-weight copies are a temporary proof device, not synthetic final rows. At each step the minority color class is retained and its common weight is doubled. Total mass never increases. The final common mass is below 2q/m, so the sum of stage errors is geometric and has no log(n) factor. Repeated original indices are merged and their weights translated back to the original rows.

**Not claimed:** an efficient general implementation of Banaszczyk coloring or of the full upper-bound construction.

## 10. Explicit quartic constants

The complete real MUB identities are proved from the finite-field construction and the traceless symmetric-space decomposition. The auxiliary assignment repeats each basis exactly r times. Thus core and auxiliary fourth moments both have constant 3/2.

Four actual hyperplanes isolate the cubic-linear term. The norms 24*epsilon and 204*epsilon yield the constant 21/2; division by the kernel lower bound 3/4 gives 196 after squaring. Every omitted row contributes 1/r^2 to the coefficient error. At epsilon=1/(28 sqrt(r)), the lower support bound is 3Mr/4.

The exact rational certificate omits only a common row scale. Its projectors and costs are checked directly using Euclidean residuals, independently of the derivative-extraction formula.

## 11. Scope and remaining claims

Appendix C proves an arbitrary-rank lower bound k/(144*4^p*epsilon^2). At p=4, epsilon=k^-2 it exceeds the completed restricted answer by a factor of k. This directly prevents promoting the restricted theorem to a whole-entry solution.

The source upper bound for S_p is used only for comparison. The primary new lower proofs and the restricted upper proofs do not depend on that upper-bound paper. Non-even powers and the arbitrary-rank joint function are left explicitly undetermined.

## 12. Computational evidence

All 1,881 new checks pass, with counts by category recorded. Exact checks include moment reductions and a separately checked quartic violation. Floating-point checks use stated tolerances. Small random examples do not certify the asymptotic existence events. The tiny exhaustive coloring tests are not proofs or implementations of the imported general balancing theorem. The constant-free optimization diagnostics do not verify unknown asymptotic constants.
