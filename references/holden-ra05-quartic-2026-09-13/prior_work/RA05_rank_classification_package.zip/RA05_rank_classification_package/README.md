# RA-05: sharp even-power coresets at intrinsic rank at most k+1

**Whole-entry status: PARTIAL, subject to review.** This package does not claim a full solution of RA-05. It gives matching upper and lower bounds for every even p >= 4 and every accuracy when the input matrix has rank at most k+1, and strengthens the unrestricted lower bounds. The unrestricted joint rank/accuracy problem and the corresponding non-even-power classification remain unresolved here.

## Main result

Let T_p(k, epsilon) be the worst-case minimum size of a nonnegative strong original-row coreset, restricted to matrices A with rank(A) <= k+1. Query subspaces have dimension at most k, as in the original problem. For each fixed even p = 2s >= 4, Theorem 1.1 proves

    T_p(k, epsilon) = Theta_p(min{
        k^s / epsilon^2,
        k^(s+1/2) / epsilon,
        k^(2s)
    }).

This holds for every k >= 1 and 0 < epsilon < 1/2. The constants depend only on p. There are no suppressed logarithms. Upper-bound weights are nonnegative and supported on original row indices. Even-power lower bounds also exclude signed reweightings of smaller support.

The three orders become active at the displayed breakpoints epsilon = k^(-1/2) and epsilon = k^(-(s-1/2)), up to the theorem's multiplicative constants.

For every real p > 2, Theorem 1.2 gives the lower bound

    S_p(k, epsilon) >= T_p(k, epsilon)
       >= c_p min{
            k^(p/2) / epsilon^beta,
            k^((p+1)/2) / epsilon^(beta/2),
            k^p
          },

where beta = 2 for even p and beta = 2 - 2/p otherwise. Here S_p is the unrestricted RA-05 quantity. Corollary 6.1 independently refutes the displayed proposed formula for each fixed p > 2; see the manuscript for the exact numbered statement if compiling with altered formatting.

## What changed from the preceding package

The core now has a tunable number of groups, ranging up to a constant times r^(p-1), rather than fixing it at order r^(p/2). Each group has its own entire orthonormal auxiliary basis. The resulting support inequality can be optimized over the group count and does not stop at the previous sparse-subset threshold.

A new matching upper-bound argument uses polynomial discrepancy followed by weighted halving, after isotropic normalization. It complements tensor spectral sparsification and exact moment reduction. Gaussian averaging transfers a linear-form embedding to the original Euclidean strong-coreset objective. The manuscript proves the converse under rank(A) <= k+1 and explicitly distinguishes intrinsic rank from query rank.

The principal proofs are self-contained apart from the precisely stated restricted-invertibility, BSS sparsification, and Banaszczyk balancing theorems. None of these external theorems is represented as a new result of this package. Related embedding work is cited without claiming a priority determination.

## Why this is not full RA-05

The rank restriction is substantive. For p=4 and epsilon=k^(-2):

    T_4(k, k^(-2)) = Theta(k^4),
    S_4(k, k^(-2)) >= c k^5,
    S_4(k, k^(-2)) <= O_tilde(k^6) [imported comparison bound].

The first statement is the new classification. The second follows from the explicit two-sparse block construction reproved in Appendix C. The third is Lin--Mirrokni--Woodruff, Theorem 1.2. Thus the restricted answer cannot be used as an arbitrary-rank upper bound. This is a remaining mathematical gap, not merely a missing review step. See STATUS.md and REMAINING_GAP.md.

## Files

- `manuscript/RA05_rank_classification.pdf`: full 21-page manuscript.
- `manuscript/RA05_rank_classification.tex`: editable LaTeX source.
- `code/rank_classification.py`: grouped inputs, exact moment reduction, dense finite cubic core, and quartic witness construction.
- `code/verify.py`: 1,881 finite checks, with recorded categories and limitations.
- `code/check_exact_certificate.py`: separate standard-library integer/Fraction checker.
- `results/`: numerical records and exact rational JSON certificates.
- `PROOF_AUDIT.md`: proof obligations, dependencies, and scope checks.
- `SOURCES.md`: primary sources and exact imported theorem locations.
- `REPRODUCIBILITY.md`: commands, dependencies, and interpretation of tests.
- `prior_work/RA05_continuation_proof_package.zip`: unchanged preceding package, including its earlier nested work.
- `SHA256SUMS`: file hashes; run `python code/check_manifest.py` before regenerating output files.

## Run

The exact lower-bound certificate requires Python's standard library only:

    python code/check_exact_certificate.py

The full finite suite requires NumPy, SciPy, and SymPy:

    python -m pip install -r requirements.txt
    python code/verify.py --out /tmp/ra05_rank_recheck

Do not run the exact checker with `python -O`: it deliberately uses assertions as test failures. The verifier's `--out` option keeps the packaged results and their hashes unchanged. The numerical test suite is supplementary, not a proof-assistant certificate or an implementation of the imported asymptotic existence theorems.

No repository files were changed. No independent peer review or formal verification is claimed.
