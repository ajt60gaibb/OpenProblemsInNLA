# Sources and mathematical dependencies

Public websites were used; no GitHub plugin was used. Sources were checked during this September 2026 continuation. The proofs distinguish original derivations in the manuscript from the following imported results. This source audit does not certify research priority or the correctness of every source's proof.

## Original problem and status

1. **RA-05 canonical statement:**
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RA-05/README.md
   Repository target: arbitrary matrices, every fixed p > 2, 1 <= k < d, 0 < epsilon < 1/2, nonnegative weighted subsets of original rows, all subspaces of dimension at most k. The page's status was Open; its stated last check was 10 September 2026.

2. **Repository resolution guidelines:**
   https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/RESOLVED.md
   Used for the proposed whole-entry status, not for any mathematical premise. A restricted classification with remaining cases belongs under partial progress, subject to review. No edit was performed.

## Imported structural theorems

3. **Restricted invertibility.** A. W. Marcus, D. A. Spielman, N. Srivastava, *Interlacing Families III: Sharper Restricted Invertibility Estimates*, arXiv:1712.07766.
   https://arxiv.org/pdf/1712.07766
   Exact location: Theorem 1.1, which states the Spielman--Srivastava stable-rank bound. For a D-by-L matrix B and m <= srank(B), some m columns have squared least singular value at least

       (1 - sqrt(m/srank(B)))^2 * ||B||_F^2/L.

   The manuscript uses m <= srank(B)/4. The full theorem was checked in a rendered PDF page as well as parsed text.

4. **Spectral sparsification.** J. Batson, D. A. Spielman, N. Srivastava, *Twice-Ramanujan Sparsifiers*, arXiv:0808.0163.
   https://arxiv.org/pdf/0808.0163
   Exact location: Theorem 3.1. With covariance equal to the identity in dimension D and t>1, support at most tD is possible, with eigenvalue ratio ((sqrt(t)+1)/(sqrt(t)-1))^2. The manuscript centers the interval at one and takes t=16/epsilon^2. The theorem was checked on the rendered PDF page.

5. **Vector balancing.** W. Banaszczyk, *Balancing vectors and Gaussian measures of n-dimensional convex bodies*, Random Structures & Algorithms 12 (1998), 351--360.
   DOI: 10.1002/(SICI)1098-2418(199807)12:4<351::AID-RSA3>3.0.CO;2-S
   Precise restatement checked: D. Dadush, S. Garg, S. Lovett, A. Nikolov, *Towards a Constructive Version of Banaszczyk's Vector Balancing Theorem*, Theory of Computing 15(15) (2019), Theorem 1.1.
   https://theoryofcomputing.org/articles/v015a015/v015a015.pdf
   Norm bound 1/5 and Gaussian measure at least 1/2 are exactly the hypotheses used. The theorem was checked on the rendered PDF page. No general balancing algorithm is implemented by the supplied code.

## Comparison upper bound

6. H. Lin, V. Mirrokni, D. P. Woodruff, *Nearly Optimal Strong Coresets for ell_p Subspace Approximation*, arXiv:2608.26047v2, 27 August 2026.
   https://arxiv.org/html/2608.26047v2
   Exact location: Theorem 1.2. With failure probability delta=1/4, its size bound is

       C_p k^(p/2) epsilon^-2 [log(4 C_p k/epsilon)]^(p+5).

   Used to compare the unrestricted lower bounds and identify the remaining gap. It is not a premise of the new restricted classification. Section 1.4 explicitly discusses the joint-dependence question.

## Construction background and related work

7. P. O. Boykin, M. Sitharam, M. Tarifi, P. Wocjan, *Real Mutually Unbiased Bases*, arXiv:quant-ph/0502024.
   https://arxiv.org/abs/quant-ph/0502024
   Background for complete real MUB families. Appendix B of this manuscript proves the finite-field construction and the identities actually used; code does not load an external frame data file.

8. Y. Li, *Near-Optimal Embeddings of Constant-Dimensional Subspaces of L^p into ell_p^N*, arXiv:2607.11747v4, 27 July 2026.
   https://arxiv.org/html/2607.11747v4
   Introduction and Theorems 1.1--1.2, read as related work. The constant-dimensional constants may depend on dimension as well as p. This is not used to claim a joint-rank classification, and no theorem from this paper is a premise of the present proofs.

## Prior conversation artifacts

The preceding continuation ZIP is included unchanged in `prior_work/`. Its SHA-256 is

    d2771d2d3fa169f009097f498dbe769344ed9a42ad8f7fdac0172b533917208a

The finite-field implementation `code/prior_ra05.py` was copied unchanged from the earlier all-exponent package. Earlier artifacts are author-side research manuscripts, not peer-reviewed external sources. The current lower-bound proof and the restricted upper proofs are written out independently; Appendix C restates the earlier all-rank construction with proof.
