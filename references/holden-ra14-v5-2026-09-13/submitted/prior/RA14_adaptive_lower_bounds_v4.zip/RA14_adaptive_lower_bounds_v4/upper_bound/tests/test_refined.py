import math
import unittest
import numpy as np
from src.ra14_refined import (DenseOracle, theorem_parameters, exact_columns, gram,
    chebyshev_apply, krylov_ritz, two_stage, solve_with_theorem_parameters,
    residual_ratio, basis)

class RefinedTests(unittest.TestCase):
    def test_gaussian_net_constants(self):
        for x in (9/16, 25/16):
            self.assertGreater((x-1-math.log(x))/2, 1/20)
        self.assertGreater(256/20-math.log(17), 9)
        self.assertLess(2*math.log(17)-10, -4)
        self.assertLess(7*math.sqrt(20)/48, 1)
        self.assertLess(4*math.exp(-9)+4*math.exp(-4*512), .01)
    def test_degrees(self):
        for n in (100, 10000, 10000000):
            for k in (1, 4, 20):
                for eps in (1e-8, 1e-3, .1, .49):
                    p=theorem_parameters(n,k,eps)
                    self.assertGreaterEqual(4*p.d1*math.sqrt(p.delta)-math.log(4),
                        math.log(n/(p.r*p.delta))-1e-12)
                    self.assertGreaterEqual(2*p.d2*math.sqrt(p.eta)-math.log(4),
                        math.log((1+p.eta)*p.R2/p.eta)-1e-12)
    def test_scalar_majorant(self):
        # Logarithmic evaluation avoids treating polynomial overflow as success.
        for rho in (2,10,1000):
            for eps in (1e-8,.001,.1,.49):
                eta=eps/4; R2=3*rho
                d=math.ceil(math.log(8*R2/eta)/(2*math.sqrt(eta)))
                for excess in (1e-6, .01, 1, 100, 1e6):
                    x=1+eta*(1+excess)
                    u=math.acosh(2*x-1)
                    du=d*u
                    logp=du+math.log1p(math.exp(-2*du))-math.log(2)
                    self.assertGreaterEqual(2*logp-math.log(x),
                                            math.log(R2/eta)-1e-7)
    def test_norm_allocation(self):
        for eps in np.linspace(.0001,.4999,100):
            self.assertLessEqual((1+eps/2)/(1-eps/4),(1+eps)**2)
    def test_surrogate_projection_lemma(self):
        rng=np.random.default_rng(700)
        for k in (1,3,6):
            n=30; ell=min(n,2*k+5)
            values=np.r_[np.linspace(3,9,k),np.linspace(-1,1,n-k)]
            h=np.diag(values); omega=rng.normal(size=(n,ell))
            q=basis(h@omega); b=q.T@h
            _,_,vh=np.linalg.svd(b,full_matrices=False); z=vh[:k].T
            L=np.linalg.norm(omega[k:]@np.linalg.pinv(omega[:k]),2)
            err=np.linalg.norm(h-(h@z)@z.T,2)
            self.assertLessEqual(err**2,2+L**2+1e-9)
    def test_exact_query_accounting(self):
        a=np.diag(np.arange(1.,21.)); o=DenseOracle(a)
        z=exact_columns(o,3)
        self.assertEqual(o.queries,20)
        self.assertAlmostEqual(residual_ratio(a,z,3),1)
    def test_gram_query_accounting(self):
        o=DenseOracle(np.eye(10)); x=np.ones((10,4))
        np.testing.assert_allclose(gram(o,x),x)
        self.assertEqual(o.queries,8)
    def test_chebyshev_identity_and_accounting(self):
        rng=np.random.default_rng(9); a=np.diag(np.linspace(.2,1.2,12))
        x=rng.normal(size=(12,3)); d=7; b=1.1; o=DenseOracle(a)
        y,logscale=chebyshev_apply(o,x,b,d)
        coeff=np.zeros(d+1); coeff[-1]=1
        vals=np.polynomial.chebyshev.chebval(2*np.diag(a)**2/b-1,coeff)
        np.testing.assert_allclose(y*math.exp(logscale), vals[:,None]*x,
                                   rtol=2e-10,atol=2e-10)
        self.assertEqual(o.queries,2*d*3)
    def test_krylov_ritz_and_query_bound(self):
        rng=np.random.default_rng(4); a=np.diag(np.linspace(.1,2,40))
        o=DenseOracle(a); om=rng.normal(size=(40,8)); d=4
        q,mq,vals=krylov_ritz(o,om,d)
        np.testing.assert_allclose(q.T@q,np.eye(q.shape[1]),atol=1e-8)
        np.testing.assert_allclose(mq,a.T@a@q,atol=1e-8)
        self.assertLessEqual(o.queries,2*(d+1)*8)
        self.assertLessEqual(vals[2],np.sort(np.diag(a)**2)[::-1][2]+1e-8)
    def test_ritz_lower_bound_on_good_sketch(self):
        rng=np.random.default_rng(23); n=64;r=3;ell=10;delta=.1
        a=np.diag(np.linspace(.1,2,n)); o=DenseOracle(a)
        om=rng.normal(size=(n,ell)); order=np.argsort(np.diag(a))[::-1]
        w=om[order]; L=np.linalg.norm(w[r:]@np.linalg.pinv(w[:r]),2)
        u=2*math.atanh(math.sqrt(delta))
        d=math.ceil(math.log(4*max(1,L*L)/delta)/(2*u))
        _,_,vals=krylov_ritz(o,om,d)
        c=np.sort(np.diag(a)**2)[::-1][r-1]
        self.assertGreaterEqual(vals[r-1],(1-delta)*c-1e-8)
    def test_conservative_fallback(self):
        a=np.diag(np.linspace(.1,4,30));o=DenseOracle(a)
        z,info=solve_with_theorem_parameters(o,2,.1)
        self.assertEqual(info['route'],'exact-column fallback')
        self.assertEqual(o.queries,30)
        self.assertLessEqual(residual_ratio(a,z,2),1+1e-10)
    def test_rank_promise_branch(self):
        rng=np.random.default_rng(3)
        u,_=np.linalg.qr(rng.normal(size=(30,30)))
        v,_=np.linalg.qr(rng.normal(size=(30,30)))
        a=u[:,:2]@np.diag([3.,1.])@v[:,:2].T
        o=DenseOracle(a)
        z,info=two_stage(o,2,.1,rng,8,6,3,5)
        self.assertTrue(info['rank_branch'])
        self.assertLess(np.linalg.norm(a-(a@z)@z.T,2),1e-8)
    def test_experimental_branch_budget(self):
        rng=np.random.default_rng(201)
        a=np.diag(np.r_[1.6,1.3,np.linspace(1,.1,58)])
        o=DenseOracle(a); d1=3;d2=5;ell1=8;ell2=6
        z,info=two_stage(o,2,.2,rng,ell1,ell2,d1,d2)
        self.assertLessEqual(o.queries,2*ell1*(d1+1)+4*ell2*d2)
        np.testing.assert_allclose(z.T@z,np.eye(2),atol=1e-8)
    def test_parameter_absorption(self):
        # This finite check supplements, not replaces, the analytic proof.
        for n in (10,100,1000,1000000):
            for k in sorted(set([1,max(1,n//100),max(1,n//3),n-1])):
                for eps in (1e-12,1e-5,.01,.49):
                    p=theorem_parameters(n,k,eps)
                    scale=k/math.sqrt(eps)*math.log(math.e*n/k)
                    self.assertLessEqual(p.budget,min(n,100000*scale)+1e-8)
    def test_known_block_queries_parallelize(self):
        a1=np.diag([2.,3.]);a2=np.array([[1.,2.],[4.,5.]])
        a=np.zeros((4,4));a[:2,:2]=a1;a[2:,2:]=a2
        x=np.array([[2.],[1.],[-1.],[3.]])
        o=DenseOracle(a); y=o.matmat(x)
        np.testing.assert_allclose(y[:2],a1@x[:2])
        np.testing.assert_allclose(y[2:],a2@x[2:])
        self.assertEqual(o.queries,1)
    def test_invalid_parameters(self):
        for n,k,e in ((1,1,.1),(10,0,.1),(10,10,.1),(10,1,0),(10,1,.5)):
            with self.assertRaises(ValueError): theorem_parameters(n,k,e)
    def test_finite_input_validation(self):
        with self.assertRaises(ValueError): DenseOracle(np.array([[1,np.nan],[0,1]]))
        with self.assertRaises(ValueError): DenseOracle(np.ones((2,3)))

if __name__=='__main__': unittest.main()
