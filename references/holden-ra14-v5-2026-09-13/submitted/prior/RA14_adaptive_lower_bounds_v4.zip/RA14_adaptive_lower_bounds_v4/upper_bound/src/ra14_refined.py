"""Oracle-counted implementations accompanying the RA-14 upper-bound proof.

The proof is for exact arithmetic. These NumPy routines use floating point;
numerical rank decisions and polynomial recurrences are not formal certificates.
Only solve_with_theorem_parameters uses the theorem's block sizes/degrees.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Protocol
import numpy as np

class Oracle(Protocol):
    n: int
    queries: int
    def matmat(self, x: np.ndarray) -> np.ndarray: ...
    def rmatmat(self, x: np.ndarray) -> np.ndarray: ...

class DenseOracle:
    """Each column of either block product is charged as one vector query."""
    def __init__(self, a: np.ndarray):
        a = np.asarray(a, dtype=float)
        if a.ndim != 2 or a.shape[0] != a.shape[1] or a.shape[0] < 2:
            raise ValueError("A must be square with dimension at least two")
        if not np.isfinite(a).all():
            raise ValueError("A must have finite entries")
        self._a = a.copy()
        self.n = a.shape[0]
        self.queries = 0
    def _check(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=float)
        if x.ndim != 2 or x.shape[0] != self.n:
            raise ValueError("Block must have shape (n, number_of_vectors)")
        if not np.isfinite(x).all():
            raise FloatingPointError("Nonfinite query")
        return x
    def matmat(self, x: np.ndarray) -> np.ndarray:
        x = self._check(x)
        self.queries += x.shape[1]
        y = self._a @ x
        if not np.isfinite(y).all():
            raise FloatingPointError("Nonfinite oracle response")
        return y
    def rmatmat(self, x: np.ndarray) -> np.ndarray:
        x = self._check(x)
        self.queries += x.shape[1]
        y = self._a.T @ x
        if not np.isfinite(y).all():
            raise FloatingPointError("Nonfinite oracle response")
        return y

def validate(n: int, k: int, eps: float) -> None:
    if not isinstance(n, (int, np.integer)) or n < 2:
        raise ValueError("n must be an integer at least 2")
    if not isinstance(k, (int, np.integer)) or not 1 <= k < n:
        raise ValueError("k must be an integer in [1,n)")
    if not math.isfinite(eps) or not 0 < eps < 0.5:
        raise ValueError("eps must lie strictly between 0 and 1/2")

@dataclass(frozen=True)
class Parameters:
    n: int
    k: int
    eps: float
    r: int
    ell1: int
    ell2: int
    d1: int
    d2: int
    delta: float
    eta: float
    R2: float
    random_branch_budget: int
    exact_fallback: bool
    @property
    def budget(self) -> int:
        return self.n if self.exact_fallback else self.random_branch_budget

def theorem_parameters(n: int, k: int, eps: float) -> Parameters:
    validate(n, k, eps)
    r = k + 1
    delta = eta = eps / 4.0
    ell1, ell2 = 256 * r, 256 * k
    R2 = 3.0 * n / k
    d1 = math.ceil(math.log(4.0 * n / (r * delta)) / (4.0 * math.sqrt(delta)))
    d2 = math.ceil(math.log(8.0 * R2 / eta) / (2.0 * math.sqrt(eta)))
    B = 2 * ell1 * (d1 + 1) + 4 * ell2 * d2
    fallback = ell1 > n or B >= n
    return Parameters(n, k, eps, r, ell1, ell2, d1, d2, delta, eta, R2, B, fallback)

def gram(oracle: Oracle, x: np.ndarray) -> np.ndarray:
    return oracle.rmatmat(oracle.matmat(x))

def basis(x: np.ndarray, tol: float | None = None) -> np.ndarray:
    """Numerical column basis; exact rank detection in the proof is different."""
    x = np.asarray(x, dtype=float)
    if x.shape[1] == 0:
        return x.copy()
    u, s, _ = np.linalg.svd(x, full_matrices=False)
    if s.size == 0 or s[0] == 0:
        return np.empty((x.shape[0], 0))
    if tol is None:
        tol = 64 * np.finfo(float).eps * max(x.shape) * s[0]
    return u[:, s > tol]

def complete(q: np.ndarray, k: int, rng: np.random.Generator) -> np.ndarray:
    q = basis(q)
    if q.shape[1] >= k:
        return q[:, :k]
    while q.shape[1] < k:
        x = rng.standard_normal((q.shape[0], k - q.shape[1]))
        for _ in range(2):
            x -= q @ (q.T @ x)
        extra = basis(x)
        if extra.shape[1] == 0:
            continue
        q = np.column_stack((q, extra[:, :k-q.shape[1]]))
    return q

def exact_columns(oracle: Oracle, k: int) -> np.ndarray:
    # n individual vector products, batched only for implementation convenience.
    a = oracle.matmat(np.eye(oracle.n))
    _, _, vh = np.linalg.svd(a, full_matrices=False)
    return vh[:k].T

def krylov_ritz(oracle: Oracle, omega: np.ndarray, degree: int):
    """Q, MQ, and descending Ritz values for span{Omega,...,M^degree Omega}.

    Block Arnoldi with reorthogonalization avoids explicitly storing raw powers.
    At most 2*(degree+1)*omega.shape[1] vector queries are made.
    """
    if degree < 0:
        raise ValueError("degree must be nonnegative")
    qnew = basis(omega)
    qblocks, mqblocks = [], []
    for level in range(degree + 1):
        if qnew.shape[1] == 0:
            break
        qblocks.append(qnew)
        mqnew = gram(oracle, qnew)
        mqblocks.append(mqnew)
        if level == degree:
            break
        qall = np.column_stack(qblocks)
        if qall.shape[1] >= oracle.n:
            break
        residual = mqnew.copy()
        for _ in range(2):
            residual -= qall @ (qall.T @ residual)
        rank_tol = 256 * np.finfo(float).eps * max(residual.shape) * max(1.0, np.linalg.norm(mqnew, 2))
        qnew = basis(residual, tol=rank_tol)
        if qnew.shape[1] > oracle.n - qall.shape[1]:
            qnew = qnew[:, :oracle.n-qall.shape[1]]
    if not qblocks:
        return np.empty((oracle.n, 0)), np.empty((oracle.n, 0)), np.empty(0)
    q, mq = np.column_stack(qblocks), np.column_stack(mqblocks)
    small = q.T @ mq
    small = (small + small.T) / 2
    vals = np.linalg.eigvalsh(small)[::-1]
    return q, mq, vals

def chebyshev_apply(oracle: Oracle, x: np.ndarray, b: float, degree: int):
    """Return (Y, log_scale) with exp(log_scale)*Y ~ T_d(2M/b-I)X.

    Common rescaling of the two recurrence states limits overflow. Each call is
    still one fixed polynomial up to an overall scalar, not a nonlinear filter.
    Extreme input scales can exceed floating-point range; then an error is raised.
    """
    if b <= 0 or not math.isfinite(b) or degree < 0:
        raise ValueError("b must be positive/finite and degree nonnegative")
    prev = np.array(x, dtype=float, copy=True)
    log_scale = 0.0
    if degree == 0:
        return prev, log_scale
    curr = (2.0 / b) * gram(oracle, prev) - prev
    if not np.isfinite(curr).all():
        raise FloatingPointError("Polynomial initialization overflow")
    scale = max(1.0, float(np.max(np.abs(prev))), float(np.max(np.abs(curr))))
    prev /= scale
    curr /= scale
    log_scale += math.log(scale)
    for _ in range(1, degree):
        nxt = (4.0 / b) * gram(oracle, curr) - 2.0 * curr - prev
        if not np.isfinite(nxt).all():
            raise FloatingPointError("Polynomial recurrence overflow")
        scale = max(1.0, float(np.max(np.abs(curr))), float(np.max(np.abs(nxt))))
        prev, curr = curr / scale, nxt / scale
        log_scale += math.log(scale)
    return curr, log_scale

def two_stage(oracle: Oracle, k: int, eps: float, rng: np.random.Generator,
              ell1: int, ell2: int, d1: int, d2: int):
    """Two-stage construction. Arbitrary supplied sizes are EXPERIMENTAL.

    A theorem-level probability assertion requires the specified conservative
    parameters AND exact arithmetic, not this floating-point implementation.
    """
    validate(oracle.n, k, eps)
    if not k + 1 <= ell1 <= oracle.n or not k <= ell2 <= oracle.n:
        raise ValueError("Invalid block dimensions")
    start = oracle.queries
    omega1 = rng.standard_normal((oracle.n, ell1))
    q, mq, vals = krylov_ritz(oracle, omega1, d1)
    delta = eps / 4
    mu = vals[k] if len(vals) > k else 0.0
    scale = max(1.0, float(vals[0]) if len(vals) else 1.0)
    if mu <= 128 * np.finfo(float).eps * scale:
        z = complete(mq, k, rng)
        return z, {"mu": float(mu), "b": 0.0, "rank_branch": True,
                   "queries": oracle.queries-start, "krylov_dimension": q.shape[1]}
    b = float(mu / (1-delta))
    omega2 = rng.standard_normal((oracle.n, ell2))
    homega, log1 = chebyshev_apply(oracle, omega2, b, d2)
    qh = basis(homega)
    if qh.shape[1] == 0:
        raise FloatingPointError("Polynomial sketch lost all numerical rank")
    hq, log2 = chebyshev_apply(oracle, qh, b, d2)
    # B=Q_H^T H=(H Q_H)^T, up to a harmless overall nonzero scalar.
    _, _, vh = np.linalg.svd(hq.T, full_matrices=False)
    z = complete(vh[:k].T, k, rng)
    details = {"mu": float(mu), "b": b, "rank_branch": False,
               "queries": oracle.queries-start, "krylov_dimension": q.shape[1],
               "filter_dimension": qh.shape[1], "filter_log_scales": [log1, log2]}
    return z, details

def solve_with_theorem_parameters(oracle: Oracle, k: int, eps: float, seed: int | None = None):
    """Conservative parameter selection; see module warning about arithmetic."""
    p = theorem_parameters(oracle.n, k, eps)
    start = oracle.queries
    if p.exact_fallback:
        z = exact_columns(oracle, k)
        info = {"route": "exact-column fallback", "queries": oracle.queries-start}
    else:
        z, info = two_stage(oracle, k, eps, np.random.default_rng(seed),
                            p.ell1, p.ell2, p.d1, p.d2)
        info["route"] = "two-stage theorem parameters (floating point)"
    info["budget"] = p.budget
    if info["queries"] > p.budget:
        raise AssertionError("Oracle budget exceeded")
    return z, info

def residual_ratio(a: np.ndarray, z: np.ndarray, k: int) -> float:
    """VALIDATION ONLY. This function is not used inside an oracle algorithm."""
    s = np.linalg.svd(a, compute_uv=False)
    err = float(np.linalg.norm(a-(a@z)@z.T, ord=2))
    return err / s[k] if s[k] > 1e-13 * max(1.0, s[0]) else err
