import math
import unittest
from fractions import Fraction

import numpy as np

from src.lower_bound_checks import (
    rising, spherical_scaled_moment, gaussian_domination_moment,
    coarse_transition_log, sharp_transition_log, exact_fejer_certificate,
    nearcritical_log_ratio_bounds, overlap_logdet_diagnostics,
)


class LowerBoundComponentTests(unittest.TestCase):
    def test_spherical_moments_exact(self):
        for d in (1, 2, 3, 7, 16, 101):
            for p in sorted({0, 1, d//2, d}):
                for j in range(15):
                    self.assertLessEqual(spherical_scaled_moment(d, p, j),
                                         gaussian_domination_moment(p, j))
        self.assertEqual(spherical_scaled_moment(7, 3, 1), Fraction(3))
        self.assertEqual(spherical_scaled_moment(7, 7, 4), Fraction(7**4))

    def test_spherical_degenerate_and_invalid(self):
        self.assertEqual(rising(Fraction(3, 2), 0), 1)
        self.assertEqual(spherical_scaled_moment(7, 0, 2), 0)
        for args in ((0, 0, 0), (2, 3, 0), (2, 1, -1)):
            with self.assertRaises(ValueError):
                spherical_scaled_moment(*args)

    def test_goe_covariance_and_mahalanobis_identity(self):
        rng = np.random.default_rng(711)
        for n, t in ((12, 0), (20, 4), (31, 18)):
            frame, _ = np.linalg.qr(rng.normal(size=(n, n)))
            v = frame[:, t]
            old = frame[:, :t]
            e = frame[:, t:]
            p = np.eye(n)-old@old.T
            u = rng.normal(size=n); u /= np.linalg.norm(u)
            lam = 2.5
            mu = lam*(u@v)*(p@u)
            sigma = (e.T@p@e + np.outer(e.T@v, e.T@v))/n
            h = (e.T@mu)@np.linalg.solve(sigma, e.T@mu)
            formula = n*lam**2*(u@v)**2*(np.linalg.norm(p@u)**2-(u@v)**2/2)
            self.assertAlmostEqual(h, formula, places=10)
            self.assertLessEqual(h, n*lam**2*(u@v)**2+1e-10)

    def test_gaussian_likelihood_moment_identity(self):
        # Exact Gaussian MGF algebra, not a Monte Carlo lower-bound test.
        for h in (0., .1, 3., 30.):
            for eta in (.01, .2, 1., 4.):
                p = 1+eta
                log_moment = (p*p-p)*h/2
                self.assertAlmostEqual(log_moment, eta*(1+eta)*h/2, places=10)

    def test_coarse_geometric_bins(self):
        for lam in (2., 3., 10., 100.):
            rho = 16*lam**2
            for T in (1, 10, 100):
                for delta in (float(T), float(T+3), float(10*T)):
                    leading = coarse_transition_log(lam, 1, (rho-1)*delta, T)
                    log_sum = leading-math.log1p(-math.exp(-lam**2/2))
                    self.assertLessEqual(log_sum, math.log(3)-lam**2*delta/3+1e-8)
                    for j in (0, 1, 10, 1000):
                        val = coarse_transition_log(lam, j+1, rho*j+(rho-1)*delta, T)
                        self.assertAlmostEqual(val, leading-lam**2*j/2, delta=1e-7)

    def test_covering_perturbation_factors_exact(self):
        for rho in map(Fraction, (1, 4, 64, 160000)):
            self.assertLessEqual((1+rho)/4, rho/2)
            self.assertLessEqual((1+rho)/8, rho/4)

    def test_rank_one_determinant_identity(self):
        rng = np.random.default_rng(730)
        for n, k, t in ((12, 1, 10), (25, 5, 20), (40, 12, 30)):
            u, _ = np.linalg.qr(rng.normal(size=(n, k)))
            v, _ = np.linalg.qr(rng.normal(size=(n, t)))
            for delta in (.01, 1., 1000.):
                rows = overlap_logdet_diagnostics(u, v, delta)
                self.assertLess(max(x['identity_error'] for x in rows), 1e-10)
                self.assertGreaterEqual(min(x['factor'] for x in rows), 1)

    def test_logarithmic_fixed_accuracy_absorption(self):
        self.assertLess(math.log(320000), 16)
        for L in (64., 65., 128., 1000., 100000.):
            log_lower = L-1+math.log(15/32)-math.log(L)
            self.assertGreaterEqual(log_lower, L/2)
            self.assertLessEqual(16*(1+L/128), 3*L/8)
            self.assertLessEqual(math.log(2*L), L-1)  # Delta <= n.

    def test_goe_net_constants(self):
        self.assertGreater(25/4-math.log(9), 4)
        self.assertLess(2*math.exp(-8), .001)
        for x in (1., 1.5, 2., 10., 1e9):
            self.assertLessEqual(1+math.log(x), x+1e-12)

    def test_nearcritical_geometric_bins(self):
        for s in (1., .5, .1, .01):
            ell = math.log1p(1/s)
            rho = (1+s)**7
            for T in (1, 10, 100):
                delta = max(T*ell/s, 2/s**3)
                for c in (1., 1+s/2, 1+s):
                    for j in (0, 1, 5, 50):
                        z = (1+s)**j*delta
                        a = (1+s)*z-delta
                        b = rho*z-delta
                        actual = sharp_transition_log(s, c, a, b, T)
                        target = -s*s*(z+delta)/2
                        self.assertLessEqual(actual, target+1e-7*max(1, abs(target)))
                self.assertLessEqual(1/(1-math.exp(-s**3*delta/2)), 2.)

    def test_nearcritical_coefficients_exact(self):
        for s in (Fraction(1), Fraction(1, 2), Fraction(1, 10), Fraction(1, 100)):
            lam = 1+s
            self.assertEqual(lam**3-lam**4, -s*lam**3)
            self.assertLessEqual(-lam**2+lam**-2, -2*s)

    def test_gap_and_warmstart_hypotheses(self):
        for eps in np.geomspace(1e-12, 1/16, 101):
            s = 4*math.sqrt(eps); lam = 1+s
            g = s*s/(lam*lam+1)
            self.assertGreaterEqual(g, (16/5)*eps*(1-1e-12))
            self.assertGreater(.97*g, 1.5*eps)
            self.assertGreaterEqual(.98/(1+g/100), .97)
            self.assertLessEqual(g/100, g*min(.5, 1/(lam*lam-1)))
            self.assertLessEqual(eps/200, g/640+1e-16)

    def test_trace_to_many_overlap_constants(self):
        for k in range(1, 200):
            r = math.ceil(k/2); m = k-r+1
            self.assertGreaterEqual(m, k/2)
            self.assertLessEqual(Fraction(k, 100)-Fraction(3*m, 4), -Fraction(365*k, 1000))
        for g in (1e-8, .001, .1, .2):
            lower = (1-g/100)*(1-g/640)
            self.assertGreaterEqual(lower, 1-.012*g-1e-15)

    def test_nearcritical_scale_absorption_without_overflow(self):
        for L in (16384., 20000., 1e5, 1e7):
            self.assertGreaterEqual((L-1)/3-math.log(3200)-2*math.log(L), L/4)
            self.assertGreaterEqual((L-1)/6-math.log(64), L/8)
            self.assertLess(L/512+42, L/128)
            for u in (0., (L-1)/12, (L-1)/6):
                for log_k in (0., 10., 1000.):
                    r = nearcritical_log_ratio_bounds(L, u, log_k)
                    self.assertGreaterEqual(r['minimum'], r['target'])

    def test_fixed_and_nearcritical_failure_absorption(self):
        for k in (1, 10, 1000):
            for L in (64., 128., 16384.):
                self.assertLess((4-20000/3)*k*L, math.log(.001))
                self.assertLess(-48*k*L, math.log(.01))
        self.assertGreater(math.log(2), .5)

    def test_fejer_constant_exact(self):
        cert = exact_fejer_certificate()
        self.assertEqual(cert, Fraction(5860808350, 567567))
        self.assertGreater(cert, 10000)
        self.assertLess(Fraction(25, 2)*11**4, 200000)
        self.assertLess(Fraction(9, 2000), Fraction(1, 200))

    def test_fejer_polynomial_identity(self):
        from numpy.polynomial import Polynomial, Chebyshev
        for m in range(1, 16):
            t = Chebyshev.basis(m).convert(kind=Polynomial)
            quotient, remainder = divmod(t-Polynomial([1]), Polynomial([-1, 1]))
            self.assertLess(np.max(np.abs(remainder.coef)), 1e-9)
            expected = Chebyshev([m]+[2*(m-j) for j in range(1, m)])
            points = np.linspace(-1., 1.5, 101)
            np.testing.assert_allclose(quotient(points), expected(points), rtol=1e-8, atol=1e-7)

    def test_weighted_graph_and_noncommuting_trace(self):
        rng = np.random.default_rng(734)
        for eps in (.001, .1, .49):
            k, n = 4, 17
            leading = 1+1.5*eps+np.arange(k)*.7
            tail = np.linspace(-1, 1, n-k)
            tau = 1+eps
            raw = rng.normal(size=(n-k, k)); raw /= np.linalg.norm(raw, 2)
            f = np.sqrt(tau*tau-tail*tail)[:, None]*raw/np.sqrt(leading*leading-tau*tau)[None, :]
            y, _ = np.linalg.qr(np.vstack((np.eye(k), f)))
            mat = np.diag(np.r_[leading, tail])
            self.assertLessEqual(np.linalg.norm(mat-(mat@y)@y.T, 2), tau+1e-10)
            loss = leading.sum()-np.trace(y.T@mat@y)
            bound = np.sum((leading[None, :]-tail[:, None])*f*f)
            self.assertLessEqual(loss, bound+1e-9)

    def test_trace_compression_weyl_component(self):
        rng = np.random.default_rng(729)
        n, k = 40, 7
        u, _ = np.linalg.qr(rng.normal(size=(n, k)))
        v, _ = np.linalg.qr(rng.normal(size=(n, k)))
        raw = rng.normal(size=(n, n)); w = (raw+raw.T)/2
        w /= np.linalg.norm(w, 2)
        lam = 1.2
        compressed = v.T@(w+lam*u@u.T)@v
        c = v.T@u@u.T@v
        self.assertTrue(np.all(np.linalg.eigvalsh(compressed)
                               <= 1+lam*np.linalg.eigvalsh(c)+1e-10))

    def test_query_extension_dimension_and_overlap(self):
        rng = np.random.default_rng(710)
        n, k, q = 30, 5, 9
        u, _ = np.linalg.qr(rng.normal(size=(n, k)))
        old, _ = np.linalg.qr(rng.normal(size=(n, q)))
        z, _ = np.linalg.qr(rng.normal(size=(n, k)))
        total, _ = np.linalg.qr(np.column_stack((old, z)))
        self.assertEqual(total.shape[1], q+k)
        delta = u.T@(total@total.T-z@z.T)@u
        self.assertGreaterEqual(np.linalg.eigvalsh(delta)[0], -1e-10)


if __name__ == '__main__':
    unittest.main()
