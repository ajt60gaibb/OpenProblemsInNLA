# Source inventory and use

Public sources were read through the website; no GitHub plugin was used. The prior artifacts are preserved as user-provided research context and are not treated as independently reviewed publications.

## 1. RA-14 problem statement

Title: Optimal query complexity of spectral rank-k approximation.
Repository: OpenProblemsInNLA.
Canonical location:
https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/RA-14
Text read at:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RA-14/README.md
Consulted during this continuation, September 12–13, 2026 (local/UTC boundary).

Used for the exact two-sided oracle, individual-vector query charge, pointwise probability 0.99, rank-k orthonormal output, and simultaneous finite-parameter scope. The residual optimum equals sigma_(k+1) by the singular-value min–max principle. This package does not change repository files or assert the repository problem is solved.

## 2. Simchowitz–El Alaoui–Recht

Max Simchowitz, Ahmed El Alaoui, Benjamin Recht.
Tight Query Complexity Lower Bounds for PCA via Finite Sample Deformed Wigner Law.
STOC 2018; arXiv:1804.01221v2 (2020).
https://arxiv.org/abs/1804.01221v2
https://arxiv.org/html/1804.01221v2

Imported theorem: Theorem 6.1, finite-sample spectrum of W+lambda UU^T. Its conditions and probability are reproduced in report Section 6. All scaling parameters and the sufficient dimension condition are then derived explicitly. This is the only non-elementary imported probability theorem needed for the new shrinking-accuracy result.

Methodological antecedents: Sections 4–5 and Appendix E use directional conditioning, information control, and a determinant potential. The manuscript credits that framework and supplies complete proofs of the particular sharper estimates it uses. No priority claim is made for the methodology or conclusions.

Not imported as an all-parameter result: the paper's adaptive PCA query theorem. No dimension restriction from that theorem is silently discarded.

## 3. Previous generated RA-14 note

RA-14: Bounds and a spectral-to-PCA reduction.
September 12, 2026.
Original files in prior/:
- RA14_research_note.pdf
- RA14_research_package.zip

Used for the Gaussian rank lower bound and the spectral-to-PCA warm-start postprocessor. Both proofs are reproduced in the new manuscript. The original artifacts remain partial, unreviewed research notes. Their other lower-bound claims retain their original hypotheses.

## 4. Previous generated continuation v3

RA-14: A Dimension-Sensitive Upper Bound and Lower-Bound Audit.
September 12, 2026.
Original files in prior/:
- RA14_continuation_v3.pdf
- RA14_continuation_v3.zip

Used for the all-parameter upper bound min{n, ceil(12000 k log(en/k)/sqrt(epsilon))}. Its proof was audited and condensed in Appendix A. Its implementation and test file are copied unchanged to upper_bound/. The original complete archive is also preserved.

## 5. Context, not a dependency of the new lower bounds

Cameron Musco and Christopher Musco.
Randomized Block Krylov Methods for Stronger and Faster Approximate Singular Value Decomposition.
2015, arXiv:1504.05477.
https://arxiv.org/abs/1504.05477

Ainesh Bakshi and Shyam Narayanan.
Krylov Methods are (nearly) Optimal for Low-Rank Approximation.
2023, arXiv:2304.03191v1.
https://arxiv.org/abs/2304.03191v1
https://arxiv.org/html/2304.03191v1

The latter is the repository problem's source and supplies the previous package's dimension-restricted rank-one hard family. The new constant-accuracy proof does not depend on that family or on a direct sum of rank-one lower bounds.

## Attribution limits

Only mathematical statements and source metadata needed to inspect the arguments are restated. No full external paper is redistributed. The unchanged earlier user-provided archives may contain their own source records; those are preserved as provenance, not silently revised.
