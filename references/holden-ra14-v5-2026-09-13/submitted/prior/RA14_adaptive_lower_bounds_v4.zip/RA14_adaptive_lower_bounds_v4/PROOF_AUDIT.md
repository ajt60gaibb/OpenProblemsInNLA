# RA-14 v4 proof audit

## Overall conclusion

PARTIAL for the full RA-14 problem. The manuscript gives a complete mathematical argument for the constant-accuracy rank/dimension dependence and for a sufficient shrinking-accuracy regime. This is an internal audit of a generated proof, not independent peer review or formal verification.

## Model

One Ax or A^T x is one query; block columns are charged individually. Queries are exact real vectors, arbitrarily adaptive and measurable. Arithmetic is unrestricted. The guarantee is 0.99 for each fixed input. The lower bounds use symmetric inputs, so the two oracle directions coincide without weakening the adversary. Probability in applications includes the algorithm's random seed; the information lemmas hold separately for each seed and therefore survive averaging.

## Rank lower bound (Section 2)

The hard matrix is nonsymmetric A = [H^T; 0], with H an n by k Gaussian matrix. The conditional unobserved block is P_(X-perp) G P_(C-perp). Both oracle directions are included. The case X-perp contained in the output subspace is explicitly handled through the almost-sure rank of H^T X, rather than dismissed by dimension counting. Rank-k inputs have zero optimal residual, so success requires exact row-space recovery.

## Adaptive likelihood (Section 3)

1. Fix a deterministic direction e in R^k before taking a net. Rotate column coordinates of U so u=Ue is the first column. Condition on the other k-1 columns B.
2. u remains uniform on the unit sphere of B-perp, dimension D=n-k+1. B is a conditioning variable for the proof, not side information given to the algorithm.
3. Compare W+lambda BB^T+lambda uu^T with W+lambda BB^T. Under the latter, u is independent of the transcript conditional on B.
4. Project each response off the previous query span. Symmetry makes the removed part known from earlier responses. In the remaining orthonormal coordinates, the covariance is n^(-1)(I+vv^T), the same in both experiments.
5. Deferred Gaussian decisions hold with adaptive queries: the next direction is fixed given the past, and the fresh trailing block remains GOE with variance normalization 1/n.
6. The mean shift is lambda <u,v> P u. Its squared Mahalanobis norm is at most n lambda^2 <u,v>^2.
7. The likelihood-power identity is controlled by a mean-one exponential martingale. The truncation S_t <= a is retained; no unjustified unconditional second-moment bound is substituted.
8. The event S_(t+1)>b uses only the first t responses because the next vector is predictable. This makes the change of measure use L_t, not L_(t+1).
9. Conditional reference independence allows the spherical moment bound. It is proved for a frame not necessarily contained in B-perp and also handles frame rank >= D.
10. Each net direction has its own legitimate comparison law. The final probabilities are under the same actual planted law, so a union bound over directions is valid.

## Matrix and determinant growth (Sections 4 and 5)

- A_t=n U^T P_t U satisfies 0 <= A_t <= nI pathwise.
- At constant spike strength, the net radius is Delta/(8n), with cardinality at most (1+16n/Delta)^k.
- Near criticality, the net radius is s Delta/(16n), with cardinality at most (1+32n/(s Delta))^k.
- A stronger Loewner-factor violation creates enough ridge margin to survive approximation by a net point. Both perturbation constants are written out.
- The bins are unit-width at constant strength and geometrically spaced in S_t+Delta near criticality. The bin sums include all possible S_t, not just an assumed typical range.
- A single orthonormal query adds rank at most one. Under B_(t+1) <= R B_t, the determinant ratio is at most R, not R^k. The rank-one matrix determinant argument is explicit.
- The theorem assumes T <= n and the ridge satisfies Delta <= n. The applications verify these inequalities rather than presume them.

## Constant-accuracy application (Section 4)

The spike lambda=100 and event ||W||<=10 are used only for a simple uniform planted-overlap implication. The norm event is proved by an elementary GOE net calculation. A successful spectral residual implies U^T ZZ^T U >= (15/16)I. The query span is extended to contain Z, costing at most k queries; T=q+k. The ridge is 2k log(en/k). The small-log-ratio case is handled separately by q>=k. The remaining numerical inequalities are proved continuously after their endpoints, not inferred from tests. No imported spectral or PCA query theorem is needed here.

## Shrinking-accuracy application (Sections 6–8)

**Imported dependency:** only SER Theorem 6.1, arXiv v2, for finite-sample eigenvalue and noise-norm bounds. Its statement, normalization, precision restriction, dimension threshold, and probability are reproduced. The paper's full query lower bound is not imported or extended without its hypotheses.

Choose s=4 sqrt(epsilon), lambda=1+s, g=s^2/(lambda^2+1), spectral precision g/100, kappa=1/100, and failure parameter 1/900. The displayed sufficient dimension condition has an epsilon^(-3) factor because g is of order s^2. It includes k+log(1/epsilon) and a universal constant that may be enormous.

The spectral event implies positive top eigenvalues, a bounded-magnitude tail, and the gap needed by the warm-start theorem. The warm-start proof is reproduced: a weighted graph inequality, a Fejer-type polynomial, a noncommuting trace inequality, scalar coefficient control, and charged block-Krylov extraction. The postprocessor never receives the unknown spectral scale.

A separate compression/Weyl argument turns the postprocessed trace guarantee into at least ceil(k/2) planted overlap eigenvalues of size beta=s^2/(4lambda^2). The corresponding two Gram matrices have the same nonzero eigenvalues. Appending the output costs k more queries. Total T <= q+42k/s. This overhead is subtracted through an explicit contradiction, not omitted.

The sharp ridge is 100 k L log(1+1/s)/s^2 + 2/s^3. The proof checks the probability bound, T<=n, Delta<=n, and log(n beta/Delta)>=L/8. The very large universal dimension constant absorbs L>=16384; it is not presented as a practical threshold.

## Upper bound (Appendix A)

The prior construction is preserved and condensed. M=A^T A costs two original queries per vector. A Gaussian block-Krylov calculation estimates the unknown sigma_(k+1)^2 scale. A fresh polynomial sketch is extracted using RIGHT singular vectors of Q^T H, not an unsupported algebraic Ritz substitution for an indefinite H. Scalar functional calculus transfers the coarse surrogate residual. The rank-zero-tail branch, compression products, Gaussian event probabilities, ceilings, and exact n-query fallback are all retained.

## What is not proved

- A matching lower bound for every finite n,k,epsilon.
- The sharp complexity at k=1, epsilon=1/n.
- A universal n lower bound in every regime where the known upper bound takes the n cap.
- A direct-sum theorem obtained by multiplying a visible rank-one hard block by k.
- A lower bound for arbitrary adaptive algorithms merely from a Krylov-depth bound.
- A numerically useful estimate of the universal C in the shrinking-accuracy dimension condition.
- Independent peer review, proof-assistant certification, or priority.

## Tests and artifacts

Twenty new component tests and seventeen unchanged v3 tests passed in the recorded run. Every determinant diagnostic row is retained. Tests can catch algebraic, coding, and constant mistakes but cannot verify the all-adaptive quantifier. The SHA-256 manifest certifies only file integrity.
