"""Finite checks for the inequalities in report.tex, not a lower-bound verifier.

The proofs quantify over arbitrary adaptive algorithms. No finite computation in
this module certifies that quantifier. Exact rational identities are separated
from double-precision matrix diagnostics and logarithmic scalar checks.
"""
from __future__ import annotations

import math
from fractions import Fraction
from typing import Any

import numpy as np
from numpy.typing import NDArray

FloatArray = NDArray[np.float64]


def rising(a: Fraction, degree: int) -> Fraction:
    if degree < 0:
        raise ValueError("degree must be nonnegative")
    out = Fraction(1)
    for j in range(degree):
        out *= a + j
    return out


def spherical_scaled_moment(dimension: int, rank: int, degree: int) -> Fraction:
    """Exact E[(D sum_{j<=p} u_j^2)^degree], for 0 <= p <= D."""
    if dimension < 1 or not 0 <= rank <= dimension or degree < 0:
        raise ValueError("require D >= 1, 0 <= p <= D, degree >= 0")
    return (Fraction(dimension) ** degree * rising(Fraction(rank, 2), degree)
            / rising(Fraction(dimension, 2), degree))


def gaussian_domination_moment(rank: int, degree: int) -> Fraction:
    if rank < 0 or degree < 0:
        raise ValueError("rank and degree must be nonnegative")
    return Fraction(2) ** degree * rising(Fraction(rank, 2), degree)


def coarse_transition_log(lam: float, a: float, b: float, next_rank: int) -> float:
    if lam <= 0 or a < 0 or b < 0 or next_rank < 1:
        raise ValueError("invalid transition parameters")
    return lam * lam * a / 2 + next_rank / 4 - b / 16


def sharp_transition_log(s: float, c: float, a: float, b: float,
                         next_rank: int) -> float:
    if not 0 < s <= 1 or not 1 <= c <= 1+s or a < 0 or b < 0 or next_rank < 1:
        raise ValueError("invalid near-critical transition parameters")
    return s / 2 * ((1+s)**2*a - b/(c*(1+s)**2)
                    + next_rank/(1+s)*math.log1p(1/s))


def exact_fejer_certificate() -> Fraction:
    return sum((Fraction(10**(2*j), math.factorial(2*j)) for j in range(1, 8)),
               start=Fraction(0))


def nearcritical_log_ratio_bounds(L: float, u: float, log_k: float = 0.0
                                  ) -> dict[str, float]:
    """Check huge formal parameter ranges without constructing exp(L) matrices.

    L=log(en/k), u=log(1/s), log_k=log(k). This computes the two
    logarithms on the RHS of report equation (9.4). It is scalar algebra,
    not an experiment with a matrix of that dimension.
    """
    if L < 1 or u < 0 or log_k < 0 or 6*u > L-1+1e-10:
        raise ValueError("require L >= 1, log k >= 0, 0 <= 6u <= L-1")
    ell = u + math.log1p(math.exp(-u))  # log(1+exp(u)), stable for huge u.
    log_x = L - 1
    first = log_x - 4*u - math.log(3200) - math.log(L) - math.log(ell)
    second = log_k + log_x - 5*u - math.log(64)
    return {"first": first, "second": second,
            "minimum": min(first, second), "target": L/8}


def overlap_logdet_diagnostics(u: FloatArray, v: FloatArray,
                              ridge: float) -> list[dict[str, Any]]:
    """Rank-one update identities for prescribed orthonormal frames.

    This function receives U and V in full. It is diagnostic code, NOT an
    oracle algorithm and NOT a demonstration of a universal lower bound.
    """
    u = np.asarray(u, dtype=float)
    v = np.asarray(v, dtype=float)
    if u.ndim != 2 or v.ndim != 2 or u.shape[0] != v.shape[0]:
        raise ValueError("U and V must be matrices with the same row count")
    n, k = u.shape
    if not 1 <= k <= n or not 1 <= v.shape[1] <= n or ridge <= 0:
        raise ValueError("invalid dimensions or ridge")
    if not np.isfinite(u).all() or not np.isfinite(v).all() or not math.isfinite(ridge):
        raise ValueError("inputs must be finite")
    if not np.allclose(u.T@u, np.eye(k), atol=1e-10):
        raise ValueError("U must have orthonormal columns")
    if not np.allclose(v.T@v, np.eye(v.shape[1]), atol=1e-10):
        raise ValueError("V must have orthonormal columns")
    b = ridge*np.eye(k)
    out = []
    for i in range(v.shape[1]):
        w = math.sqrt(n)*(u.T@v[:, i])
        exact_factor = 1 + float(w@np.linalg.solve(b, w))
        new = b + np.outer(w, w)
        sign0, log0 = np.linalg.slogdet(b)
        sign1, log1 = np.linalg.slogdet(new)
        if sign0 <= 0 or sign1 <= 0:
            raise ArithmeticError("positive-definite determinant lost numerically")
        out.append({"step": i+1, "logdet_increment": float(log1-log0),
                    "log_rank_one_factor": math.log(exact_factor),
                    "factor": exact_factor,
                    "identity_error": abs(float(log1-log0)-math.log(exact_factor))})
        b = new
    return out
