"""Run all checks, preserving stdout, stderr, exit codes, and diagnostics."""
from __future__ import annotations

import csv
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

import numpy as np
from src.lower_bound_checks import overlap_logdet_diagnostics, exact_fejer_certificate

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'


def run_suite(name: str, cwd: Path, test_dir: str) -> dict:
    proc = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', test_dir, '-v'],
                          cwd=cwd, text=True, capture_output=True,
                          env={**os.environ, 'OPENBLAS_NUM_THREADS': '1'})
    (RESULTS / f'{name}.stdout.txt').write_text(proc.stdout)
    (RESULTS / f'{name}.stderr.txt').write_text(proc.stderr)
    return {'name': name, 'exit_code': proc.returncode,
            'stdout': f'{name}.stdout.txt', 'stderr': f'{name}.stderr.txt'}


def main() -> int:
    RESULTS.mkdir(exist_ok=True)
    suites = [run_suite('lower_bound_components', ROOT, 'tests'),
              run_suite('unchanged_v3_upper_bound', ROOT / 'upper_bound', 'tests')]
    rng = np.random.default_rng(9142026)
    rows = []
    for trial in range(30):
        n, k, t = 48, 6, 24
        u, _ = np.linalg.qr(rng.normal(size=(n, k)))
        v, _ = np.linalg.qr(rng.normal(size=(n, t)))
        for ridge in (.1, 1., 100.):
            for row in overlap_logdet_diagnostics(u, v, ridge):
                rows.append({'trial': trial, 'n': n, 'k': k, 'ridge': ridge, **row})
    with (RESULTS / 'determinant_component_checks.csv').open('w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    summary = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'environment': {'python': platform.python_version(), 'numpy': np.__version__,
                        'platform': platform.platform()},
        'suites': suites,
        'all_suites_passed': all(s['exit_code'] == 0 for s in suites),
        'determinant_component_rows': len(rows),
        'maximum_determinant_identity_error': max(row['identity_error'] for row in rows),
        'exact_fejer_certificate': str(exact_fejer_certificate()),
        'limitations': [
            'Finite component checks do not certify a lower bound against every adaptive algorithm.',
            'The random determinant diagnostics are not oracle algorithms and do not test sharpness.',
            'The imported finite-sample spectral theorem is not verified numerically.',
            'The upper-bound suite is preserved unchanged from v3; it is not new lower-bound evidence.',
            'Floating-point tests differ from the exact-real model in the theorems.'
        ]
    }
    (RESULTS / 'verification.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))
    return 0 if summary['all_suites_passed'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
