"""Verify SHA-256 file integrity. This does not verify the mathematical proofs."""
from __future__ import annotations

import hashlib
from pathlib import Path
import sys


def main() -> int:
    root = Path(__file__).resolve().parent
    manifest = root / 'MANIFEST.sha256'
    if not manifest.is_file():
        print('Missing MANIFEST.sha256', file=sys.stderr)
        return 2
    failures = []
    count = 0
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        expected, relative = line.split('  ', 1)
        path = (root / relative).resolve()
        if root not in path.parents:
            failures.append((relative, 'unsafe manifest path'))
            continue
        if not path.is_file():
            failures.append((relative, 'missing'))
            continue
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        count += 1
        if actual != expected:
            failures.append((relative, 'hash mismatch'))
    if failures:
        for relative, reason in failures:
            print(f'FAIL: {relative}: {reason}')
        return 1
    print(f'All {count} listed files match their SHA-256 hashes. This verifies file integrity only.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
