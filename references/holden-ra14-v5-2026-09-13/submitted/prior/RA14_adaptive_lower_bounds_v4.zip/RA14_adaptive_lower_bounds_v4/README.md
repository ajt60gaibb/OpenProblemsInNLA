# RA-14 — Adaptive lower bounds, continuation v4

**Full-problem status: PARTIAL.** This package supplies a complete written argument for the fixed-accuracy characterization and a stronger dimension-restricted shrinking-accuracy result. It does **not** determine the query complexity for every simultaneous finite choice of n, k, and epsilon. The arguments have not undergone independent peer review or proof-assistant verification; no mathematical priority is claimed.

## Results in this continuation

For every n >= 2, 1 <= k < n, and 0 < epsilon < 1/2, the new adaptive lower bound is

    q_sp(n,k,epsilon) >= (k/128) log(en/k).

The universal q_sp >= k bound is also reproduced. Combining these with the preceding, audited upper bound gives

    max{k, (k/128) log(en/k)} <= q_sp
      <= min{n, ceil(12000 k log(en/k) / sqrt(epsilon))}.

Thus, for any fixed epsilon_0 > 0, the query complexity is Theta(k log(en/k)), uniformly over all n, k and epsilon in [epsilon_0, 1/2). Constants may depend on epsilon_0; on the particular interval [1/16, 1/2), they are universal. The lower bound covers arbitrary adaptive real queries, not only Krylov algorithms.

**Previously explicit gap closed:** when epsilon = 1/4 and k = floor(n/log n), the complexity is now characterized as

    Theta(n log log n / log n).

There is also a universal C such that, for 0 < epsilon <= 1/16,

    n >= C epsilon^(-3) (k + log(1/epsilon))

implies

    q_sp >= k log(en/k) / (2048 sqrt(epsilon)).

This matches the upper bound. C is deliberately unoptimized, is not numerically evaluated, and can be enormous: the proof absorbs log(en/k) >= 16384 and the universal constant in an imported finite-sample spectral theorem. This is a sufficient condition, not a necessary boundary for the problem.

## What the proof actually does

The hard input is W + lambda U U^T, where W is a normalized GOE matrix and U is a uniform orthonormal k-frame. For each fixed direction in the planted subspace, the proof conditions on the other k-1 columns and compares the adaptive transcript to a rank-(k-1) reference law. A Gaussian likelihood calculation and a spherical exponential-moment bound control the growth of information in that direction.

The covering radius retains a ridge Delta, rather than discarding it. This makes the covering size depend on n/Delta. Each query adds a rank-one positive semidefinite increment to the overlap matrix. Consequently its regularized determinant grows by at most one factor per query, not one factor per dimension per query. This is where the k times logarithm lower bound comes from.

For shrinking epsilon, the information calculation is sharpened at lambda = 1 + 4 sqrt(epsilon). The only imported non-elementary probability theorem is **Theorem 6.1 of Simchowitz–El Alaoui–Recht, arXiv:1804.01221v2**, about the finite-sample spectrum of a deformed Wigner matrix. The note reproduces the spectral-to-PCA postprocessor and charges all of its matrix products, as well as the queries used to include the output in the transcript span.

The directional-conditioning and determinant framework has antecedents in that paper. This package does not claim that the framework itself is new.

## Remaining gap

For example, k = 1 and epsilon = 1/n does not satisfy the new shrinking-accuracy dimension condition for large n. This package does not give a matching lower bound for the O(sqrt(n) log n) upper bound there. Nor may the n-query exact-learning upper cap simply be placed around a restricted lower bound and asserted globally.

No file in this package labels full RA-14 as solved.

## Contents

- `report.pdf`, `report.tex`: the mathematical note, with all new lower-bound proofs, the warm-start proof, and a condensed upper-bound proof.
- `PROOF_AUDIT.md`: hypotheses, conditioning, query accounting, and proof dependencies.
- `STATUS.json`: machine-readable claim and status inventory.
- `src/lower_bound_checks.py`, `tests/test_lower_bounds.py`: exact rational and finite numerical component checks.
- `upper_bound/`: the v3 upper-bound implementation and its tests, copied unchanged.
- `results/`: actual test logs, verification summary, and every determinant-identity diagnostic row.
- `sources/SOURCES.md`: primary-source locations and the claims used.
- `prior/`: both original PDFs and both original ZIPs, unchanged.
- `verify_manifest.py`, `MANIFEST.sha256`: package integrity checks, not proof verification.

## Reproduce

Python 3.10 or later and NumPy are sufficient for the checks. The recorded run used Python 3.13.5 and NumPy 2.3.5.

```bash
python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 python run_checks.py
python verify_manifest.py
pdflatex -interaction=nonstopmode -halt-on-error report.tex
pdflatex -interaction=nonstopmode -halt-on-error report.tex
```

**Recorded outcome:** 20 new component tests and 17 unchanged v3 implementation tests passed. There are 2,160 rank-one determinant identity rows from 90 prescribed-frame diagnostic sequences. Their maximum recorded floating-point identity error was about 1.175e-14. These are not adaptive lower-bound trials; the diagnostic code receives the frames in full and is not an oracle algorithm. It checks identities, not sharpness or universal impossibility.

Running checks or recompiling will change generated files and timestamps. Verify the original manifest before rerunning; subsequent differences in those regenerated files are expected. Numerical results can vary with the platform.

No elapsed-work-time, independent-certification, or mathematical-priority claim is made.
