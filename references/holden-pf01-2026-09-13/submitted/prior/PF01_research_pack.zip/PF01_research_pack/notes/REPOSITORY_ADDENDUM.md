# Possible PF-01 addendum — not submitted

This text is a draft for review. It is not a patch, and no repository file has been changed. The existing status is already “Partially resolved”; the present package does not justify “Solution claimed,” “Solved,” or “Lean verified.”

## Partial bounds

A stereographic graph construction gives real symmetric PSD factors of size

\[
\left\lceil 2\sqrt{n-2}\right\rceil
\]

for every n>=3. Separately, an algebraic obstruction rules out factor size k when n=k(k+1)/2 and k>=3. Together with the previously established order-five value, these arguments give, for n>=5,

\[
\max\left\{4,\left\lceil\frac{\sqrt{8n+9}-1}{2}\right\rceil\right\}
\le \operatorname{rank}_{\rm psd}(M^{(n)})
\le \left\lceil2\sqrt{n-2}\right\rceil.
\]

The upper bound improves the previously displayed construction by one at n=11,27,51,83,... . The lower bound improves the ordinary-rank bound at triangular orders. The exact ranks for n=7,8 remain between four and five; the full function remains undetermined by these arguments.

## Evidence and attribution

Reference: `paper/pf01_bounds.pdf` and its TeX source in this package. Verification: included symbolic and exact finite checks plus floating-point construction tests; self-review only. No independent audit or proof-assistant verification has been performed. The equality at n=5 and the already established n=6 result remain attributed to Colbrook's cited manuscript. Attribution, priority, and the new mathematical arguments should be independently reviewed before repository admission.
