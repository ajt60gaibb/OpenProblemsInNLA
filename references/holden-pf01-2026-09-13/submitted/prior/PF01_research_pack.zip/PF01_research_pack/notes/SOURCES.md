# Sources and attribution

Public sources were checked on 12 September 2026. The repository's canonical README is used in preference to any older generated problem PDF or TeX. No GitHub connector or plugin was used.

## Canonical problem and scope

Open Problems in Numerical Linear Algebra, PF-01, “Exact positive semidefinite rank of subset-intersection matrices.” The page defines real symmetric factors and asks for the exact function for all n>=5. Its 11 September update gives exact values for n=5,6 and identifies n>=7 as the remaining target.

- https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/nonnegative-and-positive-factorizations/PF-01
- https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/nonnegative-and-positive-factorizations/PF-01/README.md

## Prior partial results

Matthew J. Colbrook, *Positive semidefinite ranks of the five- and six-element subset-intersection matrices*, 11 September 2026. Theorem 1, Corollary 5, and equation (8) supply the prior small-order values and comparison upper bound.

- https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/references/colbrook-factorization-2026-09-11/manuscripts/PF-01_subset_intersection.tex
- https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/references/colbrook-factorization-2026-09-11/manuscripts/PF-01_subset_intersection.tex
- https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/references/colbrook-factorization-2026-09-11/verification/reviews/PF-01-review.md

That review concerns Colbrook's existing manuscript, not the arguments in this package. The repository describes it as an independent agent review, not external human peer review or formal verification.

## Original problem source

Hamza Fawzi, Joao Gouveia, Pablo A. Parrilo, Richard Z. Robinson, and Rekha R. Thomas, *Positive semidefinite rank*, Mathematical Programming 153 (2015), 133-177. Section 9.1, especially Problem 9.2, poses the family.

- https://arxiv.org/html/1407.4095

## Computational benchmark source

Arnaud Vandaele, Francois Glineur, and Nicolas Gillis, *Algorithms for Positive Semidefinite Factorization*, Computational Optimization and Applications 71 (2018), 193-219. Section 4.2 of the preprint discusses the subset-intersection benchmark. It is not used to turn numerical factor searches into exact lower bounds.

- https://arxiv.org/html/1707.07953
- https://arxiv.org/pdf/1707.07953

## Repository status definitions

The repository distinguishes an improved partial bound from a complete resolution of the exact target. No status change or submission has been made as part of this work.

- https://github.com/ajt60gaibb/OpenProblemsInNLA#problem-status
- https://github.com/ajt60gaibb/OpenProblemsInNLA/blob/main/CONTRIBUTING.md

## Literature-search limitation

The sources above and targeted searches were checked to establish the problem, existing partial results, and comparison bounds. Failure to locate an earlier occurrence of an argument is not evidence that no such occurrence exists. The package claims an improvement relative to the checked repository bounds, not a certified priority result or an exhaustive literature review.
