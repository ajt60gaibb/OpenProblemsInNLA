# Proof dependency and self-review record

This is a self-review of the included arguments, not an independent audit. The target is real PSD rank, not complex Hermitian PSD rank, nonnegative rank, square-root rank, or the size of an equivariant factorization.

## Explicit upper factors

1. Both incidence matrices have full column rank n, hence rank(M)=n. Column complementation gives D[I,K] = r-|I intersect K|.
2. Centered incidence vectors lie on a sphere of radius sqrt(r(n-r)/n) in the (n-1)-dimensional zero-sum subspace.
3. The pole v=(e1-e2)/sqrt(2) has dot products in {0, +/-1/sqrt(2)}. The radius is strictly larger than 1/sqrt(2) for all n>=3; every denominator lambda_I is positive.
4. The transverse Helmert coordinates are an isometry into dimension n-2. Padding and reshaping into a by b matrices preserve their inner products.
5. The factors are positive scalar multiples of explicit rectangular Gram matrices. Their PSD property does not depend on a numerical eigenvalue computation.
6. The trace is lambda_I lambda_K/2 times the squared distance between the rescaled rectangular coordinates. Substituting the spherical identity yields D exactly.
7. Minimizing a+b over positive integers with ab>=n-2 gives ceil(2 sqrt(n-2)). Optimality inside this graph class does not imply optimality among all PSD factors.

Exact coordinate checks cover every ordered pair for n=3,...,11. Symbolic graph identities and direct floating-point factor tests are separate checks.

## Strict triangular lower obstruction

The proof begins with an unrestricted factorization at n=k(k+1)/2 and k>=3. It assumes no equivariance, no prescribed ranks of individual factors, no equality between the two factor families, and no affine dependence until that dependence is forced by full spans.

1. Ordinary rank forces both factor spans to equal the entire space of symmetric k by k matrices. Comparing column spaces of the coordinate factorization with the incidence matrices produces trace-dual bases X_i,Y_i.
2. The identity sum_i X_i Y_i = ((k+1)/2) I is invariant under an arbitrary dual change of basis, not merely an orthonormal change. This is important because the normalized bases need not be orthogonal.
3. The sums S=sum X_i and T=sum Y_i are positive definite: each is a positive multiple of a sum of PSD factors with full span. The zero entries for complementary subsets imply A_I B_Ic=0, not just trace zero.
4. Averaging these identities gives ST=tI, enabling a congruence normalization S=I, T=tI. It does not rely on assuming ST is symmetric in advance.
5. A second, conditional average yields (n-2r) X_iY_i=(s-1)tX_i-(r-1)Y_i. In the even case this gives Y_i=tX_i. In the odd case it makes X_iY_i symmetric. Thus each dual pair commutes.
6. The quadratic polynomial [sum x_i X_i, sum x_i Y_i] has no square terms and vanishes on the fixed-cardinality Boolean slice. The quadratic-slice lemma makes it identically zero.
7. The dual-basis map Phi(X)=sum tr(XY_i)Y_i is self-adjoint and positive definite. Its commuting property forces Phi(X)=alpha X+beta tr(X)I with alpha>0.
8. Complementary-factor orthogonality now makes every row factor the same positive scalar times a projection.
9. The affine-projection lemma rules out a full-span family of this form for k>=3 and r>=3. Its proof uses commutator identities and a two-dimensional diagonal intersection, not an unproved classification of Clifford representations.

Every denominator divided by in the lower argument is nonzero in the stated range: r>=3, s>=3, n>=6, t>0. The use of r!=2 in the projection lemma is essential; it is not applied to n=5.

## Imported result

The order-five equality rank_psd(M^(5))=4 is the only prior nontrivial lower result needed by the combined theorem. It is attributed to Colbrook's 11 September 2026 manuscript and is not re-proved here. At n=6 the two new arguments themselves give equality four, but that equality was already established in the checked repository.

## Boundary of the argument

The full-span step is unavailable when n<k(k+1)/2. Additional factor directions invisible to the incidence pairing need not disappear. The proof does not assume them away. In particular, it does not rule out size four for n=7 or n=8, nor size five for n=11.

The tests establish exact identities for their stated finite sizes and numerical agreement for the supplied floating-point factors. They do not independently validate the general proofs, establish global novelty, or promote PF-01 to a complete solution. External mathematical review should focus first on the conditional-average calculation, the full-span inference, and the projection-family obstruction.
