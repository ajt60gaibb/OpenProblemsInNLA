# RA-17: index obstructions and exact corank-one cases

**Status: PARTIAL. This archive is not an all-dimension solution of RA-17.**

The new argument closes the two gaps highlighted in the previous package:

\[
\mu_{\mathbb R}(12,5)=139,\qquad \mu_{\mathbb R}(16,7)=247.
\]

The main deliverable is **`writeup/RA17_index_obstructions.pdf`** (19 pages), with editable LaTeX beside it. It contains complete written arguments for the new index obstruction, a general binary-digit lower bound, matching constructions in exact families, exact certificate methodology, and a precise account of what remains missing. The topology is not proof-assistant formalized or independently peer reviewed. The executed computer checks establish the stated arithmetic identities and matrix certificates; they are not a substitute for the written topological proofs.

## Results established in the write-up

For even `d`, let `a = v_2(d)` and let `kappa` be the largest dimension of a real linear subspace of `d x d` matrices whose nonzero members have rank at least `d-1`. The new obstruction is

\[
\kappa\leq 2a+1+(a\bmod2).
\]

It is sharp for `a=1`, `a=2`, `a=0 mod 4` with `a>=4`, and `a=3 mod 4`. The matching constructions use anti-diagonals, the exactly certified Xu pencil with octonion blocks, or explicitly generated Hurwitz–Clifford matrices. Examples include:

| Pair `(d,r)` | Earlier package | Updated exact count |
|---|---:|---:|
| `(12,5)` | 138–139 | **139** |
| `(16,7)` | 246–247 | **247** |
| `(20,9)` | 394–395 | **395** |
| `(28,13)` | 778–779 | **779** |

Other exact instances of the same families include `(48,23): 2295` and `(256,127): 65519`. Mathematical priority over the literature is not asserted.

For every even `d=2n` and `1<=r<n`, the manuscript evaluates a Grassmannian characteristic number as an exact Hankel determinant. Its dyadic denominator has a finite binary-digit expression. Integrality of total and half-spin Dirac indices then gives a lower bound on the required number of measurements. Two elementary propagation rules transfer bounds between dimensions and ranks. These are necessary conditions, not a sufficient test or an exact classification.

## What remains undetermined by these arguments

The archive deliberately leaves intervals rather than assigning unsupported exact values:

\[
19\leq\mu_{\mathbb R}(6,1)\leq20,\qquad
35\leq\mu_{\mathbb R}(10,1)\leq36,
\]
\[
1012\leq\mu_{\mathbb R}(32,15)\leq1014,\qquad
4083\leq\mu_{\mathbb R}(64,31)\leq4084.
\]

For `(6,1)`, the missing step is the construction or exclusion of a 17-dimensional real `6 x 6` linear space with minimum nonzero rank three. The supplied construction has dimension 16. No result in this archive settles the remaining dimension. The corank-one gaps also remain explicit. An interval here describes this package's proof chain, not a claim that no stronger result exists elsewhere in the literature.

## Archive contents

| Location | Contents |
|---|---|
| `writeup/` | New 19-page manuscript and LaTeX source |
| `code/index_bounds.py` | Exact rational determinant and fast binary-digit index bound |
| `code/combined_bounds.py` | New bounds and propagation combined with the preserved baseline |
| `code/test_index.py` | Determinant/product/localization/digit checks |
| `code/test_new_results.py` | Exact-case and unresolved-interval regression tests |
| `code/constructions.py`, `code/test_constructions.py` | Explicit rational constructions and coefficient tests |
| `code/verify_xu.py`, `code/rref.cpp` | Regenerate both Xu certificates, including the chart at infinity |
| `code/export_measurements.py` | Regenerate complete measurement systems in four exact cases |
| `code/bounds.py` | Unmodified previous-package bounds; **not** the updated calculator |
| `certificates/` | Exact Xu data and complete rational measurement matrices |
| `results/` | Executed logs, freshly regenerated certificates, and 256-pair bound table |
| `prior/` | Unmodified earlier manuscript, source, and source notes |
| `SOURCES.md` | Primary-source inventory and scope/discrepancy audit |
| `MANIFEST.sha256` | Integrity hashes; check with `python code/check_manifest.py` |

The bound table covers all 256 admissible pairs with `2<=d<=32`. Compared with the preserved baseline under the same 20,000-partition cutoff, 179 lower bounds improve and four previously unclosed intervals become exact. The optional baseline partition enumeration is complete through `d=16`; above that, skipped enumerations are flagged. The new binary-digit index calculation does not have a partition-enumeration cutoff. The table is not advertised as literature-optimal.

## Reproduction

Tested with Python 3.13.5 and SymPy 1.14.0. Install the Python dependency with:

```sh
python -m pip install -r requirements.txt
```

From this archive's root directory:

```sh
python code/check_manifest.py
python code/test_index.py
python code/test_new_results.py
python code/test_constructions.py
python code/verify_xu.py --variant both
python code/export_measurements.py
python code/combined_bounds.py --max-d 32 --partition-limit 20000
```

The default Xu verifier requires a C++17 compiler, GMP, and its development headers. It builds the helper in a temporary directory. A slower pure-SymPy alternative is:

```sh
python code/verify_xu.py --variant both --backend sympy
```

Single-case calculations:

```sh
python code/index_bounds.py 12 5 --determinant
python code/index_bounds.py 16 7 --determinant
```

The determinant uses the manuscript's fixed orientation; its sign can differ from the positive corank-one formula, while its valuation and obstruction agree. The original construction regression test intentionally retains the earlier intervals because it imports `bounds.py`. Use `test_new_results.py` and `combined_bounds.py` for the updated conclusions.

Reproduction commands overwrite their generated results in `results/` or `certificates/`; timestamps in execution logs may differ. Check the delivered manifest **before** rerunning commands, or rerun in a separate copy. No network access is needed to execute the mathematics. LaTeX compilation uses standard packages listed in the source; `pdflatex` should be run twice or until references settle.

## Exact measurement data

Files `certificates/measurements_d12_r5.json`, `measurements_d16_r7.json`, `measurements_d20_r9.json`, and `measurements_d28_r13.json` contain the full matrices `W` and `B`, not a random seed or only an existence description. A row of `W` is the row-major vectorization of a measurement matrix `A_i`; columns of `B` vectorize the kernel basis. All entries are rational strings. The checks establish `W B = 0`, the full row rank of `W` via an identity minor, and independence of `B` via an exact nonzero minor. The minimum-rank guarantee additionally uses the proved construction and, for Xu lifts, the separate real pencil certificate.

For the Xu inputs, the printed paper and the author's webpage differ in two entries. Both entire variants are retained and were independently regenerated with exact rational arithmetic in this follow-up. Each degree-20 necessary eliminant has no real roots by Sturm's theorem, and each separate homogeneous infinity-chart matrix has full column rank. The new larger systems use the paper variant. See the manuscript and `SOURCES.md` for the exact source-to-vectorization convention.
