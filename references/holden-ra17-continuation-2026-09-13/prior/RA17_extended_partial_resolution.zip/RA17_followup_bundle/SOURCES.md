# Primary sources and scope audit

The problem definition and cited mathematical foundations were read on public websites. No GitHub plugin was used. The new index argument and its determinant/digit evaluation are given in the accompanying manuscript rather than attributed to the sources below. No claim of mathematical priority is made.

## Problem and low-rank constructions

1. **OpenProblemsInNLA, RA-17 — Minimum linear measurements for uniform recovery of real low-rank matrices.** Repository audit dated 2026-09-10. Defines unrestricted real square matrices, uniform injectivity on every rank-at-most-r signal, and the all-dimension exact-count target. It explicitly distinguishes a classification from fixed-instance polynomial decidability.
   - https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RA-17/README.md

2. **Zhiqiang Xu, Signal Recovery on Algebraic Varieties Using Linear Samples.** Acta Mathematica Sinica, English Series 42 (2026), 740–754; arXiv:2506.17572v2. Section 5, especially Theorem 5.5 and Remark 5.6, supplies the survey's exact real families, general upper bound, and real four-dimensional exception.
   - https://arxiv.org/html/2506.17572v2
   - https://doi.org/10.1007/s10114-026-5299-y

3. **Zhiqiang Xu, The minimal measurement number for low-rank matrices recovery.** arXiv:1505.07204v1 (2015), especially Theorem 3.2 and equation (3.5). Source of the eleven-measurement construction, not a source for the new follow-up's index proof.
   - https://arxiv.org/pdf/1505.07204v1
   - https://doi.org/10.1016/j.acha.2017.01.005

4. **Zhiqiang Xu, accompanying Maple verification webpage.** Author's source code for the four-dimensional real example.
   - https://lsec.cc.ac.cn/~xuzq/rank1.htm

### Xu input discrepancy and exact verification

The paper has `A_4(2,4)=3` and `A_8(4,3)=3`. The webpage instead has `4` and `2`, respectively. Both full matrix collections are included and pass the exact verification. In the stored measurement files the source matrices have all been transposed and then vectorized row-major; the differing entries therefore occur at one-based `W(4,14)` and `W(8,12)`. Simultaneous transposition preserves the rank-avoidance property.

Both certificates were regenerated in this follow-up with rational GMP row reduction, starting from the matrices and their cubic minors, not merely from a previously saved univariate polynomial. The earlier package additionally recorded a pure-SymPy paper-variant run. The affine chart gives a necessary eigenvalue polynomial without assuming a complete Gröbner basis. The projective infinity chart is checked independently; no solution is discarded solely by normalization.

## Grassmannian and index foundations

5. **Jeffrey D. Carlson, Grassmannians and the equivariant cohomology of isotropy actions.** arXiv:1611.01175v2 (2023), Corollary 2.3. Used for the rational cohomology ring of the *unoriented* real Grassmannian. In the even-plane/even-complement case its rational cohomology occurs only in degrees divisible by four.
   - https://arxiv.org/pdf/1611.01175v2

6. **Chen He, Localization of equivariant cohomology rings of real and oriented Grassmannians.** arXiv:1609.06243, Sections 2 and 5, especially Corollary 5.26. Used to check fixed points, Euler weights, localization, and the distinction between the oriented cover and the unoriented Grassmannian.
   - https://arxiv.org/pdf/1609.06243

7. **Blake Mellor, Spin^c-Manifolds.** Notes, Theorem 4. Used for the integral-lift criterion for an oriented real bundle to admit a Spin^c structure. The determinant lines in the new proof are constructed explicitly as powers of the complexification of `det S`; it is not assumed that the manifold is spin.
   - https://webhomes.maths.ed.ac.uk/~v1ranick/papers/mellor

8. **Konstantin Wernli, Lecture Notes on Spin Geometry.** arXiv:1911.09766v1 (2019), Theorem 4.2.4. The Clifford-module index theorem gives the integer index used for the genuine total and half-spin twisting bundles. The 2019 date is the arXiv version's submission year; the live HTML may display a later generation date.
   - https://arxiv.org/html/1911.09766v1
   - https://arxiv.org/abs/1911.09766

The relevant PDF cohomology and Spin^c statements were also checked visually. The new proof does not confuse orientability of the base with orientability of its tautological bundle. It explicitly accounts for torsion determinant lines, the degree-two covering normalization, and the half-spin Euler-class condition. Those written mathematical inferences have not been formally verified in a proof assistant or independently peer reviewed.

## Corank-one literature scope

9. **Andrea Causin, On the dimension of some real, bounded rank, matrix spaces.** arXiv:0911.1810v1 (2009), Proposition 2.2, Theorem 3.5, and the table preceding Proposition 3.6. Published as *On the dimension of some real spaces of bounded rank matrices*, Linear Algebra and its Applications 434 (2011), 501–506.
   - https://arxiv.org/pdf/0911.1810v1
   - https://doi.org/10.1016/j.laa.2010.09.004

Theorem 3.5 proves the upper bound `kappa <= 2 v_2(d)+2` relevant to the previous package. The preprint's Proposition 3.6 is worded for the broader condition `8 | d`, but the immediately preceding table by itself makes the upper and lower bounds coincide only when `v_2(d)=3 mod 4`. At `d=16` that table has bounds 9 and 10, which do not coincide.

The follow-up does **not** treat that table as a proof of the broader statement, and does not claim to disprove the broader proposition. Its stronger obstruction is proved independently. A verified additional argument for the broader proposition could close more corank-one gaps than this archive does. Accordingly all unclosed intervals are explicitly scoped to the supplied proof chain, not asserted to be optimal across the entire literature.

## Previous artifact and provenance

The new work builds on the uploaded `RA17_partial_resolution_and_verification.zip`. Its PDF, LaTeX, source notes, baseline calculator, explicit construction implementation, and exact Xu inputs are preserved where described in `README.md`. The original third-party papers are cited, not redistributed. New computation logs are kept separately from the earlier manuscript's statements. The final integrity manifest covers every delivered file except itself.
