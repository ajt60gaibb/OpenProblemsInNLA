#!/usr/bin/env python3
"""Export and verify exact measurement matrices for newly closed RA-17 cases.

JSON entries are rational strings (e.g. "3/7"), not floating-point numbers.
Measurements use row-major vec(X); each row is an A_i with <A_i,X>=tr(A_i^T X).
The lower bounds are proved in the manuscript, not inferred from finite tests.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sympy as sp
from constructions import xu_octonion_lift, hurwitz_basis, annihilating_measurements
from combined_bounds import combined_bounds

ROOT = Path(__file__).resolve().parents[1]

def write_case(d: int, directory: Path) -> dict:
    if d % 8 == 4:
        matrices = xu_octonion_lift(d, 'paper')
        proof = 'Exactly certified Xu paper pencil, plus octonion left-multiplication blocks.'
    else:
        matrices = hurwitz_basis(d)
        proof = 'Hurwitz/Clifford coefficient identities X(x)^T X(x)=||x||^2 I.'
        for i,A in enumerate(matrices):
            for j,B in enumerate(matrices):
                if A.T*B+B.T*A != (2*sp.eye(d) if i == j else sp.zeros(d)):
                    raise AssertionError(f'norm coefficient {(d,i,j)}')
    B = sp.Matrix.hstack(*(A.reshape(d*d,1) for A in matrices))
    W = annihilating_measurements(matrices)
    r = d//2-1
    bound = combined_bounds(d,r,0)
    if W*B != sp.zeros(W.rows,B.cols):
        raise AssertionError('nonzero annihilation product')
    # Nullspace output has an explicit identity submatrix in its free columns.
    # Verify that witness instead of a much slower dense rational rank(W).
    _, pivots = B.T.rref()
    free = [j for j in range(d*d) if j not in pivots]
    if W.extract(range(W.rows),free) != sp.eye(W.rows):
        raise AssertionError('annihilator identity minor is missing')
    kernel_minor = B.extract(pivots,range(B.cols)).det()
    if not kernel_minor or W.rows+B.cols != d*d:
        raise AssertionError('incorrect kernel minor or dimensions')
    rank_W,rank_B = W.rows,B.cols
    if not (bound['exact'] and bound['lower'] == W.rows):
        raise AssertionError('construction does not match the proved bound')
    data = {'d':d,'r':r,'m':W.rows,'kernel_dimension':B.cols,
            'arithmetic':'exact rational strings','vectorization':'row-major',
            'minimum_nonzero_rank_proof':proof,
            'measurement_rows':[[str(x) for x in row] for row in W.tolist()],
            'kernel_basis_columns':[[str(x) for x in row] for row in B.tolist()]}
    path = directory/f'measurements_d{d}_r{r}.json'
    path.write_text(json.dumps(data,indent=2)+'\n')
    return {'d':d,'r':r,'m':W.rows,'kernel_dimension':B.cols,
            'rank_W':rank_W,'rank_B':rank_B,'W_times_B_is_zero':True,
            'file':path.name,'proof':proof,
            'measurement_identity_minor_columns_zero_based':free,
            'kernel_nonsingular_minor_rows_zero_based':list(pivots),
            'kernel_minor_determinant':str(kernel_minor)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dimensions',type=int,nargs='+',default=[12,16,20,28])
    parser.add_argument('--output-dir',type=Path,default=ROOT/'certificates')
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True,exist_ok=True)
    rows=[]
    for d in args.dimensions:
        result=write_case(d,args.output_dir); rows.append(result)
        print(f"PASS: d={d}, r={result['r']}, m={result['m']}, "
              f"kernel dimension={result['kernel_dimension']}; ranks and W B=0 exact",flush=True)
    (ROOT/'results'/'exported_measurement_checks.json').write_text(json.dumps(rows,indent=2)+'\n')
    print('The Xu minimum-rank property also requires the separate exact Xu verifier.',flush=True)

if __name__ == '__main__':
    main()
