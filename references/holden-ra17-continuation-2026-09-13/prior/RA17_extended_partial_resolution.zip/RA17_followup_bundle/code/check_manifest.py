#!/usr/bin/env python3
"""Check delivered archive integrity; no third-party Python packages needed."""
from __future__ import annotations
import hashlib
from pathlib import Path
import sys


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    manifest = root / 'MANIFEST.sha256'
    if not manifest.is_file():
        print('ERROR: MANIFEST.sha256 is missing.', file=sys.stderr)
        return 2
    checked = 0
    errors = []
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        try:
            expected, relative = line.split('  ', 1)
            path = (root / relative).resolve()
            if root not in path.parents or len(expected) != 64:
                raise ValueError('invalid manifest entry')
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            checked += 1
            if digest != expected:
                errors.append(f'CHANGED: {relative}')
        except (ValueError, OSError) as error:
            errors.append(f'ERROR: {line}: {error}')
    if errors:
        print('\n'.join(errors), file=sys.stderr)
        print('Reproduction commands may intentionally regenerate result files.', file=sys.stderr)
        return 1
    print(f'PASS: all {checked} listed file hashes match.')
    print('Integrity verification does not establish mathematical correctness.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
