#!/usr/bin/env python3
"""Regression checks for the new bounds and closed intervals."""
from __future__ import annotations
import time
from combined_bounds import combined_bounds
from index_bounds import (even_lower_bound, odd_rank_one_lower_bound,
                          corank_one_kernel_upper, denominator_exponent)
from bounds import rho, v2

def main() -> None:
    start=time.monotonic()
    for d in range(5,1002,2):
        if odd_rank_one_lower_bound(d)['lower'] != even_lower_bound(d-1,1)['lower']:
            raise AssertionError('odd simplification differs from monotonicity')
    print('PASS: odd rank-one simplification equals the even bound at d-1, through d=1001')
    for pair,value in {(4,1):11,(12,5):139,(16,7):247,(20,9):395,(28,13):779,
                       (48,23):2295,(256,127):65519}.items():
        row=combined_bounds(*pair,0)
        if not (row['lower']==value==row['upper']):
            raise AssertionError(f'incorrect exact case {pair}')
    print('PASS: exact cases (4,1), (12,5), (16,7), (20,9), (28,13), (48,23), (256,127)')
    for pair,interval in {(6,1):(19,20),(10,1):(35,36),(32,15):(1012,1014),
                          (64,31):(4083,4084)}.items():
        row=combined_bounds(*pair,0)
        if (row['lower'],row['upper']) != interval or row['exact']:
            raise AssertionError(f'unclosed interval misclassified {pair}')
    print('PASS: unresolved intervals remain explicitly unresolved')
    for d in range(4,4098,2):
        a=v2(d); bound=corank_one_kernel_upper(d)
        if a in (1,2) or a%4 in (0,3):
            construction=4 if a==1 else 5 if a==2 else rho(d)
            if bound != construction:
                raise AssertionError(f'exact-family mismatch d={d}')
        elif a%4==1 and bound-rho(d)!=2:
            raise AssertionError('wrong two-dimensional kernel gap')
        elif a%4==2 and bound-rho(d)!=1:
            raise AssertionError('wrong one-dimensional kernel gap')
    print('PASS: all corank-one exact families and remaining gaps through d=4096')
    bad=[(3,1),(4,2),(0,1),(4,0),(True,1)]
    for d,r in bad:
        try:
            even_lower_bound(d,r)
        except ValueError:
            continue
        raise AssertionError('invalid even input accepted')
    print('PASS: basic invalid-input checks')
    print(f'All new-result regression tests passed in {time.monotonic()-start:.2f} seconds.')
    print('These are arithmetic/regression tests, not a formalization of topology.')

if __name__ == '__main__':
    main()
