#!/usr/bin/env python3
"""Exact Spin^c index obstructions for RA-17 (necessary bounds, not a solver).

No numerical tolerances are used. The fast even-dimensional bound uses binary
population counts. The determinant computes the associated rational index.
See the accompanying manuscript for the topological hypotheses and proof.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
from functools import lru_cache
from math import factorial
import json
from pathlib import Path


def validate_even(d: int, r: int) -> None:
    if (not isinstance(d, int) or isinstance(d, bool) or not isinstance(r, int)
            or isinstance(r, bool) or d < 4 or d % 2 or not 1 <= r < d//2):
        raise ValueError('require even integer d >= 4 and 1 <= r < d/2')


def binomial(x: Fraction, n: int) -> Fraction:
    if n < 0:
        raise ValueError('binomial lower argument must be nonnegative')
    answer = Fraction(1)
    for j in range(n):
        answer *= (x-j)/(j+1)
    return answer


def valuation2(x: Fraction | int) -> int:
    x = Fraction(x)
    if not x:
        raise ValueError('the 2-adic valuation of zero is not a finite integer')
    a, b = abs(x.numerator), x.denominator
    return (a & -a).bit_length() - (b & -b).bit_length()


def determinant(matrix: list[list[Fraction]]) -> Fraction:
    n = len(matrix)
    if any(len(row) != n for row in matrix):
        raise ValueError('matrix must be square')
    a = [[Fraction(x) for x in row] for row in matrix]
    result = Fraction(1)
    for j in range(n):
        pivot = next((i for i in range(j, n) if a[i][j]), None)
        if pivot is None:
            return Fraction(0)
        if pivot != j:
            a[j], a[pivot] = a[pivot], a[j]
            result = -result
        p = a[j][j]
        result *= p
        for i in range(j+1, n):
            multiplier = a[i][j]/p
            for k in range(j+1, n):
                a[i][k] -= multiplier*a[j][k]
    return result


@lru_cache(maxsize=None)
def grassmannian_index(d: int, r: int) -> Fraction:
    """J = integral_G Ahat(TG) C(S)^(-d), up to the specified orientation.

    G = Gr_(2r)(R^d). The orientation is normalized by the Pontryagin
    Schur-rectangle class having integral +1.
    """
    validate_even(d, r)
    n = d//2
    h = [[2**(i+j)*binomial(Fraction(i+j-1, 2), n-1)
          for j in range(r)] for i in range(r)]
    return (-1)**(r*(r-1)//2)*determinant(h)


def denominator_exponent(d: int, r: int) -> int:
    """q = -v2(J), evaluated without a determinant or partition enumeration."""
    validate_even(d, r)
    n, s = d//2, d//2-r
    m0, m1 = (r+1)//2, r//2
    def digit_sum(m: int) -> int:
        return sum((n-1-j).bit_count()-j.bit_count() for j in range(m))
    return 2*r*s+r-(r % 2)-digit_sum(m0)-digit_sum(m1)


def even_lower_bound(d: int, r: int) -> dict:
    validate_even(d, r)
    q = denominator_exponent(d, r)
    q0 = max(0, q)
    t_min = 2*q0+(q0 % 2)
    return {'d': d, 'r': r, 'index_denominator_exponent': q,
            'minimum_complement_rank_from_index': t_min,
            'lower': 2*d*r+t_min,
            'reason': 'Spin^c total/half-spin index integrality'}


def odd_rank_one_lower_bound(d: int) -> dict:
    """Equivalent simplification of the even bound at d-1; monotonicity only."""
    if not isinstance(d, int) or isinstance(d, bool) or d < 5 or d % 2 != 1:
        raise ValueError('require odd integer d >= 5')
    q = d-3-(d-2).bit_count()
    t_min = 2*q+int(q % 2 == 0)
    return {'d': d, 'r': 1, 'propagated_parameter_q': q,
            'minimum_complement_rank_from_index': t_min,
            'lower': 2*d+t_min,
            'reason': 'even-dimensional index at d-1 and principal-submatrix monotonicity'}


def corank_one_kernel_upper(d: int) -> int:
    if not isinstance(d, int) or isinstance(d, bool) or d < 4 or d % 2:
        raise ValueError('require even integer d >= 4')
    a = valuation2(d)
    return 2*a+1+(a % 2)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('d', type=int)
    parser.add_argument('r', type=int)
    parser.add_argument('--determinant', action='store_true',
                        help='also compute the exact characteristic number')
    args = parser.parse_args()
    if args.d % 2:
        if args.r != 1:
            parser.error('the odd-dimensional formula here is only for r=1')
        result = odd_rank_one_lower_bound(args.d)
    else:
        result = even_lower_bound(args.d, args.r)
        if args.d-2*args.r == 2:
            result['kernel_dimension_upper'] = corank_one_kernel_upper(args.d)
        if args.determinant:
            value = grassmannian_index(args.d, args.r)
            result['index_J'] = str(value)
            result['index_J_v2'] = valuation2(value)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
