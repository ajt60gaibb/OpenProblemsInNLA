#!/usr/bin/env python3
"""Independent exact arithmetic checks of the new index formulae.

These check identities and bound consistency. They do NOT formalize the
Spin^c index theorem or the bundle obstruction in a proof assistant.
"""
from __future__ import annotations
from fractions import Fraction as F
from itertools import combinations
from math import factorial, comb
from pathlib import Path
import json
import time
import sympy as sp
from index_bounds import (binomial, determinant, grassmannian_index,
                          denominator_exponent, even_lower_bound,
                          odd_rank_one_lower_bound, corank_one_kernel_upper,
                          valuation2)
from bounds import bounds, rho

ROOT = Path(__file__).resolve().parents[1]


def rising(x: F, n: int) -> F:
    result = F(1)
    for i in range(n):
        result *= x+i
    return result


def hankel_product(z: F, N: int, m: int) -> F:
    answer = binomial(z, N)**m
    for j in range(m):
        answer *= factorial(j)*rising(z+1,j)*rising(F(-N),j)
        answer /= rising(z-N+1,m+j-1)
    return answer


def exp_coefficient(log_coefficients: list[F]) -> F:
    """[z^N] exp(sum_(j>=1) log_coefficients[j-1] z^j)."""
    coefficients = [F(1)]
    for m in range(1,len(log_coefficients)+1):
        coefficients.append(sum((j*log_coefficients[j-1]*coefficients[m-j]
                                 for j in range(1,m+1)), F(0))/m)
    return coefficients[-1]


def localization_index(d: int, r: int) -> F:
    """Direct tangent-root localization, independent of the Hankel reduction.

    Fixed torus weights are 1,...,n. Tangent weights at I are a_j +/- a_i
    for i in I,j not in I. The twist is C(Q)^d, not its reduced S expression.
    """
    n,s = d//2,d//2-r
    order = r*s
    alpha = [F(-sp.bernoulli(2*j), 2*j*factorial(2*j))
             for j in range(1,order+1)]
    beta = [-(2**(2*j)-1)*alpha[j-1] for j in range(1,order+1)]
    answer = F(0)
    weights = tuple(range(1,n+1))
    for I in combinations(weights,r):
        J = tuple(a for a in weights if a not in I)
        euler = 1
        for a in I:
            for b in J:
                euler *= a*a-b*b
        logs = []
        for ell in range(1,order+1):
            tangent = sum((b-a)**(2*ell)+(b+a)**(2*ell)
                          for a in I for b in J)
            twist = sum(b**(2*ell) for b in J)
            logs.append(alpha[ell-1]*tangent+d*beta[ell-1]*twist)
        answer += exp_coefficient(logs)/euler
    return answer


def quadric_corank_series(d: int) -> F:
    """Integral on the oriented double cover; direct truncated power series."""
    h = sp.Symbol('h')
    order = d-2
    a = sp.series((h/2)/sp.sinh(h/2),h,0,order+1).removeO()
    c = sp.series(sp.cosh(h/2),h,0,order+1).removeO()
    # Use power-series truncation after each multiplication to keep sizes small.
    def mul(p,q):
        return sum(
            value*h**monomial[0] for monomial,value in sp.Poly(p*q,h).terms()
            if monomial[0] <= order)
    f = sp.Integer(1)
    ac = mul(a,c)
    for _ in range(d):
        f=mul(f,ac)
    sinhc=sum(h**(2*j)/sp.factorial(2*j+1) for j in range(order//2+1))
    return F(2*sp.expand(mul(f,sinhc)).coeff(h,order))


def require(test: bool, message: str) -> None:
    if not test:
        raise AssertionError(message)


def main() -> None:
    start=time.monotonic(); rows=[]
    # Binomial determinant versus the separate product formula.
    count=0
    for N in range(1,15):
        for m in range(1,N+1):
            for z in (F(-1,2),F(1,2),F(3,2)):
                D=determinant([[binomial(z+i+j,N) for j in range(m)] for i in range(m)])
                require(D==hankel_product(z,N,m),f'Hankel product N={N},m={m},z={z}')
                count+=1
    print(f'PASS: {count} Hankel determinant/product identities',flush=True)
    # The characteristic integral is computed independently by torus localization.
    count=0
    for n in range(2,10):
        for r in range(1,n):
            J=grassmannian_index(2*n,r)
            other=localization_index(2*n,r)
            require(J==other,f'localization d={2*n},r={r}: {J} != {other}')
            require(valuation2(J)==-denominator_exponent(2*n,r),'digit valuation')
            rows.append({'d':2*n,'r':r,'J':str(J),'q':-valuation2(J),
                         'localization_matches':True})
            count+=1
    print(f'PASS: {count} independent localization/determinant checks through d=18',flush=True)
    count=0
    for n in range(2,33):
        for r in range(1,n):
            J=grassmannian_index(2*n,r)
            q=denominator_exponent(2*n,r)
            require(J != 0 and -valuation2(J)==q,'binary formula')
            require(J.denominator & (J.denominator-1)==0,'dyadic denominator')
            lo=even_lower_bound(2*n,r)['lower']
            require(lo<=bounds(2*n,r,0)['upper'],'bound exceeds construction')
            count+=1
    print(f'PASS: {count} exact determinant/digit/bound checks through d=64',flush=True)
    for d in range(4,1026,2):
        a=valuation2(d)
        r=d//2-1
        lo=even_lower_bound(d,r)['lower']
        require(lo==d*d-corank_one_kernel_upper(d),'corank binary simplification')
        require(corank_one_kernel_upper(d)>=rho(d),'corank bound versus Hurwitz')
        if d<=64:
            J=grassmannian_index(d,r)
            require(abs(J)==F(d,2**(d-1)),'quadric closed form')
    print('PASS: corank-one formula and Hurwitz consistency through d=1024',flush=True)
    for d in range(4,18,2):
        require(quadric_corank_series(d)==F(d,2**(d-2)),f'quadric series d={d}')
    print('PASS: direct quadric power-series identity for d=4,6,...,16',flush=True)
    for d in range(5,66,2):
        require(odd_rank_one_lower_bound(d)['lower']==even_lower_bound(d-1,1)['lower'],
                'odd rank-one monotonicity simplification')
        require(odd_rank_one_lower_bound(d)['lower']<=bounds(d,1,0)['upper'],
                'odd rank-one bound consistency')
    print('PASS: odd rank-one monotonicity simplification through d=65',flush=True)
    require(even_lower_bound(12,5)['lower']==139,'12,5 lower')
    require(even_lower_bound(16,7)['lower']==247,'16,7 lower')
    require(even_lower_bound(6,1)['lower']==19,'6,1 improved lower')
    require(even_lower_bound(10,1)['lower']==35,'10,1 improved lower')
    require(odd_rank_one_lower_bound(11)['lower']==35,'11,1 improved lower')
    (ROOT/'results'/'index_values.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(f'All index arithmetic tests passed in {time.monotonic()-start:.2f} seconds.',flush=True)
    print('No finite test is being substituted for the general topological proofs.',flush=True)


if __name__=='__main__':
    main()
