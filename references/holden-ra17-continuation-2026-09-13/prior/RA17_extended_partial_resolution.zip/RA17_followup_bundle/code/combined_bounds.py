#!/usr/bin/env python3
"""Combine the previous RA-17 bounds with the new exact index obstructions.

This computes proved intervals, NOT an all-dimension exact classification.
The unmodified bounds.py is retained solely as the previous baseline.
"""
from __future__ import annotations
import argparse
import csv
from functools import lru_cache
import json
from pathlib import Path
from bounds import bounds as baseline_bounds
from index_bounds import even_lower_bound

ROOT = Path(__file__).resolve().parents[1]

@lru_cache(maxsize=None)
def combined_bounds(d: int, r: int, partition_limit: int = 200000) -> dict:
    if (not isinstance(d, int) or isinstance(d, bool) or not isinstance(r, int)
            or isinstance(r, bool) or d < 2 or not 1 <= r <= d//2
            or partition_limit < 0):
        raise ValueError('require d>=2, 1<=r<=floor(d/2), and partition_limit>=0')
    previous = baseline_bounds(d, r, partition_limit)
    candidates = {'previous package': previous['lower']}
    result = dict(previous)
    result['previous_lower'] = previous['lower']
    result['previous_upper'] = previous['upper']
    if d % 2 == 0 and r < d//2:
        index = even_lower_bound(d, r)
        candidates['even Grassmannian Spin^c index'] = index['lower']
        result['index'] = index
    # Restrict measurements to a smaller principal submatrix.
    if d >= 3 and r <= (d-1)//2:
        candidates['principal-submatrix monotonicity'] = combined_bounds(d-1,r,partition_limit)['lower']
    # Delete a row and a column from every kernel matrix. The projection is
    # injective for r>=1, and loses at most two in rank.
    if r >= 2:
        candidates['kernel deletion'] = 2*d-1+combined_bounds(d-1,r-1,partition_limit)['lower']
    result['new_lower_candidates'] = candidates
    result['lower'] = max(candidates.values())
    result['exact'] = result['lower'] == result['upper']
    result['improved'] = result['lower'] > result['previous_lower']
    if result['lower'] > result['upper']:
        raise ArithmeticError(f'inconsistent proved bounds: {(d,r)}')
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--max-d', type=int, default=32)
    parser.add_argument('--partition-limit', type=int, default=20000)
    parser.add_argument('--output', type=Path, default=ROOT/'results'/'combined_bounds.json')
    args = parser.parse_args()
    if args.max_d < 2:
        parser.error('--max-d must be at least 2')
    rows = [combined_bounds(d,r,args.partition_limit)
            for d in range(2,args.max_d+1) for r in range(1,d//2+1)]
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(rows,indent=2)+'\n')
    with args.output.with_suffix('.csv').open('w',newline='') as stream:
        columns = ['d','r','previous_lower','previous_upper','lower','upper','exact',
                   'improved','generic_count','schur_enumerated']
        writer = csv.DictWriter(stream,fieldnames=columns,extrasaction='ignore')
        writer.writeheader(); writer.writerows(rows)
    print(' d  r      previous       updated   exact')
    for row in rows:
        print(f"{row['d']:2} {row['r']:2}  {row['previous_lower']:5}..{row['previous_upper']:<5} "
              f"{row['lower']:5}..{row['upper']:<5}  {'yes' if row['exact'] else 'NO'}")
    print(f"Improved lower bounds: {sum(x['improved'] for x in rows)} / {len(rows)}")
    print(f"Newly closed intervals: {sum(x['exact'] and x['previous_lower'] != x['previous_upper'] for x in rows)}")
    print('These intervals report this package, not a claim of literature-optimality.')

if __name__ == '__main__':
    main()
