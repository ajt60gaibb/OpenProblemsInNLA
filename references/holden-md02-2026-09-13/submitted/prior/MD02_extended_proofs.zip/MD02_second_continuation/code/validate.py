"""Reproducible finite checks. Execute from any working directory."""
from pathlib import Path
import itertools,json,time,sys,hashlib
from fractions import Fraction
import numpy as np
import scipy
from fft_path import FFTPath,dense_state
ROOT=Path(__file__).resolve().parent.parent
OUT=ROOT/'results';OUT.mkdir(exist_ok=True)

def save(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2,allow_nan=False))

def exact_enumeration():
    rows=[]; total=0; maxerr=0.
    for n in range(2,19):
        t5s=[];r4s=[];m3s=[];exact_m3=[];exact_r4=[]
        for bits in itertools.product((0,1),repeat=n//2):
            p=FFTPath(n,bits);s=p.initial_statistics();eta=p.eta.astype(np.int64)
            conv=np.array([sum(int(eta[a])*int(eta[(ss-a)%n]) for a in range(n))
                           for ss in range(n)],dtype=np.int64)
            T3=int(eta@conv);B=int(eta.sum());m=n-1
            exact=Fraction(T3+3*B,8*n*n)-Fraction((m+2)*B**3,8*n*n*m*m)
            predicted=float(exact);exact_m3.append(exact)
            exact_r4.append(Fraction(int(conv@conv),n**3))
            maxerr=max(maxerr,abs(s['M3']-predicted))
            assert abs(s['M3']-predicted)<3e-13
            if s['d']>1e-12:
                c3=s['M3']/s['d']**3-3*s['beta']/m+2/m**2
                assert abs(s['C3']-c3)<5e-11
            raw=np.fft.ifft(eta).real
            t5=int(eta@(conv*conv));lhs=float((raw*raw)@np.fft.ifft(eta*np.fft.fft(raw*raw)).real)
            assert abs(lhs-t5/n**3)<2e-12
            t5s.append(t5);r4s.append(float(np.sum(raw**4)));m3s.append(s['M3']);total+=1
        rows.append({'n':n,'masks':len(t5s),'n2_E_M3_squared':n*n*float(np.mean(np.square(m3s))),
                     'E_U5_squared_over_n3':float(np.mean(np.square(np.asarray(t5s,dtype=float))))/n**3,
                     'n_E_raw_fourth':n*float(np.mean(r4s)),
                      'n3_Var_raw_fourth':n**3*float(np.var(r4s)),
                     'exact_n2_E_M3_squared':str(n*n*sum(x*x for x in exact_m3)/len(exact_m3)),
                     'exact_E_U5_squared_over_n3':str(Fraction(sum(x*x for x in t5s),len(t5s)*n**3)),
                     'exact_n_E_raw_fourth':str(n*sum(exact_r4)/len(exact_r4))})
        assert n*n*sum(x*x for x in exact_m3)/len(exact_m3)<=Fraction(3,16)
    save('enumeration.json',{'total_masks':total,'max_initial_identity_error':maxerr,'orders':rows})
    return {'masks':total,'max_identity_error':maxerr}

def compare_dense():
    rng=np.random.default_rng(2026091301);rows=[]
    for n in [7,16,31,64,127]:
        for sample in range(3):
            mask=rng.integers(0,2,n//2);path=FFTPath(n,mask)
            for t in [1.,2.,4.,10.]:
                a=path.at(t);b=dense_state(n,mask,t)
                row={'n':n,'sample':sample,'t':t,'L_error':abs(a.L-b['L']),
                     'M3_error':abs(a.M3-b['M3']),'d_error':abs(a.d-b['d']),
                     'max_y_error':float(np.max(abs(a.y-b['y']))),'fft_residual':a.residual_l2}
                assert row['L_error']<1e-8 and row['M3_error']<1e-8
                rows.append(row)
    save('dense_comparison.json',rows)
    return {'states':len(rows),'maximum_L_error':max(r['L_error'] for r in rows),
            'maximum_M3_error':max(r['M3_error'] for r in rows)}

def local_experiment():
    rng=np.random.default_rng(2026091302);rows=[];summaries=[]
    for n in [127,256,511,1024,2047,4096,8191,16384]:
        by_t={t:[] for t in [1.5,2.,4.,9.]};initrows=[]
        for sample in range(32):
            mask=rng.integers(0,2,n//2);path=FFTPath(n,mask);init=path.initial_statistics();initrows.append(init)
            for t in by_t:
                state=path.at(t);s=np.sqrt(t)
                predicted=2*(1-1/s)*init['D']+4*(s-2+1/s)*init['M3']
                rem=n*(state.L-predicted);by_t[t].append(rem)
                rows.append({'n':n,'sample':sample,'mask_hex':np.packbits(mask.astype(np.uint8)).tobytes().hex(),
                             't':t,'initial':init,'L':state.L,'M3':state.M3,'kappa':state.kappa,
                             'n_remainder':rem,'residual':state.residual_l2})
        summaries.append({'n':n,'independent_masks':len(initrows),
                          'mean_n_C4':float(np.mean([n*r['C4'] for r in initrows])),
                          'mean_n_Q':float(np.mean([n*r['Q'] for r in initrows])),
                          'rms_n_remainder':{str(t):float(np.sqrt(np.mean(np.square(v)))) for t,v in by_t.items()}})
        print('local',n,summaries[-1],flush=True)
        save('local_expansion_raw.json',rows);save('local_expansion_summary.json',summaries)
    return {'masks':sum(r['independent_masks'] for r in summaries),'states':len(rows)}

def initial_clt_and_early_path():
    rng=np.random.default_rng(2026091303);rows=[];summaries=[];early=[]
    for n in [127,256,511,1024,2047,4096,8191]:
        data=[]
        for sample in range(512):
            mask=rng.integers(0,2,n//2);p=FFTPath(n,mask);s=p.initial_statistics()
            x=np.sqrt(2*n)*s['D'];y=4*n*s['M3']/np.sqrt(3)
            data.append((x,y));rows.append({'n':n,'sample':sample,'X':float(x),'Y':float(y),
                                            'n_kappa':n*s['kappa']})
            if sample<24:
                for gamma in [.2,.3]:
                    q=FFTPath(n,mask);state=q.at(float(n**gamma))
                    early.append({'n':n,'sample':sample,'gamma':gamma,'t':state.t,
                                  'n_kappa_initial':n*s['kappa'],'n_kappa_final':n*state.kappa,
                                  'n_delta_kappa':n*(state.kappa-s['kappa']),'residual':state.residual_l2})
        v=np.asarray(data)
        summaries.append({'n':n,'masks':len(v),'mean':v.mean(axis=0).tolist(),
                          'second_moment':np.mean(v*v,axis=0).tolist(),
                          'fourth_moment':np.mean(v**4,axis=0).tolist(),
                          'cross_moment':float(np.mean(v[:,0]*v[:,1]))})
        print('initial CLT',n,summaries[-1],flush=True)
    save('initial_clt_raw.json',rows);save('initial_clt_summary.json',summaries)
    save('early_path_raw.json',early)
    es=[]
    for n in sorted({r['n'] for r in early}):
        for gamma in [.2,.3]:
            z=[r['n_delta_kappa'] for r in early if r['n']==n and r['gamma']==gamma]
            es.append({'n':n,'gamma':gamma,'masks':len(z),'rms_n_delta_kappa':float(np.sqrt(np.mean(np.square(z))))})
    save('early_path_summary.json',es)
    return {'initial_masks':len(rows),'early_path_states':len(early)}

if __name__=='__main__':
    start=time.time();summary={'numpy':np.__version__,'scipy':scipy.__version__,'python':sys.version,
                                'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())}
    summary['enumeration']=exact_enumeration();print(summary['enumeration'],flush=True)
    summary['dense_comparison']=compare_dense();print(summary['dense_comparison'],flush=True)
    summary['local_expansion']=local_experiment()
    summary['initial_and_early']=initial_clt_and_early_path()
    summary['elapsed_seconds']=time.time()-start;summary['status']='PASS'
    save('validation_summary.json',summary);print(json.dumps(summary,indent=2),flush=True)
