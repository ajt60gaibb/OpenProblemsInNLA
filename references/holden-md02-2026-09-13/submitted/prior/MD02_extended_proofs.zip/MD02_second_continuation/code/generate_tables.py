"""Regenerate the manuscript's finite-validation tables from recorded JSON."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent.parent
RES=ROOT/'results'
lines=[r'\subsection{Recorded validation run}']
p=RES/'validation_summary.json'
s=json.loads(p.read_text()) if p.exists() else {'status':'INCOMPLETE'}
status=s.get('status','UNKNOWN')
lines.append('The recorded numerical validation status is \\texttt{'+status+'}. '
             'The raw reports and console log are included; finite computations do not establish the asymptotic claims.')
if status=='PASS':
    lines += [r'\begin{center}\begin{tabular}{lr}\toprule Check & Count\\\midrule']
    for label,key,subkey in [('Enumerated masks','enumeration','masks'),('Dense/FFT states','dense_comparison','states'),
        ('Local-expansion masks','local_expansion','masks'),('Local-expansion states','local_expansion','states'),
        ('Initial-law masks','initial_and_early','initial_masks'),('Early-path states','initial_and_early','early_path_states')]:
        lines.append(f'{label} & {s.get(key,{}).get(subkey,"not recorded")}'+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{center}']
else:
    lines.append(r'The run did not complete all checks. Consult \texttt{results/validation\_run.log}; the existence of source code is not a claim of successful numerical validation.')
p=RES/'local_expansion_summary.json'
if p.exists():
    d=json.loads(p.read_text())
    lines += [r'\subsection{Fixed-time scaled residuals}',
              r'The entries are RMS values of $n\mathcal R_n(t)$ over the recorded independent masks, not rigorous error bounds.',
              r'\begin{center}\small\begin{tabular}{rrrrrrr}\toprule',
              r'$n$ & $t=1.5$ & $t=2$ & $t=4$ & $t=9$ & Mean $nC_4$ & Mean $nQ$\\\midrule']
    for row in d:
        vals=[row['rms_n_remainder'][str(t)] for t in [1.5,2.,4.,9.]]
        lines.append(str(row['n'])+' & '+' & '.join(f'{x:.5f}' for x in vals)+
                     f" & {row['mean_n_C4']:.4f} & {row['mean_n_Q']:.4f}"+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{center}']
p=RES/'initial_clt_summary.json'
if p.exists():
    d=json.loads(p.read_text())
    lines += [r'\subsection{Standardized initial moments}',
              r'Here $X=\sqrt{2n}D$ and $Y=4nM_3(1)/\sqrt3$. Limiting second moments are one, the cross moment is zero, and fourth moments are three.',
              r'\begin{center}\small\begin{tabular}{rrrrrr}\toprule',
              r'$n$ & Mean $X^2$ & Mean $Y^2$ & Mean $XY$ & Mean $X^4$ & Mean $Y^4$\\\midrule']
    for row in d:
        vals=[*row['second_moment'],row['cross_moment'],*row['fourth_moment']]
        lines.append(str(row['n'])+' & '+' & '.join(f'{x:.4f}' for x in vals)+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{center}']
p=RES/'early_path_summary.json'
if p.exists():
    d=json.loads(p.read_text());lookup={(r['n'],r['gamma']):r['rms_n_delta_kappa'] for r in d}
    lines += [r'\subsection{Growing-time endpoint diagnostics}',
              r'RMS values of $n(\kappa(n^\gamma)-\kappa(1))$ are shown below. These samples check endpoints only, not a continuum supremum.',
              r'\begin{center}\small\begin{tabular}{rrr}\toprule',
              r'$n$ & $\gamma=0.2$ & $\gamma=0.3$\\\midrule']
    for n in sorted({r['n'] for r in d}):
        lines.append(f"{n} & {lookup[n,.2]:.5f} & {lookup[n,.3]:.5f}"+r'\\')
    lines += [r'\bottomrule\end{tabular}\end{center}']
(ROOT/'manuscript'/'validation_tables.tex').write_text('\n'.join(lines)+'\n')
print('Tables generated; validation status:',status)
