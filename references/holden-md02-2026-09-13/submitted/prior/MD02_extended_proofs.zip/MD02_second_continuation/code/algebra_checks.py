"""Exact symbolic checks of the expansion and projector-flow algebra.

These identities support particular algebraic steps; they do not prove
probabilistic estimates or the MD-02 target.
"""
from pathlib import Path
import json
import sympy as sp

lam,s,d,c,nu=sp.symbols('lambda s d c nu',nonzero=True)
a=s-1
r1=2*d*a
r2=2*d*d*a*a/s+4*c*a*a-s*(s*s-1)*nu/2
r=s+lam*r1+lam**2*r2
beta=1-4*lam*d+lam**2*(2*nu+8*d*d)
c3=lam**2*(8*c-3*nu)
a4=-lam**2*nu
root=s*s/r-1-beta*(r-1)+c3*(r-1)**2+a4*(r-1)**3
root_series=sp.series(root,lam,0,3).removeO().expand()
root_coeffs=[sp.simplify(root_series.coeff(lam,k)) for k in range(3)]
assert root_coeffs==[0,0,0]
log_expr=sp.log(r/s)+sp.log(1+lam**2*nu*(s*s-1))/2
log_series=sp.series(log_expr,lam,0,3).removeO()
predicted=2*lam*d*(1-1/s)+4*lam**2*c*(s-2+1/s)
assert sp.simplify(log_series-predicted)==0

h,z,M,T,m=sp.symbols('h z M T m',nonzero=True)
d0=h*z
# This expression is d'/h - d*h'/h**2, after t/m=(1-h)/h.
poly=z*(1-h*z)*(1-2*h*z)-6*(1-h)*z*z*(1-z)-2*(1-h)**2*z**3+z*(1-h)
assert sp.expand(poly-(2-h)*z*(1-z)*(1-2*z))==0

A,B2,B3=sp.symbols('A B2 B3')
centered=B3+3*A*B2/m+3*A*A*(-A)/(m*m)+m*A**3/m**3
assert sp.simplify(centered-(B3+3*A*B2/m-2*A**3/m**2))==0

result={'status':'PASS','sympy_version':sp.__version__,
        'checks':['root equation through second formal order',
                  'cancellation of degree-square and deterministic normalization terms',
                  'projector d-flow to normalized z-flow',
                  'bulk cubic centering identity'],
        'root_coefficients':[str(x) for x in root_coeffs],
        'logarithmic_expansion':str(sp.factor(predicted))}
path=Path(__file__).resolve().parent.parent/'results'/'algebra_checks.json'
path.write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
