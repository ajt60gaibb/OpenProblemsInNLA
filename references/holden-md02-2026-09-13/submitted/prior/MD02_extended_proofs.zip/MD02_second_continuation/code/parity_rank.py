"""Exact finite rank checks used in all-order parity-counting bounds.

Only integer arithmetic is used. A nonzero minor of fixed integer size gives
an O(n**(variables-rank)) bound on solutions modulo every integer n; n need
not be prime. The code checks a finite combinatorial lemma, not MD-02 itself.
"""
from __future__ import annotations
from functools import reduce
from itertools import product
from math import gcd
from collections import Counter
from pathlib import Path
import json,time

def matchings(items):
    if not items:
        yield ()
    else:
        a=items[0]
        for j in range(1,len(items)):
            b=items[j]
            for rest in matchings(items[1:j]+items[j+1:]):
                yield ((a,b),)+rest

def row_basis(rows):
    rows=[list(map(int,r)) for r in rows if any(r)]
    if not rows:return []
    out=[]; col=0; width=len(rows[0])
    while rows and col<width:
        idx=next((i for i,r in enumerate(rows) if r[col]),None)
        if idx is None:
            col+=1; continue
        pivot=rows.pop(idx)
        g=reduce(gcd,(abs(v) for v in pivot),0)
        pivot=[v//g for v in pivot]
        if pivot[col]<0:pivot=[-v for v in pivot]
        new=[]
        for row in rows:
            if row[col]:
                pc=pivot[col]; rc=row[col]
                row=[pc*v-rc*w for v,w in zip(row,pivot)]
                gg=reduce(gcd,(abs(v) for v in row),0)
                if gg:row=[v//gg for v in row]
            if any(row):new.append(row)
        out.append(pivot); rows=new;col+=1
    return out

def rank(rows):return len(row_basis(rows))

def run(forms,name,outdir):
    count=Counter(); bad=[]; start=time.time(); total=0
    for pairs in matchings(tuple(range(len(forms)))):
        for signs in product((-1,1),repeat=len(pairs)):
            rows=[[x-s*y for x,y in zip(forms[a],forms[b])] for (a,b),s in zip(pairs,signs)]
            r=rank(rows); total+=1; count[r]+=1
            if r<3:
                forced=[i for i,v in enumerate(forms) if rank(rows+[v])==r]
                bad.append({'pairs':pairs,'signs':signs,'rank':r,'rationally_forced_zero':forced,'has_original_equation_s_zero': any(row==forms[0] or row==[-x for x in forms[0]] for row in rows)})
    data={'name':name,'forms':forms,'total':total,'rank_counts':dict(sorted(count.items())),
          'rank_below_three':bad,'seconds':time.time()-start}
    outdir.mkdir(exist_ok=True,parents=True);(outdir/(name+'.json')).write_text(json.dumps(data,indent=2))
    print(name,total,count,'bad',len(bad),'seconds',time.time()-start,flush=True)
    return data

if __name__=='__main__':
    forms=[[1,0,0,0,0,0],[0,1,0,0,0,0],[1,-1,0,0,0,0],
           [0,0,1,0,0,0],[1,0,-1,0,0,0],
           [0,0,0,1,0,0],[0,0,0,0,1,0],[0,0,0,1,-1,0],
           [0,0,0,0,0,1],[0,0,0,1,0,-1]]
    data=run(forms,'quintic_second_moment_rank',Path(__file__).resolve().parent.parent/'results')
    assert all(b['has_original_equation_s_zero'] for b in data['rank_below_three']), 'An admissible rank-below-three system survived.'
    print('PASS: every rank-two system forces s=0 modulo every n and has zero summand.')
