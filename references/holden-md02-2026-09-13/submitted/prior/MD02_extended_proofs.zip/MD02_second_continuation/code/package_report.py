"""Build and inspect the local PDF; create the deliverable archive.

This packaging helper does not execute the mathematical experiments.
Run run_all.sh first to regenerate numerical outputs.
"""
from pathlib import Path
import json,subprocess,hashlib,zipfile,shutil,re,datetime
ROOT=Path(__file__).resolve().parent.parent
MAN=ROOT/'manuscript';OUT=ROOT/'audit'
OUT.mkdir(exist_ok=True)
source=MAN/'MD02_extended_proofs.tex'
s=source.read_text().replace('\texttt',r'\texttt')
# The replacement above handles an accidental Python tab escape, if present.
source.write_text(s)
for i in (1,2):
    process=subprocess.run(['pdflatex','-interaction=nonstopmode','-halt-on-error',source.name],cwd=MAN,
                           capture_output=True,text=True)
    (OUT/f'latex_pass_{i}.log').write_text(process.stdout+'\n'+process.stderr)
    if process.returncode:
        raise RuntimeError(f'LaTeX pass {i} failed; inspect audit/latex_pass_{i}.log')
pdf=MAN/'MD02_extended_proofs.pdf'
assert pdf.exists() and pdf.stat().st_size>10000
import fitz
from PIL import Image,ImageOps,ImageDraw,ImageFont
DOC=fitz.open(pdf)
checks={'pages':len(DOC),'out_of_page_text':[],'replacement_characters':[],'rendered_pages':[]}
render=ROOT/'audit'/'renders';render.mkdir(exist_ok=True)
thumbs=[]
font_path=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
font=ImageFont.truetype(str(font_path),16) if font_path.exists() else ImageFont.load_default()
for i,page in enumerate(DOC):
    text=page.get_text()
    if '\ufffd' in text:checks['replacement_characters'].append(i+1)
    for word in page.get_text('words'):
        x0,y0,x1,y1=word[:4]
        if min(x0,y0)<-0.5 or x1>page.rect.width+.5 or y1>page.rect.height+.5:
            checks['out_of_page_text'].append({'page':i+1,'word':word[4],'box':word[:4]})
    pix=page.get_pixmap(matrix=fitz.Matrix(1,1),alpha=False)
    path=render/f'page-{i+1:02d}.png';pix.save(path)
    checks['rendered_pages'].append(path.name)
    im=Image.open(path).convert('RGB');im.thumbnail((306,420))
    tile=Image.new('RGB',(330,455),'#eeeeee');tile.paste(im,((330-im.width)//2,10))
    ImageDraw.Draw(tile).text((12,434),f'Page {i+1}',font=font,fill='black')
    thumbs.append(tile)
for start in range(0,len(thumbs),12):
    batch=thumbs[start:start+12];rows=(len(batch)+2)//3
    canvas=Image.new('RGB',(990,455*rows),'white')
    for j,tile in enumerate(batch):canvas.paste(tile,((j%3)*330,(j//3)*455))
    canvas.save(render/f'contact-{start//12+1}.png')
log=(MAN/'MD02_extended_proofs.log').read_text(errors='replace')
checks['overfull_warnings']=re.findall(r'Overfull[^\n]*',log)
checks['undefined_reference_warning']='There were undefined references' in log
checks['pdf_sha256']=hashlib.sha256(pdf.read_bytes()).hexdigest()
(OUT/'pdf_layout_check.json').write_text(json.dumps(checks,indent=2))
assert not checks['out_of_page_text'], 'Text was detected outside the PDF page.'
assert not checks['replacement_characters'], 'Replacement glyphs were detected.'
assert not checks['undefined_reference_warning'], 'Unresolved cross references.'
# The manuscript and logs record any remaining overfull warnings explicitly.
for ext in ['aux','out','toc','log']:
    p=MAN/f'MD02_extended_proofs.{ext}'
    if p.exists():p.unlink()
for p in MAN.glob('build_pass*.log'):p.unlink()
# Rendered inspection images stay in the working container, not in the ZIP.
files=[p for p in ROOT.rglob('*') if p.is_file() and 'renders' not in p.relative_to(ROOT).parts
       and '__pycache__' not in p.parts and p.name not in ['SHA256SUMS','MANIFEST.txt']]
manifest='\n'.join(str(p.relative_to(ROOT)) for p in sorted(files))+'\n'
(ROOT/'MANIFEST.txt').write_text(manifest)
files.append(ROOT/'MANIFEST.txt')
(ROOT/'SHA256SUMS').write_text('\n'.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(ROOT))
                                       for p in sorted(files))+'\n')
files.append(ROOT/'SHA256SUMS')
archive=ROOT.parent/'MD02_extended_proofs.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files):z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
shutil.copy2(pdf,ROOT.parent/'MD02_extended_proofs.pdf')
print(json.dumps({'zip':str(archive),'zip_bytes':archive.stat().st_size,
                  'pdf':str(ROOT.parent/'MD02_extended_proofs.pdf'),'pages':len(DOC),
                  'overfull_warnings':checks['overfull_warnings'],
                  'validation_summary_present':(ROOT/'results'/'validation_summary.json').exists()},indent=2))
