"""Matrix-free logarithmic central path for circulant Fourier probability LPs.

The code verifies finite numerical consequences only; it is not a proof of
MD-02.  numpy and scipy are the only nonstandard dependencies.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.sparse.linalg import LinearOperator, cg

@dataclass
class State:
    n:int
    t:float
    y:np.ndarray
    L:float
    residual_l2:float
    iterations:int
    d:float|None=None
    z:float|None=None
    M3:float|None=None
    kappa:float|None=None

class FFTPath:
    def __init__(self,n:int,edge_mask):
        if not isinstance(n,(int,np.integer)) or n<2:
            raise ValueError('n must be an integer at least two')
        mask=np.asarray(edge_mask,dtype=bool)
        if mask.shape!=(n//2,):
            raise ValueError('one Boolean per nonzero inversion class is required')
        self.n=int(n); self.mask=mask.copy()
        self.allowed=np.zeros(n)
        for s,edge in enumerate(mask,1):
            if not edge:self.allowed[s]=self.allowed[-s%n]=1.
        self.eta=2*self.allowed-1; self.eta[0]=0
        self.k=np.fft.ifft(self.allowed).real
        self.d0=float(self.k[0]); self.D=self.d0*n/(n-1)-.5
        self.y=np.ones(n)
    def project(self,x):
        return np.fft.ifft(self.allowed*np.fft.fft(x)).real
    def _solve(self,diagonal,rhs,rtol=1e-12):
        def matvec(x):
            px=self.project(x)
            return self.project(diagonal*px)+x-px
        operator=LinearOperator((self.n,self.n),matvec=matvec,dtype=float)
        solution,info=cg(operator,rhs,rtol=rtol,atol=2e-15,maxiter=max(200,2*self.n))
        if info:
            raise RuntimeError(f'conjugate gradient did not converge: info={info}')
        return self.project(solution)
    def at(self,t:float,projector=True,tol=2e-12,max_iter=80):
        if not np.isfinite(t) or t<1:raise ValueError('t must be finite and at least one')
        n=self.n; weights=np.ones(n);weights[0]=t;y=self.y.copy()
        for iteration in range(max_iter):
            grad=self.project(weights/y)
            residual=float(np.linalg.norm(grad))
            if residual<=tol:break
            delta=self._solve(weights/y**2,grad)
            dec=float(grad@delta)
            if dec< -1e-20:raise RuntimeError('negative Newton decrement')
            neg=delta<0
            step=min(1.,float(.99*np.min(-y[neg]/delta[neg]))) if np.any(neg) else 1.
            accepted=False
            for _ in range(60):
                trial=step*delta/y
                if np.all(trial>-1):
                    gain=float(weights@np.log1p(trial))
                    if gain>=.05*step*dec-2e-14:
                        y+=step*delta;accepted=True;break
                step*=.5
            if not accepted:raise RuntimeError('positive Armijo line search failed')
        else:raise RuntimeError('Newton iteration did not converge')
        self.y=y.copy()
        L=float(np.log(y[0]/np.sqrt(t))+.5*np.log1p((t-1)/n))
        state=State(n,float(t),y,L,residual,iteration)
        if projector:
            zz=self._solve(weights/y**2,self.k)
            col=(np.sqrt(t)/y[0])*(np.sqrt(weights)/y)*zz
            d=float(col[0]);h=(n-1)/(t+n-1);z=d/h
            u=col[1:]+np.sqrt(t)*d/(n-1)
            M3=float(np.sum(u**3))
            denom=h**1.5*z*(1-z)
            kappa=M3/denom if denom>1e-14 else 0.
            state.d=d;state.z=z;state.M3=M3;state.kappa=kappa
        return state
    def initial_statistics(self):
        n=self.n; d=self.d0; h=(n-1)/n
        u=self.k[1:]+d/(n-1);M3=float(np.sum(u**3))
        den=h**1.5*(.25-self.D**2)
        result={'D':self.D,'d':d,'M3':M3,'kappa':M3/den if den>1e-14 else 0.}
        if d<1e-14:
            result.update(C3=0.,C4=0.,Q=0.,beta=0.,coherence=0.)
        else:
            v=self.k/d;v[0]=0;x=v*v
            jx=self.project(x)-self.k*(self.k@x)/d
            result.update(C3=float(np.sum(v**3)),C4=float(x@x),Q=float(jx@jx),
                          beta=float(v@v),coherence=float(np.max(np.abs(v))))
        return result

def dense_state(n:int,mask,t:float):
    """Independent dense real-orthonormal-basis Newton implementation."""
    j=np.arange(n); columns=[]
    for s,edge in enumerate(mask,1):
        if edge:continue
        if 2*s==n:columns.append((-1.)**j/np.sqrt(n))
        else:
            columns.extend([np.sqrt(2/n)*np.cos(2*np.pi*s*j/n),
                            np.sqrt(2/n)*np.sin(2*np.pi*s*j/n)])
    weights=np.ones(n);weights[0]=t
    if not columns:
        y=np.ones(n);P=np.zeros((n,n))
    else:
        B=np.column_stack(columns);y=np.ones(n)
        for _ in range(80):
            g=B.T@(weights/y)
            if np.linalg.norm(g)<2e-12:break
            H=B.T@((weights/y**2)[:,None]*B)
            delta=B@np.linalg.solve(H,g)
            neg=delta<0
            step=min(1.,float(.99*np.min(-y[neg]/delta[neg]))) if np.any(neg) else 1.
            dec=float((weights/y)@delta)
            for _ in range(60):
                trial=step*delta/y
                if np.all(trial>-1) and float(weights@np.log1p(trial))>=.05*step*dec-2e-14:
                    y+=step*delta;break
                step*=.5
            else:raise RuntimeError('dense line search failed')
        else:raise RuntimeError('dense Newton failed')
        Z=(np.sqrt(weights)/y)[:,None]*B
        P=Z@np.linalg.solve(Z.T@Z,Z.T)
    h=(n-1)/(t+n-1);d=float(P[0,0]);u=P[1:,0]+np.sqrt(t)*d/(n-1)
    return {'L':float(np.log(y[0]/np.sqrt(t))+.5*np.log1p((t-1)/n)),
            'M3':float(np.sum(u**3)),'d':d,'y':y}
