#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python algebra_checks.py
python parity_rank.py
python validate.py
python generate_tables.py
