# MD-02: extended proofs and early-path control

**Status: OPEN. This archive is not a complete solution of MD-02.**

The displayed target remains

    E[theta(G_n)] / sqrt(n) -> 1

for the independent fair inversion-class random circulant ensemble, through all integer orders. No substantive asymptotic case of that theta expectation limit is established here. This package does not justify changing the repository status to PARTIAL.

## Read first

The self-contained manuscript is `manuscript/MD02_extended_proofs.pdf`; its editable LaTeX source is alongside it. `STATUS.md` and `audit/PROOF_REVIEW.md` distinguish proved statements from the remaining estimate.

## Results developed in this continuation

Theorem 3.2 proves an all-orders joint central limit theorem for the initial imbalance D and the initial cubic M3, with independent Gaussian limits. It also proves n^2 E[kappa(1)^2] -> 3.

Theorem 6.1 proves a uniform second-order expansion on every fixed interval 1 <= t <= T:

    L_t = 2(1 - t^(-1/2)) D
          + 4(sqrt(t) - 2 + t^(-1/2)) M3(1) + remainder.

The squared L2 norm of the uniform remainder is O_T(log(en)^6 / n^3). The proof explicitly cancels both the degree-square correction and the deterministic order-1/n normalization correction.

Theorem 7.1 proves the genuinely adaptive early-time estimate

    n^2 E[sup_{1 <= t <= T_n} |kappa(t)-kappa(1)|^2] -> 0

whenever T_n^3 log(en)^6 = o(n). Thus n^2 E[kappa(t)^2] -> 3 uniformly on that interval; T_n = n^gamma is allowed for every fixed 0 < gamma < 1/3. The even-order singleton and composite orders are included.

## What remains unproved

The required full-scale weighted energy estimate on 1 <= t <= n^2 remains unproved. The uncontrolled range includes times proportional to n. The early interval carries a vanishing fraction of the weight in the full reduction. The fixed-time expectation result concerns the barrier surrogate H_t, not theta.

See Section 8 of the manuscript for the exact missing estimate and the quantitative explanation of the scale gap. No counterexample to MD-02 is claimed.

## Reproduce the computations

Use Python 3.10 or later. In an isolated environment:

```sh
python -m pip install -r code/requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 bash code/run_all.sh
```

The scripts write their results under `results/`. They include exact symbolic algebra, a fully integer enumeration of 30,240 signed parity systems, exact rational polynomial moments over all masks of orders 2--18, independent dense/FFT comparisons, fixed-time residual diagnostics, initial-law samples, and growing-time endpoint diagnostics. The exact polynomial calculations and the floating-point comparisons are distinguished in the output.

The numerical experiments do not prove any asymptotic theorem. Finite endpoint samples do not verify a continuum supremum. The mathematical proofs are in the manuscript.

To rebuild the PDF with a LaTeX installation:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error MD02_extended_proofs.tex
pdflatex -interaction=nonstopmode -halt-on-error MD02_extended_proofs.tex
```

`validation_tables.tex` contains tables generated from the recorded JSON outputs. The source of those tables is preserved in `results/`.

## Contents and provenance

`manuscript/` contains the PDF, LaTeX, and numerical tables. `code/` contains the independent implementation and checks. `results/` contains raw outputs, seeds, software versions, residuals, and logs. `audit/` contains the proof and limitation audit. `sources/provenance.json` records the public sources and hashes of the supplied archives. `prior/` preserves both supplied proof-pack archives unchanged.

`SHA256SUMS` covers the delivered files. No repository files were modified and no pull request was submitted.
