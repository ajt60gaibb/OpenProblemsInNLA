# Internal proof review

This is an internal audit of the written derivations, not an independent referee report or a proof-assistant certificate.

## Quantifiers and exceptional masks

All asymptotic statements use the actual inversion-class ensemble at every integer order. The class n/2 at even orders is a single independent sign. The complete and empty masks have normalized cubic skew defined as zero. Their exponentially small probabilities are handled explicitly; no division by zero is used in an expectation argument.

The exact initial diagonal is d = ((n-1)/n)(1/2+D). In expansions, the additional -D/n term is part of the order-n^(-3/2) remainder, not an exact equality being discarded without explanation.

## Joint Gaussian law

The distinct-class cubic hypergraph has O(n^2) edges, O(n) maximum degree, and codegree at most two. The martingale conditional variance is controlled by separating disjoint and intersecting pairs in a link. The fourth-increment sum tends to zero. The conditional covariance with the weighted degree sum is also controlled, establishing joint normality rather than merely zero covariance. The CLT criterion is proved in the manuscript.

## All-order parity counts

The fourth- and fifth-degree moment proofs do not divide in a finite field. Equations involving multiplication by two have at most two solutions modulo n. The quintic hand proof bounds degree-five, degree-three, and degree-one Walsh coefficients separately. The finite rank checker is an independent check. Its rank-two exceptions contain an original equation s=0, so they vanish modulo composite n as well as over the rationals.

## Bulk-profile estimates

The profile maximizer is obtained inside a strongly convex local ball, then identified as the unique global maximizer by strict concavity. Smoothness follows from invertibility on the fixed tangent space T_0. The same deterministic estimates hold for all root coordinates in the stated interval; this is why they support a time supremum rather than only a pointwise estimate.

The initial geometric cancellation is 2Q-C4 = -1/n + smaller terms. The exact formula is

    2Q-C4 = -beta^2/n + x^T R x - 2d C3^2.

The quintic Fourier-chaos bound is needed to control x^T R x. A bound for M3(1) alone would not suffice.

## Fixed-time expansion

The two root corrections are substituted into the root equation. In the logarithm, the degree-square term cancels against the square of the first root correction. The deterministic -(t-1)/(2n) term cancels the barrier normalization. `code/algebra_checks.py` verifies these identities symbolically.

## Growing-time cubic

The projector-column formula is derived from the profile tangent and its weighted orthogonality. The centering is exact with A=t/r, not an assumption that A=r:

    M3(t) = [(r/sqrt(t)) d(t)]^3
            [sum b_j^3 + 3 A beta_r/(n-1) - 2 A^3/(n-1)^2].

The error from replacing A beta_r by r is bounded explicitly. The leading -3r/n from the uncentered cubic cancels the leading centering correction. On one initial good event, the uniform error is bounded by C T^(3/2) log(en)^3 / n^(3/2). The exceptional event uses the deterministic bound |kappa| <= 1/2. Squaring produces the restriction T^3 log(en)^6 = o(n).

## Remaining gap

The proof does not establish that restriction at T proportional to n, nor at T=n^2. The early interval accounts for a vanishing fraction of the full energy weight. The late-time energy estimate is a separate, unproved claim. The current manuscript does not establish any new asymptotic subcase of the actual theta expectation target.
