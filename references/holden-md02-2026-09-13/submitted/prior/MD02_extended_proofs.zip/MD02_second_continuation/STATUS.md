# Status audit

## MD-02 remains OPEN

The target is the normalized expectation of the actual Lovasz theta number, not a fixed-time or early-time barrier value.

| Statement | Classification | Locator |
|---|---|---|
| Initial joint CLT, all orders | Proved in the manuscript | Theorem 3.2 |
| Fourth- and fifth-degree initial moment estimates | Proved in the manuscript | Lemma 4.1 |
| Initial root-conditioned geometric estimates | Proved in the manuscript | Lemma 4.2 |
| Deterministic bulk-profile estimates | Proved in the manuscript | Lemma 5.1 |
| Fixed-time second-order expansion | Proved in the manuscript | Theorem 6.1 |
| Fixed-time expected barrier bias | Proved for H_t, not theta | Corollary 6.2 |
| Uniform early-time skew control | Proved for T_n^3 log(en)^6 = o(n) | Theorem 7.1 |
| Early weighted skew energy asymptotic 3/n^2 | Proved in that same time range | Corollary 7.2 |
| Full-interval energy implication | Conditional reduction | Proposition 8.1 |
| Required late-time energy estimate | Unproved | Section 8 |
| MD-02 expectation limit | Not established | Section 1 and Section 8 |
| Repository PARTIAL status | Not justified by these results | This audit |

## Independence and validation

The proofs have been internally checked in the preparation of this package, not independently peer reviewed. Exact algebra and finite integer checks are included as support for specific steps. Numerical data are not used to assert a proof of the target or to replace a missing probabilistic bound.

## No hidden completion claim

The early-time theorem cannot be extended to t proportional to n by substituting the initial variance. Its proof relies on a uniform small-deformation condition that fails to supply such an extension. The endpoint estimate only turns the barrier into an accurate theta approximation when t/n grows, whereas the proved range has T_n/n -> 0.
