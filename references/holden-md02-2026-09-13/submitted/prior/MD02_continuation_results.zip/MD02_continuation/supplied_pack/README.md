# MD-02 central-path research pack

Start with MANIFEST.md and MD-02/result.md. The original conjecture is not resolved.

To reproduce the exact finite checks:

    python MD-02/exact_initial_skew.py

Only Python's standard library is required. The checker rewrites its JSON output. The general proofs are in Markdown and do not rely on floating-point experiments.

