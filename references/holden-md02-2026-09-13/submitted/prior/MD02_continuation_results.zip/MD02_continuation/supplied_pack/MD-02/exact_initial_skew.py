#!/usr/bin/env python3
"""Exact finite checks for the initial central-path cubic moment.
Only Python's standard library is required. This is not an asymptotic proof.
"""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

def inversion_classes(n):
    seen=set(); out=[]
    for s in range(1,n):
        if s not in seen:
            c=tuple(sorted({s,(-s)%n})); seen.update(c); out.append(c)
    return out

def check(n):
    classes=inversion_classes(n); m=n-1
    total=1<<len(classes); mean=Fraction(0); second=Fraction(0); degree_var=Fraction(0)
    max_abs=Fraction(0)
    for signs in product((-1,1),repeat=len(classes)):
        eta=[0]*n
        for c,sgn in zip(classes,signs):
            for s in c: eta[s]=sgn
        B=sum(eta)
        T=sum(eta[s]*eta[t]*eta[(-s-t)%n]
              for s in range(1,n) for t in range(1,n) if (s+t)%n)
        M=Fraction(T+3*B,8*n*n)-Fraction((m+2)*B**3,8*n*n*m*m)
        # Independent direct expansion of empirically centered triangle sum.
        cen=[Fraction(0)]+[Fraction(eta[s],2)-Fraction(B,2*m) for s in range(1,n)]
        direct=sum((cen[s]*cen[t]*cen[(-s-t)%n]
                    for s in range(1,n) for t in range(1,n) if (s+t)%n),Fraction(0))/n**2
        assert M==direct, (n, signs, M, direct)
        mean+=M; second+=M*M; max_abs=max(max_abs,abs(M)); degree_var+=Fraction(B*B,4*m*m)
    mean/=total; second/=total; degree_var/=total
    assert mean==0
    assert second<=Fraction(30,n*n)
    assert degree_var<=Fraction(1,2*m)
    return {'n':n,'configurations':total,'mean_M3':str(mean),'second_moment_M3':str(second),
            'max_abs_M3':str(max_abs),'degree_imbalance_variance':str(degree_var),'passed':True}

def main():
    rows=[check(n) for n in range(2,15)]
    p=Path(__file__).with_name('exact_initial_skew_results.json')
    p.write_text(json.dumps({'all_passed':True,'checks':rows},indent=2)+'\n')
    print(json.dumps({'all_passed':True,'orders':[r['n'] for r in rows], 'output':str(p)}))
if __name__=='__main__': main()
