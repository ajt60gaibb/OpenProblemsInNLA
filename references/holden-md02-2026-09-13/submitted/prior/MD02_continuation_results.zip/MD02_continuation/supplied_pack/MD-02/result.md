# MD-02: exact central-path reduction, with the concentration gap exposed

## Exact repository target

For every integer n >= 2, independently choose, with probability 1/2 each, the inversion classes {s,-s} in Z_n \ {0}. A self-inverse nonzero element is a singleton class. Let S be the selected union and let G have edge ij exactly when i-j belongs to S.

For the REAL symmetric semidefinite program

    theta(G) = max <J,X>
      subject to X >= 0, tr X = 1, and X_ij = 0 on edges,

prove or refute

    E theta(G_n)/sqrt(n) -> 1.

The limit is over all integers n. The target is an expectation statement. No special restriction on arithmetic subsequences, eigenvalue multiplicity, optimizer uniqueness, or algorithmic model is added.

## Outcome

**The original conjecture remains unproved in this pack.** There is no complete-proof or counterexample candidate for the original target.

The main new derivation is a regularized, exact self-dual path. Let K_S be the Fourier probability polytope described in central_path.md. For t >= 1 let p(t) be the unique strictly positive maximizer of

    t log p_0 + sum_{j != 0} log p_j

on K_S. Put A=t+n-1 and

    H_t(S) = n sqrt(A/t) p_0(t).

Then, deterministically,

    H_t(S) H_t(S^c) = n,
    sqrt(t/A) theta(G) <= H_t(S) <= sqrt(A/t) theta(G).

Thus the approximation is uniform over all graphs and becomes exact as t -> infinity.

An explicitly defined orthogonal projector P(t) gives d(t)=P_00(t), h(t)=(n-1)/(t+n-1), and z(t)=d(t)/h(t). Set

    u_j(t)=P_j0(t)+sqrt(t)d(t)/(n-1),  j != 0,
    M_3(t)=sum_{j != 0} u_j(t)^3.

With derivative taken with respect to log t, the following equations are exact:

    z' = (2-h)z(1-z)(1-2z) + 2 sqrt(t) M_3/h,
    (log(H_t/sqrt(n)))' = h(z-1/2).

The first term in the z equation points toward 1/2. The cubic moment is the only remaining forcing term in this scalar equation.

At t=1, the random model admits the elementary bounds

    E M_3(1) = 0,
    E M_3(1)^2 <= 30/n^2,
    E (z(1)-1/2)^2 <= 1/[2(n-1)].

These initial estimates are proved for the actual inversion-class model, including even n.

## Exact remaining gap

The initial estimate is NOT a bound for later t. We have not proved that the adaptive projector preserves the required cubic-moment cancellation.

A sufficient missing estimate is: there exist deterministic gamma_n=o(1/log n) such that, with probability 1-o(n^(-1/2)),

    sup_{1 <= t <= n^2} 2 sqrt(t)|M_3(t)|/h(t) <= gamma_n.

The proof in central_path.md shows that this estimate implies the repository's exact expectation limit. It includes the rare-event contribution and the finite-t approximation error.

It would be incorrect to count the initial second moment, a fixed-t numerical test, or the displayed sufficient condition itself as a resolution.

## Audit of the earlier sensitivity route

A single-optimizer pointwise inequality of the form

    log(theta(G)/theta(G+{+s,-s})) <= C f_s(G)^2

is false for every universal C, even when the circulant Fourier-LP optimizer is unique. The cycle family in cycle_obstruction.md proves this exactly.

However, the earlier AVERAGED reduction Var(log(theta/sqrt(n))) <= E sum_{s != 0}|f_s|^4 survives: its correct proof uses coefficients of TWO optimizers from complementary adjacent graphs, followed by Cauchy-Schwarz. See overlap_variance.md. The counterexample does not refute that averaged estimate.

## Source fidelity

All calculations concern the original real theta SDP. Complex Fourier notation is used only to diagonalize circulant matrices. Reflection averaging identifies the auxiliary probability LP with the real SDP, without weakening its value. No assertion of formal verification or repository acceptance is made.

