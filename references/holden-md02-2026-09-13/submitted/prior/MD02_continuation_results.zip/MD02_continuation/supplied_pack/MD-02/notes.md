# Research notes and remaining obstructions

## What was preserved and what was not

The earlier Fourier-LP/variance route was not discarded. Its correct sensitivity uses two different optimizers. A pointwise replacement of that product by a single squared coefficient is false. The exact odd-cycle family explains why optimizer uniqueness cannot repair the shortcut.

The new barrier route removes optimizer nonuniqueness and zero spectral coordinates. It also gives an exact complement relation at every parameter, rather than an approximate primal-dual relation.

## Principal unresolved step

The quantity M_3(t) in central_path.md is not the third moment of an independent random sample. Its coordinates depend on the entire random mask through the nonlinear barrier optimizer. The initial Fourier-projection calculation does not imply a corresponding calculation later in the path.

A tempting but invalid shortcut is to note that M_3 changes sign under complementation, conclude its expectation is zero, and replace the random forcing by zero in the differential equation. An ODE driven by a mean-zero dependent process need not have negligible fluctuations.

Another invalid shortcut is to use only sum u_j^2=h z(1-z). This controls a second moment, whereas the needed cancellation is a SIGNED cubic sum. The bound |sum u_j^3|<=max|u_j| sum u_j^2 is far too weak at the desired scale without additional delocalization and cancellation.

## Alternative exact fixed-point formulation

The barrier can also be expressed using real even physical coefficients f and g, normalized by f_0=g_0=1. Let beta=(t-1)/(t+n-1), alpha=n/(t+n-1)=1-beta. Their ordinary cyclic convolution satisfies

    f*g=alpha delta_0+beta 1.

This follows by Fourier transforming p_j q_j=a_j/[n(t+n-1)]. Their pointwise product equals delta_0 because their physical supports are complementary.

Writing h=f+g and k=f-g gives k_0=0 and k_s=eta_s h_s off zero. In Fourier coordinates,

    h_hat_j=sqrt(k_hat_j^2+4alpha), j != 0,
    h_hat_0=sqrt(k_hat_0^2+4[1+(n-1)beta]).

All square roots take the positive branch. The scalar map x -> sqrt(x^2+c) has derivative of absolute value less than one for c>0. However, this is not by itself a dimension-uniform contraction estimate: the derivative can approach one, and the input and random mask are dependent. No concentration theorem is inferred from this observation.

## Approaches that were not completed

- Extending the elementary initial third-moment estimate uniformly to t up to n^2.
- Controlling the diagonal-projector flow by a leave-one-class-out argument.
- A logarithmic-Sobolev argument that would turn the optimizer fourth moment into exponential-moment control without extra hypotheses.
- A direct feasible Fourier certificate achieving theta >= (1-o(1))sqrt(n) together with a matching upper certificate.
- A sharp-threshold/symmetry argument. Multipliers are not transitive on all nonzero residues for composite n, and symmetry alone does not control adaptive optimizer tails.

These are recorded as unclosed approaches, not as proven reductions beyond the precise results in the other files.

## Concrete next mathematical target

Prove or refute a propagated cubic-skew estimate for the EXACT projection P(t), rather than a surrogate independent projection. The sufficient condition in central_path.md gives explicit parameter range, scale, and exceptional-probability requirements. A proof only at t=1 or only for fixed n is insufficient.

The fourth-moment route remains another valid target; inequality (3) in overlap_variance.md modestly relaxes the decay rate needed. No numerical fit is used to assert that decay.

## Computation and provenance

The exact checker uses Fraction arithmetic and exhausts inversion-class masks at the listed small orders. It checks an identity and finite instances of proved bounds; it is not the proof of the asymptotic conjecture. The validation file records the actual checker execution result. No claim is made that earlier large LP experiments were reproduced in this continuation.

