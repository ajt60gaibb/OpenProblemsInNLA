# Self-review

## Strongest weakness

The concentration estimate needed to finish MD-02 is missing. This is not a cosmetic gap: the random projector becomes adaptive along the path, and the only proved cubic-moment bound is at its initial point. The conditional theorem must not be presented as a complete proof.

## Highest-priority checks for an adversarial verifier

1. Verify the Fourier normalization: X=f/n has eigenvalues p, and theta=n p_0. Check that the auxiliary non-even probability formulation has the same optimum as the original REAL SDP by reflection averaging.
2. Verify the weighted barrier duality C=nA using the perpendicular Fourier tangent spaces. Do not assume a theta product theorem to prove its own approximation bound; the pack derives the product identity by taking the barrier limit.
3. Verify the projector definition W^{-1}T_S, not WT_S, and the sign in the projector differential equation. The latter is negative because the moving tangent space is transformed by W^{-1}.
4. Check the centering u_j=P_j0+sqrt(t)d/(n-1), the cubic expansion, and the normalization z=d/h. Confusing P_00 with z changes the drift and invalidates the closure criterion.
5. Check the exceptional-probability requirement o(n^-1/2), which is used with the deterministic bound theta/sqrt(n)<=sqrt(n). Convergence in probability alone does not finish the expectation statement.
6. In the cycle obstruction, (2) is an UPPER bound on the modified graph's theta, not an exact formula. This direction is sufficient for the claimed LOWER bound on its logarithmic drop.
7. Check that the valid overlap sensitivity contains TWO optimizers. The false squared-coefficient shortcut and the valid averaged variance statement are different claims.

## Assumptions and edge cases checked

- Every integer n>=2 is admitted in the central-path and random-mask results.
- The even-order class n/2 is handled with weight one and one Fourier dimension.
- Empty and complete graphs are permitted. Their paths give z=1 and z=0, respectively, and satisfy the complement and approximation identities.
- Strictly positive barrier weights ensure a unique interior optimizer; differentiability is taken before sending t to infinity.
- The odd-cycle obstruction uses n odd and n>=7 so that +/-3 is a genuinely new class.
- The initial moment estimate treats signs as independent by CLASS, not by directed difference.
- No assumed spectral-edge theorem, Fourier universality theorem, or numerical convergence rate is invoked.

## Verification scope

The proofs are mathematical candidates, not Lean-verified results. Exact finite checks support selected algebraic identities, not the unproved propagation estimate. No historical novelty, repository acceptance, or status promotion is claimed.

