# Exact initial cubic-moment estimate

Use the definitions in central_path.md, and put m=n-1. Let eta_s be +1 when s is in the allowed nonedge set R=S^c, and -1 otherwise. Variables are independent across inversion classes and satisfy eta_s=eta_{-s}. Write

    B=sum_{s != 0}eta_s,
    T=sum_{s,t,v != 0; s+t+v=0}eta_s eta_t eta_v.

The sum defining T is over ORDERED triples.

## Formula

At t=1 the projection is the Fourier projection onto the modes R. If r=|R|, then, for j != 0,

    u_j=(1/n)sum_{s != 0}(1_R(s)-r/m)exp(2 pi i js/n).

These numbers are real, since R is inversion-invariant. Their zero-frequency coefficient is zero. Fourier orthogonality gives

    M_3(1)=(1/n^2)sum_{s+t+v=0; s,t,v != 0}
              (1_R(s)-r/m)(1_R(t)-r/m)(1_R(v)-r/m).

Since 1_R(s)-r/m=(eta_s-B/m)/2, expansion yields the exact rational expression

    M_3(1) = [T+3B-(m+2)B^3/m^2]/(8n^2).     (1)

To check the expansion: there are m(m-1) admissible ordered triples;

    sum_triples eta_s eta_t = B^2-m,
    sum_triples eta_s = (m-1)B.

The subtraction m uses eta_s eta_{-s}=1, which holds also for the even-order singleton.

## Mean and variance

Complementation changes every eta sign, so E M_3(1)=0.

Here is a deliberately non-sharp universal second-moment bound:

    E M_3(1)^2 <= 30/n^2.                     (2)

We prove it using only independent Rademacher orthogonality.

First, E T^2 <= 48m^2. After identifying eta_s=eta_{-s}, each triple monomial reduces either to a product of three DISTINCT class variables or to a single class variable. A degree-three monomial has coefficient at most 6*2^3=48, by ordering the three classes and choosing residue signs. The sum of their coefficients is at most m(m-1).

A degenerate triple has two residues equal: two opposite residues would force the third to be zero and are excluded. There are at most 3m such ordered triples. A fixed linear monomial has coefficient at most 12: choose the third residue from its class (at most two choices), solve 2s=-v (at most two solutions in Z_n), and choose its position (at most three choices). This overcounts all-equal triples and is therefore a valid upper bound. Its coefficients are nonnegative.

Orthogonality of distinct Rademacher monomials now gives

    E T^2 <= 48m(m-1)+12(3m) <= 48m^2.

Second, write B=sum_c w_c eta_c, w_c in {1,2}. Then

    E B^2=sum_c w_c^2 <= 2m,
    E B^6 <= 15(sum_c w_c^2)^3 <= 120m^3.

The sixth-moment estimate follows by pairing the six factors: only even multiplicities survive, and the 15 pairings overcount every surviving nonnegative term.

Using (x+y+z)^2<=3(x^2+y^2+z^2) in (1),

    E M_3(1)^2
      <= [144m^2+54m+360(m+2)^2/m]/[64(m+1)^4]
      <= [144m^2+3294m]/[64(m+1)^4]
      <= 30/(m+1)^2.

For the middle inequality, (m+2)^2/m<=9m for m>=1. The final inequality is equivalent to

    144m^2+3294m <= 1920(m+1)^2,

whose difference is 1776m^2+546m+1920>0.

Also

    D=z(1)-1/2=B/(2m),
    E D^2<=1/(2m).

## Scope

This is an all-order, elementary mathematical estimate at t=1, not merely a finite computational observation. The included exact-arithmetic script checks the formula and inequalities on all masks for n=2,...,14. Those checks audit implementation and algebra; the argument above proves the general statement.

There is NO claim that (2) holds uniformly for t>1. Proving an adequate propagated bound is the missing step in the central-path approach.

