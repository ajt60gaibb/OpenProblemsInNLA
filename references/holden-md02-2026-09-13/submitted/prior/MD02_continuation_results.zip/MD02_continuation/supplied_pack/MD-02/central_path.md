# Exact barrier duality and central-path asymmetry

All vectors below have coordinates indexed by Z_n. The dot product on real vectors is the ordinary Euclidean dot product. S is an inversion-invariant subset of Z_n \ {0}; S^c always means its complement WITHIN the nonzero elements.

## 1. Fourier probability formulation and the real field

For a real probability vector p define

    f_s = sum_j p_j exp(2 pi i j s/n).

Let K_S be the set of p >= 0 with sum p=1 and f_s=0 for s in S. Complex equalities here mean both real and imaginary parts vanish. The uniform probability vector belongs to the relative interior.

Reflection p_j -> p_{-j} preserves K_S and p_0. Averaging a vector with its reflection makes f real and even. For such f, X_ij=f_{i-j}/n is real symmetric positive semidefinite, has trace one, and has eigenvalues p_j. Conversely, cyclically averaging a feasible original SDP matrix gives this form. Its objective is n p_0. Therefore

    theta(G_S) = n max_{p in K_S} p_0.

Allowing a non-even p in the auxiliary LP does not change this maximum. For the barrier weights used below, uniqueness forces p itself to be even.

Let

    T_S = {v in R^n: sum v=0 and Fourier_s(v)=0 for s in S}.

The real Fourier decomposition gives

    T_S perpendicular to T_{S^c},
    T_S direct-sum T_{S^c} = 1^perp,
    dim T_S = n-1-|S|.

Here |S| counts residues, not classes. Thus a two-element class contributes two real Fourier dimensions; the even-order singleton contributes one.

## 2. Weighted barrier duality

Fix arbitrary positive weights a_j, and A=sum_j a_j. Let p be the maximizer on K_S of

    F_S(a) = max sum_j a_j log p_j.

This maximizer exists, is strictly positive, and is unique. Indeed, the feasible simplex is compact, the uniform vector has finite objective, approaching a boundary coordinate makes the objective tend to minus infinity, and the objective is strictly concave in the positive orthant.

Stationarity on the affine space says that the vector b with b_j=a_j/p_j is perpendicular to T_S. Thus b belongs to span{1}+T_{S^c}. It is positive. Normalize it to a probability vector q=b/C, where C=sum b_j. Then q belongs to K_{S^c}.

Because p-1/n and q-1/n belong to perpendicular spaces,

    p dot q = 1/n.

On the other hand, p dot q=A/C. Consequently C=nA and

    p_j q_j = a_j/(nA)                         (2.1)

for EVERY j. Also a_j/q_j=nA p_j, which is perpendicular to T_{S^c}. Strict concavity therefore shows that q is the unique maximizer of the SAME weighted barrier on K_{S^c}.

In particular,

    F_S(a)+F_{S^c}(a)
      = sum_j a_j log a_j - A log(nA).         (2.2)

No random assumption has been used.

## 3. Uniform approximation to theta

Set a_0=t >= 1 and a_j=1 for j != 0, so A=t+n-1. Let p(t),q(t) be the pair above. For ANY r in K_S,

    r dot q=1/n >= r_0 q_0.

Taking r_0 maximal gives theta(G_S) <= 1/q_0. Equation (2.1) now implies

    (t/A) theta(G_S) <= n p_0 <= theta(G_S).

Define

    H_t(S)=n sqrt(A/t) p_0(t).

Then

    sqrt(t/A) theta(G_S) <= H_t(S) <= sqrt(A/t) theta(G_S),
    H_t(S) H_t(S^c)=n.                        (3.1)

These bounds are uniform over S and n. Taking t to infinity proves both H_t -> theta and theta(G_S)theta(G_{S^c})=n. Thus this pack does not require an external theta product theorem.

At t=1 the optimizer is uniform, so H_1=sqrt(n).

## 4. Projector formula for derivatives

The positive maximizer is smooth in the positive weights: the negative Hessian of the objective, restricted to its fixed tangent space, is positive definite. This also follows by applying the implicit-function theorem to stationarity in any basis of T_S.

Put

    W=diag(p_j/sqrt(a_j)),
    P=orthogonal projection onto W^{-1} T_S.

If B is any full-row-rank matrix with kernel T_S, then this is equivalently the projection onto ker(BW). Differentiating the first-order conditions in a weight a_k gives

    partial p / partial a_k = W P e_k / sqrt(a_k),
    partial log p_i / partial a_k = P_ik / sqrt(a_i a_k).     (4.1)

For clarity, the negative objective Hessian is W^{-2}. The differential satisfies B dp=0 and W^{-2}dp=e_k/p_k minus a vector in range(B^T). Multiplication by W and projection onto ker(BW) gives (4.1).

For the complementary solution, W_bar=(nA)^{-1}W^{-1}. Thus the two projected spaces W^{-1}T_S and W T_{S^c} are perpendicular. Their dimensions sum to n-1. Their common perpendicular direction is sqrt(a): indeed,

    W^{-1}sqrt(a)=a/p=nAq is perpendicular to T_S,
    W sqrt(a)=p is perpendicular to T_{S^c}.

Therefore the FULL projector identity is

    P_S(a)+P_{S^c}(a)=I-sqrt(a)sqrt(a)^T/A.     (4.2)

Equivalently, the Hessians of the two optimal barrier values sum to diag(1/a)-11^T/A. In particular each Hessian is positive semidefinite and is bounded above by this matrix.

## 5. Exact nonlinear flow

Write a prime for differentiation with respect to tau=log t. Let

    m=n-1,   h=m/(t+m),   d=P_00,   z=d/h.

The projector identity implies 0 <= d <= h, hence 0 <= z <= 1.

Equation (4.1) yields

    (log p_j)'=sqrt(t/a_j)P_j0.

Consequently Z=(log W)' is diagonal, with

    Z_00=d-1/2,     Z_jj=sqrt(t)P_j0 for j != 0.

Because the projected space is W^{-1}T_S, its orthogonal projector evolves by

    P'=-(I-P)ZP-PZ(I-P).                       (5.1)

This follows by differentiating the subspace under the diagonal map W^{-1}; it can also be checked by differentiating P^2=P and its action on vectors W^{-1}v, v in T_S.

Taking entry 00 gives

    d'=d-3d^2+2d^3+2sqrt(t)sum_{j != 0}P_j0^3. (5.2)

The identity P sqrt(a)=0 and P^2=P give

    sum_{j != 0}P_j0=-sqrt(t)d,
    sum_{j != 0}P_j0^2=d-d^2.

Define centered column coordinates and their cubic moment by

    u_j=P_j0+sqrt(t)d/m,  j != 0,
    M_3=sum_{j != 0}u_j^3.

Then, exactly,

    sum u_j=0,
    sum u_j^2=h z(1-z).                        (5.3)

Substituting the centered cubic expansion into (5.2), and using h'=-h(1-h), gives

    z'=(2-h)z(1-z)(1-2z)+2sqrt(t)M_3/h.       (5.4)

For auditing the algebra, set x=t/m, so h=1/(1+x). Before division by h, the non-cubic part of d' is

    d - 3(1+2x)d^2 + 2(1+x)(1+2x)d^3.

For

    L_t=log(H_t/sqrt(n)),

one has

    L_t'=h(z-1/2),    L_1=0.                  (5.5)

At t=1, W is scalar and P is the Fourier projection onto T_S. Its diagonal is constant, so

    d(1)=(n-1-|S|)/n,
    z(1)=(n-1-|S|)/(n-1).                     (5.6)

Under complementation, z changes to 1-z and u changes to -u. Thus M_3 changes sign. Its unconditional mean is zero at EVERY t, but this does not bound its absolute size or variance.

## 6. A rigorous sufficient condition for the original expectation limit

The following is a CONDITIONAL theorem. Its hypothesis is not proved here.

Suppose there are deterministic gamma_n=o(1/log n) and events E_n with

    P(E_n^c)=o(n^(-1/2)),

such that on E_n,

    sup_{1 <= t <= n^2} 2sqrt(t)|M_3(t)|/h(t) <= gamma_n.     (6.1)

Then E theta(G_n)/sqrt(n) -> 1.

PROOF. Let D=z(1)-1/2. The independent inversion-class weights are w_c in {1,2}, with sum w_c=m and sum w_c^2<=2m. Writing independent Rademacher variables eta_c,

    D=(sum_c w_c eta_c)/(2m).

The elementary exponential bound cosh y<=exp(y^2/2), followed by Chernoff, gives

    P(|D|>a)<=2 exp(-m a^2).

Take a_n=sqrt(3 log(n)/m); the exceptional probability is at most 2n^-3.

Put e=z-1/2. Equation (5.4) is

    e'=-2(2-h)(1/4-e^2)e + g(t),
    |g(t)|<=gamma_n on E_n.

For sufficiently large n let b_n=max(a_n,4gamma_n)<=1/4. At e=b_n the damping magnitude is at least (3/8)b_n >= (3/2)gamma_n, so e'<=0. At e=-b_n the derivative is nonnegative. The scalar differential equation therefore cannot leave [-b_n,b_n] if it starts there.

Hence, on the intersection of the two good events,

    |L_{n^2}| <= b_n integral_1^{n^2} h(t) dt/t <= b_n log n.

The uniform theta approximation (3.1) gives

    |log(theta/sqrt(n))-L_{n^2}|
       <= (1/2)log(1+m/n^2) <= 1/(2n).

The resulting good-event bound tends to zero. On the bad event, theta/sqrt(n)<=sqrt(n), so its expectation contribution is at most

    sqrt(n)[o(n^-1/2)+2n^-3]=o(1).

Thus the expectation limsup is at most one. Complementation gives L and -L the same law, so E exp(L)=E cosh(L)>=1. This proves the claimed expectation limit. END PROOF.

## 7. What is not proved

Equation (6.1), or another estimate strong enough to replace it, remains open in this work. The initial estimate in initial_skew.md is insufficient: the projector becomes an adaptive nonlinear function of the same random mask as t grows. Neither zero mean by complement symmetry nor contraction of the scalar drift controls that forcing term.

