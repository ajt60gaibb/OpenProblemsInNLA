# Exact obstruction to single-optimizer quadratic sensitivity

This is a counterexample to an INTERMEDIATE inequality, not to MD-02.

## Claim refuted

There is no finite universal C such that, for every circulant graph G, every absent class {s,-s}, and the optimal Fourier coefficients f,

    log(theta(G)/theta(G+{s,-s})) <= C |f_s|^2.

The counterexample has a unique optimizer of the Fourier probability LP. This uniqueness statement does not assert uniqueness of every non-circulant matrix optimizer of the original SDP.

## Family and exact theta

Let n>=7 be odd and G=C_n with selected differences {+1,-1}. Put

    delta=pi/n,   c=cos(delta).

For a feasible Fourier probability distribution p, let x_j=cos(2pi j/n). Feasibility gives E_p x=0. All x_j>=-c, and only the two indices j=(n-1)/2,(n+1)/2 attain -c. Therefore

    0 >= p_0-c(1-p_0),
    p_0 <= c/(1+c).

Equality is attained by placing mass c/(1+c) at zero and mass 1/[2(1+c)] at each of the two minimizing indices. The sine constraint forces the two nonzero masses to be equal, proving uniqueness. Thus

    theta(C_n)=n c/(1+c),
    f_3=[c-cos(3delta)]/(1+c)
       =4c(1-c^2)/(1+c)>0.                   (1)

## A certificate after adding differences +/-3

Let H have selected differences +/-1 and +/-3. For every feasible p,

    E x=0,
    E(4x^3-3x)=0,

so E x^3=0. The polynomial

    P_c(x)=(x+c)(x-c/2)^2
          =x^3-(3c^2/4)x+c^3/4

is nonnegative for every x>=-c, in particular on all the Fourier grid points. Hence

    c^3/4=E P_c(x) >= p_0 P_c(1),

which yields the rigorous upper certificate

    theta(H) <= n c^3/(4-3c^2+c^3).           (2)

No equality assertion for (2) is needed.

Combining (1) and (2),

    log(theta(C_n)/theta(H))
       >= log(1+f_3/c^3).                    (3)

As n tends to infinity through odd orders,

    n^2 f_3 -> 2pi^2,
    log(1+f_3/c^3)/f_3^2 ~ n^2/(2pi^2) -> infinity.

This refutes every proposed universal C.

## Why the averaged fourth-moment reduction can still be correct

The VALID pointwise estimate involves f_s(G) multiplied by the coefficient of an optimizer for the complement of the graph AFTER the class is added. That second coefficient need not be comparable to f_s(G). Squaring the product and then averaging over complementary outside masks allows Cauchy-Schwarz to recover a fourth-moment bound. See overlap_variance.md.

It would therefore be a mistake either to keep the false single-optimizer inequality or to claim that this counterexample disproves the valid averaged reduction.

