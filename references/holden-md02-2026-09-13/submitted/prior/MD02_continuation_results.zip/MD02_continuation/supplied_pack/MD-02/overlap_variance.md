# Valid overlap sensitivity and expectation conversion

Let f(G) be a deterministic real even optimal Fourier coefficient vector, with f_0=1. A minimum-Euclidean-norm choice on the optimal face is one permissible selector. Let p be its Fourier probability vector. No uniqueness assumption is needed.

## 1. Two-optimizer sensitivity

Fix a class c={s,-s}, of size w in {1,2}, absent from G_0. Let G_1=G_0+c. Let f=f(G_0), and let g be the selected optimizer for the complement of G_1.

The supports of f and g can overlap only at 0 and the class c. If q is the Fourier probability vector of g, Parseval and nonnegativity give

    1+w f_s g_s = sum_r f_r g_r
                = n sum_j p_j q_j
                >= n p_0 q_0
                = theta(G_0)/theta(G_1).

The last equality uses the theta complement identity, proved in central_path.md. In particular f_s g_s>=0. Thus

    0 <= log(theta(G_0)/theta(G_1))
       <= log(1+w f_s g_s) <= w f_s g_s.      (1)

The product is essential.

## 2. Boolean Poincare and the fourth moment

Put L=log(theta(G_n)/sqrt(n)). Complementation changes L to -L, so E L=0. For independent fair class bits, the elementary product-space Poincare inequality is

    Var L <= (1/4)sum_c E_outside (L(G_0)-L(G_1))^2.

One proof expands L in the orthonormal Rademacher characters: the variance counts each nonconstant coefficient once, while the right side counts it once per coordinate in its nonempty support.

For a fixed class, the outside-mask complement maps the law of f_s(G_0) to the law of g_s. Applying (1) and Cauchy-Schwarz,

    E_outside (Delta_c L)^2 <= w^2 E_outside |f_s(G_0)|^4.

Define

    R_n=E sum_{s != 0}|f_s(G_n)|^4.

A selected class has zero coefficients. Thus

    R_n=(1/2)sum_c w E_outside |f_s(G_0)|^4.

Since w^2<=2w,

    Var L <= R_n.                            (2)

The cycle obstruction does not invalidate this argument.

## 3. Elementary spectral tail

Let W=J-I-2A_G. For any feasible SDP matrix X,

    theta(G)-1=<W,X><=||W||,

because X is positive semidefinite with trace one. Therefore theta(G)<=1+||W||. W is circulant, and each eigenvalue is a Rademacher sum with real class coefficients of squared sum at most 2(n-1). Chernoff using cosh y<=exp(y^2/2), followed by a union bound over n eigenvalues, yields

    P(||W||>=u)<=2n exp(-u^2/[4(n-1)]).

The complement replaces W by -W. Consequently, on ||W||<=sqrt(24n log n),

    |L|<=M_n=log(n^(-1/2)+sqrt(24 log n)),

and the exceptional probability is at most 2n^-5.

## 4. A modestly sharper conversion to expectations

The function (cosh x-1)/x^2 is nondecreasing for x>0. This follows immediately by expanding cosh into its nonnegative even power series. Set

    c_n=(cosh M_n-1)/M_n^2.

By complement symmetry, E exp(L)=E cosh(L). On the good spectral event,

    cosh L-1 <= c_n L^2.

Always |L|<=0.5 log n, since 1<=theta<=n. Hence the exceptional expectation contribution is at most 2n^(-9/2). Combining with (2),

    0 <= E theta(G_n)/sqrt(n)-1
       <= c_n R_n + 2n^(-9/2).               (3)

As n grows,

    c_n = O(sqrt(log n)/(log log n)^2).

Thus R_n=o((log log n)^2/sqrt(log n)) is sufficient for MD-02. This is a small improvement over using the coarser bound cosh L-1<=constant*exp(M_n)L^2. It still does not prove any required decay of R_n.

All tails and constants above are valid for even n and its singleton class. The asymptotic little-o statement is only interpreted for large n, so log log n at small orders is irrelevant.

