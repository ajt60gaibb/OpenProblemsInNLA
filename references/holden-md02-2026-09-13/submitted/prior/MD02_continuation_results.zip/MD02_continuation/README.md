# MD-02 — Research continuation and partial results

**Status: MD-02 is not solved by this package.** The requested limit

\[
\lim_{n\to\infty}\frac{\mathbb E\vartheta(G_n)}{\sqrt n}=1
\]

has neither been proved nor disproved here. The archive contains a substantive continuation of the proof pack supplied by the user, with complete written proofs of additional lemmas, exact finite certificates, reproducible numerical experiments, and a precise remaining probabilistic estimate. The conditional reduction is not presented as a solution.

Start with **`manuscript/MD02_continuation.pdf`**. Its LaTeX source is alongside it. `STATUS.md` gives a compact claim-by-claim audit.

## Results established in the manuscript

1. **Global central-path inequality and an averaged-energy reduction.** A Lyapunov argument bounds log-theta deviation by a weighted integral of the normalized cubic skew. A quantitative expectation inequality reduces MD-02 to a time-averaged second-moment estimate, rather than to a uniform-in-time event. The reduction is proved; the needed moment estimate is not.
2. **Sharp initial cubic variance, including even orders.** With the proof pack's normalization,
   \[
   \mathbb E M_3(1)^2\le\frac{3}{16n^2},\qquad
   n^2\mathbb E M_3(1)^2\longrightarrow\frac3{16}.
   \]
   The constant is optimal as a universal upper-bound constant. Exact odd/even formulas and an all-orders proof are included. The normalized initial energy satisfies \(n^2\mathbb E\kappa(1)^2\to3\).
3. **Exact 17-vertex derivative obstruction.** The graph with edge classes represented by 4, 5, 6, 7 has initial imbalance zero and initial cubic skew zero, but
   \[
   \left.\frac{dM_3}{d\log t}\right|_{t=1}=\frac{24}{4913},\qquad
   L_{e^\tau}=\frac8{4913}\tau^3+O(\tau^4).
   \]
   Initial zero skew does not propagate automatically. This is not a counterexample to MD-02.
4. **Balanced square-order graphs with large optimizer fourth moment.** For every odd \(k\ge3\), explicit graphs on \(n=k^2\) vertices have degree \((n-1)/2\), theta value exactly \(\sqrt n\), and a unique Fourier-probability optimizer with fourth moment \(\sqrt n-1\). This blocks a deterministic shortcut, not an averaged random-ensemble estimate.

“Additional” means additional to the supplied pack. No historical priority or independent peer-review claim is made. These are written mathematical proofs, not proof-assistant formalizations.

## Exact missing estimate

Let \(h(t)=(n-1)/(t+n-1)\), let \(z(t)\) and \(M_3(t)\) be the central-path quantities defined in the manuscript, and put

\[
\kappa(t)=\frac{M_3(t)}{h(t)^{3/2}z(t)(1-z(t))},\qquad
\rho_n(t)=\frac{h(t)^{3/2}}{(2-h(t))\sqrt t}.
\]

At empty and complete masks set \(\kappa=0\). Write

\[
\mathcal A_{n,T}=\int_1^T\rho_n(t)\,dt,\qquad
\mathcal V_n=\frac{1}{\mathcal A_{n,n^2}}\int_1^{n^2}\rho_n(t)\mathbb E\kappa(t)^2\,dt.
\]

The proved implication requires

\[
n\mathcal V_n=o\!\left(\frac{(\log\log n)^2}{\sqrt{\log n}}\right).
\]

For example, \(\mathcal V_n=O(n^{-2})\) would suffice. **This estimate is unproved.** The exact initial moment and finite grid computations do not supply it. The central-path projector depends adaptively on the same random edge mask, which is the dependence the missing estimate must control.

## Validation performed

Exact rational checks independently count Walsh coefficients at 87 orders, enumerate all 1,532 masks across orders 2 through 18, and check the sharp variance inequality through order 10,000. The manuscript's polynomial proof establishes the inequality for all orders; finite enumeration alone does not.

Floating-point checks verify the barrier, projector, complement, approximation, and flow identities on odd and even orders. The maximum flow finite-difference residual is below \(5.02\times10^{-11}\). Monte Carlo uses 640 independent base graphs across ten orders up to 512, with each graph paired with its complement. A pair is one observation, not two independent observations. Central-path diagnostics use 64 base graphs across eight orders, with 45 log-spaced times plus \(t=n\).

Every sampled mask is recorded. Numerical quadrature is not a continuum bound, and Monte Carlo agreement is not a proof of an expectation limit. Fourth moments in the Monte Carlo output are for the basic optimizers chosen by the LP solver, not a separately computed minimum-norm selector.

## Reproduce

Python 3.10 or newer is required. Tested versions: Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, mpmath 1.3.0.

```bash
python -m pip install -r code/requirements.txt
bash code/run_all.sh
```

Exact checks alone need only the standard library:

```bash
python code/exact_checks.py
```

Individual numerical phases can be run or resumed independently:

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/numerical_checks.py --phase identities
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/numerical_checks.py --phase monte-carlo --pairs 64
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python code/numerical_checks.py --phase paths --path-samples 8
python code/obstruction_checks.py
```

Outputs default to `results/`. `--output-dir` (numerical checks) and `--output` (exact and obstruction checks) permit alternate destinations. Use ordinary Python execution: `python -O` disables the assertions used by the check programs.

To rebuild the PDF:

```bash
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error MD02_continuation.tex
pdflatex -interaction=nonstopmode -halt-on-error MD02_continuation.tex
```

The root `SHA256SUMS` can be verified on a system with `sha256sum`:

```bash
sha256sum -c SHA256SUMS
```

Rerunning programs changes output files and may invalidate their recorded checksums. The unchanged supplied pack has its own checksum manifest.

## Contents

- `manuscript/`: final PDF, LaTeX, generated numerical tables.
- `code/`: exact checks, Fourier LP/central-path implementation, experiment drivers, dependencies, runner.
- `results/`: exact certificates, raw numerical data, experiment logs, validation summary.
- `sources/`: bibliographic references and provenance, including the original upload's SHA-256.
- `supplied_pack/`: unchanged extracted contents of the user's original proof pack.
- `STATUS.md`: explicit audit of established and unestablished claims.

The public sources were read on the web without using a GitHub plugin. Source access date: September 12, 2026.
