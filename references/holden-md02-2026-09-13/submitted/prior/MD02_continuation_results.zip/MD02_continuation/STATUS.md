# Mathematical status and claim audit

**MD-02 resolved: NO.**

The package does not prove or refute the expectation limit requested by the user. It does not claim that an unproved concentration statement follows from numerical evidence, complement symmetry, or the initial variance computation.

| Claim | Status | Evidence / location |
|---|---|---|
| Real Fourier LP, weighted barrier duality, projector flow | Proved, reconstructed from supplied pack | Manuscript Sections 2–3 |
| Exact theta/complement product, all orders | Proved | Proposition 3.2 |
| Global weighted-skew inequality | Proved | Theorem 4.1 |
| Quantitative expectation inequality involving averaged skew energy | Proved | Theorem 4.2 |
| Its sufficient energy estimate for the actual adaptive random path | **NOT PROVED** | Equation (1.1), Sections 4 and 9 |
| Alternative normalized uniform condition | Conditional implication proved; hypothesis **not proved** | Corollary 4.3 |
| Sharp initial variance upper bound and asymptotic constant | Proved | Theorem 5.3 |
| Normalized initial energy limit 3 | Proved | Corollary 5.4 |
| 17-vertex nonpropagation example | Proved; exact integer certificate | Theorem 6.1 |
| Balanced square-order large-fourth-moment family | Proved | Theorem 6.2 |
| Two-optimizer fourth-moment sensitivity reduction | Proved, reconstructed from supplied pack | Proposition 7.1 |
| Required averaged optimizer fourth-moment estimate | **NOT PROVED** | Section 7 |
| Any deterministic obstruction above refutes MD-02 | **NO** | They refute only specified shortcuts |
| Numerical evidence proves the limit or a continuous-time estimate | **NO** | Section 8 explains the limitations |
| Proof-assistant formalization or independent peer review | **NOT PERFORMED** | Written proofs and programmatic checks only |

## How the gap differs from the supplied pack

The continuation replaces one possible uniform forcing hypothesis with an averaged, weighted second-moment condition. This avoids requiring simultaneous pathwise control, but requires its own quantitative averaged rate; it is not asserted to be logically weaker than every uniform-forcing condition. The input remains unproved. It also sharpens the initial variance from the supplied upper bound to the optimal universal constant and identifies new exact obstacles to deterministic shortcuts.

## What would finish this approach

With the manuscript's notation, it is sufficient to prove

\[
\frac{n}{\mathcal A_{n,n^2}}\int_1^{n^2}\rho_n(t)\mathbb E\kappa(t)^2\,dt
=o\!\left(\frac{(\log\log n)^2}{\sqrt{\log n}}\right).
\]

This is an expectation over the actual random circulant mask at each time. Replacing the evolved projector by an independent random projector would be an unjustified change of model. Proving the same scale only at time one, on a finite time grid, or on a collection of sampled masks is insufficient.
