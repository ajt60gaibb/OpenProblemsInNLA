#!/usr/bin/env python3
"""Check the two additional obstruction examples.

The n=17 derivative certificate is exact integer arithmetic (exact_checks.py).
This file additionally checks the local Taylor coefficient using 70-digit
arithmetic, and emits exact combinatorial certificates for the square-order
balanced family with theta=sqrt(n) but large optimizer fourth moment.
"""
from __future__ import annotations
import argparse
from fractions import Fraction
import json
from pathlib import Path

import mpmath as mp


def balanced_family(k: int) -> dict:
    if k < 3 or k % 2 == 0:
        raise ValueError("Use an odd integer k >= 3")
    n = k * k
    mandatory = set(range(1, k))
    forbidden = {s for s in range(1, n // 2 + 1) if s % k == 0}
    target = (n - 1) // 4
    edges = set(mandatory)
    for s in range(1, n // 2 + 1):
        if len(edges) == target:
            break
        if s not in forbidden:
            edges.add(s)
    support_p = list(range(0, n, k))
    assert len(edges) == target
    assert mandatory <= edges and not (edges & forbidden)
    assert len(support_p) == k
    assert Fraction(len(support_p), k) == 1
    assert n * Fraction(1, k) == k
    assert 2 * len(forbidden) == k - 1
    return {"k": k, "n": n, "edge_class_representatives": sorted(edges),
        "degree": 2 * len(edges), "required_degree": (n - 1) // 2,
        "unique_optimal_probability_support": support_p,
        "probability_on_each_support_point": str(Fraction(1, k)),
        "theta": k, "sqrt_n": k,
        "optimizer_fourth_moment_R4": k - 1,
        "dual_nonzero_Fourier_coefficients": {
            str(s): str(Fraction(k - s, k)) for s in range(1, k)},
        "probability_of_unbalanced_or_balanced_mandatory_pattern":
            str(Fraction(1, 2 ** (3 * (k - 1) // 2)))}


def high_precision_state(tau: str) -> dict:
    mp.mp.dps = 70
    n = 17
    t = mp.exp(mp.mpf(tau))
    allowed = [1, 2, 3, 8]
    V = mp.matrix([[mp.sqrt(mp.mpf(2) / n) * mp.cos(2 * mp.pi * s * j / n)
                    for s in allowed] for j in range(n)])
    x = mp.matrix([0] * len(allowed))
    a = mp.matrix([t] + [mp.mpf(1)] * (n - 1))
    for iteration in range(100):
        y = mp.matrix([1] * n) + V * x
        grad = V.T * mp.matrix([a[j] / y[j] for j in range(n)])
        Hess = V.T * mp.diag([a[j] / y[j] ** 2 for j in range(n)]) * V
        step = mp.lu_solve(Hess, grad)
        if mp.fdot(grad, step) < mp.mpf('1e-125'):
            break
        dy = V * step
        length = mp.mpf(1)
        for j in range(n):
            if dy[j] < 0:
                length = min(length, -mp.mpf('.99') * y[j] / dy[j])
        x += length * step
    else:
        raise ArithmeticError("High-precision Newton iteration did not converge")
    y = mp.matrix([1] * n) + V * x
    U = mp.diag([mp.sqrt(a[j]) / y[j] for j in range(n)]) * V
    column = U * mp.lu_solve(U.T * U, mp.matrix([U[0, k] for k in range(len(allowed))]))
    d = column[0]
    u = [column[j] + mp.sqrt(t) * d / (n - 1) for j in range(1, n)]
    M3 = mp.fsum(v ** 3 for v in u)
    L = mp.log(mp.sqrt((t + n - 1) / (n * t)) * y[0])
    return {"log_t": tau, "t": mp.nstr(t, 50), "M3": mp.nstr(M3, 50),
            "L": mp.nstr(L, 50), "M3_over_log_t": mp.nstr(M3 / mp.mpf(tau), 50),
            "L_over_log_t_cubed": mp.nstr(L / mp.mpf(tau) ** 3, 50)}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "obstruction_checks.json")
    args = parser.parse_args()
    rows = [high_precision_state(tau) for tau in ['0.01', '0.005', '0.001', '0.0001']]
    expected_M3 = mp.mpf(24) / 4913
    expected_L = mp.mpf(8) / 4913
    assert abs(mp.mpf(rows[-1]['M3_over_log_t']) / expected_M3 - 1) < mp.mpf('.001')
    assert abs(mp.mpf(rows[-1]['L_over_log_t_cubed']) / expected_L - 1) < mp.mpf('.001')
    result = {"passed": True, "precision_decimal_digits": 70,
              "exact_M3_first_derivative": "24/4913", "exact_L_cubic_coefficient": "8/4913",
              "high_precision_n17": rows,
              "balanced_square_order_families": [balanced_family(k) for k in range(3, 32, 2)],
              "scope": "Finite checks; neither obstruction is a counterexample to MD-02."}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({"passed": True, "output": str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
