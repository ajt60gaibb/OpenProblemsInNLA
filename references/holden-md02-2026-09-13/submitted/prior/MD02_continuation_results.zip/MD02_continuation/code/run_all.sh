#!/usr/bin/env bash
# Run from any working directory. Numeric outputs are written to ../results/.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export OPENBLAS_NUM_THREADS="${OPENBLAS_NUM_THREADS:-1}"
export OMP_NUM_THREADS="${OMP_NUM_THREADS:-1}"
export MKL_NUM_THREADS="${MKL_NUM_THREADS:-1}"
export PYTHONDONTWRITEBYTECODE=1
python "$ROOT/code/exact_checks.py"
python "$ROOT/code/obstruction_checks.py"
python "$ROOT/code/numerical_checks.py" --phase all --pairs 64 --path-samples 8
printf '%s\n' 'All finite check programs completed; this does not prove the MD-02 asymptotic claim.'
