"""Numerical Fourier LP and weighted central path for MD-02.

All arrays are real; cosine coordinates impose reflection symmetry.  Sine
coordinates are restored when a full real tangent-space projector is needed.
Floating-point outputs are diagnostics, not exact mathematical certificates.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import atan, sqrt
from typing import Iterable

import numpy as np
from numpy.typing import NDArray
from scipy.linalg import solve, qr
from scipy.optimize import linprog

Array = NDArray[np.float64]


def validate_mask(n: int, mask: Iterable[bool]) -> NDArray[np.bool_]:
    if not isinstance(n, (int, np.integer)) or n < 2:
        raise ValueError("n must be an integer at least 2")
    out = np.asarray(list(mask), dtype=bool)
    if out.shape != (n // 2,):
        raise ValueError(f"Expected {n // 2} inversion-class bits, got {out.shape}")
    return out


def real_basis(n: int, edge_mask: NDArray[np.bool_], even_only: bool = True) -> Array:
    """Orthonormal real Fourier basis of the (even) nonedge tangent space."""
    j = np.arange(n, dtype=float)
    columns = []
    for s, is_edge in enumerate(edge_mask, start=1):
        if is_edge:
            continue
        angle = 2 * np.pi * s * j / n
        if 2 * s == n:
            columns.append(np.cos(angle) / sqrt(n))
        else:
            columns.append(sqrt(2 / n) * np.cos(angle))
            if not even_only:
                columns.append(sqrt(2 / n) * np.sin(angle))
    return np.column_stack(columns) if columns else np.zeros((n, 0), dtype=float)


@dataclass
class LPResult:
    theta: float
    p: Array
    f: Array
    equality_residual: float
    dual_slack_violation: float
    primal_dual_gap: float


def theta_lp(n: int, mask: Iterable[bool]) -> LPResult:
    edge_mask = validate_mask(n, mask)
    reps = np.arange(n // 2 + 1, dtype=float)
    C = np.vstack((np.ones(reps.size),
                   np.cos(2 * np.pi * np.outer(reps[1:][edge_mask], reps) / n)))
    b = np.zeros(C.shape[0]); b[0] = 1
    c = np.zeros(reps.size); c[0] = -n
    res = linprog(c, A_eq=C, b_eq=b, bounds=(0, None), method="highs",
                  options={"dual_feasibility_tolerance": 1e-9,
                           "primal_feasibility_tolerance": 1e-9})
    if not res.success:
        raise RuntimeError(f"LP failed for n={n}: {res.message}")
    p = np.empty(n, dtype=float)
    p[0] = res.x[0]
    for j in range(1, reps.size):
        weight = 1 if 2 * j == n else 2
        p[j] = p[-j % n] = res.x[j] / weight
    f = np.fft.fft(p).real
    dual = np.asarray(res.eqlin.marginals)
    slack = c - C.T @ dual
    return LPResult(theta=float(-res.fun), p=p, f=f,
                    equality_residual=float(np.max(np.abs(C @ res.x - b))),
                    dual_slack_violation=float(max(0., -np.min(slack))),
                    primal_dual_gap=float(abs(c @ res.x - b @ dual)))


@dataclass
class State:
    n: int
    t: float
    p: Array
    q: Array
    P: Array | None
    d: float
    h: float
    z: float
    u: Array
    M3: float
    kappa: float
    H: float
    L: float
    stationarity_scaled: float
    q_sum_error: float
    m2_error: float

    def record(self) -> dict:
        return {"n": self.n, "t": self.t, "p0": float(self.p[0]),
                "H": self.H, "L": self.L, "d": self.d, "z": self.z,
                "M3": self.M3, "kappa": self.kappa,
                "max_abs_u": float(np.max(np.abs(self.u))),
                "stationarity_scaled": self.stationarity_scaled,
                "q_sum_error": self.q_sum_error, "m2_error": self.m2_error}


class CentralPath:
    """Warm-started damped Newton solver for the weighted log barrier."""

    def __init__(self, n: int, mask: Iterable[bool]):
        self.n = n
        self.mask = validate_mask(n, mask)
        self.V = real_basis(n, self.mask, even_only=True)
        self.x = np.zeros(self.V.shape[1], dtype=float)

    def solve(self, t: float, full_projector: bool = False) -> State:
        if not np.isfinite(t) or t < 1:
            raise ValueError("The supplied implementation uses finite t >= 1")
        n, V = self.n, self.V
        a = np.ones(n); a[0] = t
        if self.x.size:
            for iteration in range(180):
                y = 1 + V @ self.x
                if np.min(y) <= 0:
                    raise ArithmeticError("Newton iterate left the positive orthant")
                grad = V.T @ (a / y)
                U = (np.sqrt(a) / y)[:, None] * V
                step = solve(U.T @ U, grad, assume_a="pos")
                decrement = max(0., float(grad @ step))
                if decrement <= 1e-23 * a.sum():
                    break
                dy = V @ step
                negative = dy < 0
                length = min(1., .99 * float(np.min(-y[negative] / dy[negative]))) if np.any(negative) else 1.
                value = float(a @ np.log(y))
                roundoff = 5e-14 * max(1., abs(value))
                while length >= 1e-15:
                    trial = y + length * dy
                    if np.min(trial) > 0 and a @ np.log(trial) >= value + 1e-4 * length * decrement - roundoff:
                        break
                    length *= .5
                if length < 1e-15:
                    raise ArithmeticError("Newton line search stalled")
                self.x += length * step
            else:
                raise ArithmeticError("Newton iteration limit exceeded")
        y = 1 + V @ self.x
        if np.min(y) <= 0:
            raise ArithmeticError("Nonpositive barrier result")
        U = (np.sqrt(a) / y)[:, None] * V
        Q = qr(U, mode="economic")[0] if V.shape[1] else np.zeros((n, 0))
        column = Q @ Q[0, :] if Q.shape[1] else np.zeros(n)
        d = float(column[0]); h = (n - 1) / (t + n - 1)
        z = d / h
        # Degenerate empty/complete masks have exact z=1/0 and M3=0.
        if np.all(self.mask):
            z, d = 0., 0.
        elif not np.any(self.mask):
            z, d = 1., h
        u = column[1:] + sqrt(t) * d / (n - 1)
        M3 = float(np.sum(u ** 3))
        denominator = h ** 1.5 * z * (1 - z)
        kappa = M3 / denominator if denominator > 1e-18 else 0.
        p = y / n
        q = a / (n * (t + n - 1) * p)
        P = None
        if full_projector:
            V_full = real_basis(n, self.mask, even_only=False)
            U_full = (np.sqrt(a) / y)[:, None] * V_full
            Q_full = qr(U_full, mode="economic")[0] if V_full.shape[1] else np.zeros((n, 0))
            P = Q_full @ Q_full.T
        grad = V.T @ (a / y)
        scaled_residual = float(np.max(np.abs(grad))) / max(1., sqrt(float(a.sum()))) if grad.size else 0.
        H = n * sqrt((t + n - 1) / t) * p[0]
        return State(n=n, t=float(t), p=p, q=q, P=P, d=d, h=h, z=float(z), u=u,
                     M3=M3, kappa=float(kappa), H=float(H), L=float(np.log(H / sqrt(n))),
                     stationarity_scaled=scaled_residual,
                     q_sum_error=float(abs(q.sum() - 1)),
                     m2_error=float(abs(np.dot(u, u) - h * z * (1 - z))))


def energy_weight_mass(n: int, T: float) -> float:
    if n < 2 or T < 1:
        raise ValueError("n >= 2 and T >= 1 are required")
    return 2 * sqrt(n - 1) * (atan(sqrt(T / (T + n - 1))) - atan(1 / sqrt(n)))
