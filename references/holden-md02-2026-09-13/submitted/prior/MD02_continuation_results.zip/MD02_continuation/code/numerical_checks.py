#!/usr/bin/env python3
"""Reproducible floating-point checks and small Monte Carlo experiments.

These checks do not establish asymptotics, exact feasibility in real arithmetic,
or a uniform-in-t bound.  Path maxima and integrals are discrete-grid diagnostics.
"""
from __future__ import annotations

import argparse
import json
from math import sqrt
from pathlib import Path
import platform

import numpy as np
import scipy

from md02_numeric import CentralPath, energy_weight_mass, theta_lp


def identity_checks() -> dict:
    rng = np.random.default_rng(8211702)
    maxima = {name: 0. for name in ["barrier_product", "reciprocal_dual",
              "projector_complement", "projector_idempotence", "theta_product",
              "theta_approximation_violation", "stationarity_scaled", "q_sum_error",
              "m2_error", "z_flow_finite_difference", "L_flow_finite_difference",
              "full_projector_flow_finite_difference", "lp_equality_residual",
              "lp_dual_slack_violation", "lp_primal_dual_gap"]}
    cases = []
    for n in [5, 9, 17, 18, 31, 32, 63, 64]:
        mask = rng.integers(0, 2, n // 2).astype(bool)
        mask[0], mask[-1] = False, True
        primal, dual = theta_lp(n, mask), theta_lp(n, ~mask)
        maxima["theta_product"] = max(maxima["theta_product"], abs(primal.theta * dual.theta / n - 1))
        for result in (primal, dual):
            for name in ("equality_residual", "dual_slack_violation", "primal_dual_gap"):
                maxima["lp_" + name] = max(maxima["lp_" + name], getattr(result, name))
        first, second = CentralPath(n, mask), CentralPath(n, ~mask)
        for t in [1., sqrt(n), float(n), float(n * n)]:
            p = first.solve(t, full_projector=True)
            q = second.solve(t, full_projector=True)
            a = np.ones(n); a[0] = t
            target = np.eye(n) - np.outer(np.sqrt(a), np.sqrt(a)) / a.sum()
            maxima["barrier_product"] = max(maxima["barrier_product"], abs(p.H * q.H / n - 1))
            maxima["reciprocal_dual"] = max(maxima["reciprocal_dual"], float(np.max(abs(p.q - q.p))))
            maxima["projector_complement"] = max(maxima["projector_complement"], float(np.max(abs(p.P + q.P - target))))
            maxima["projector_idempotence"] = max(maxima["projector_idempotence"], float(np.max(abs(p.P @ p.P - p.P))))
            error = abs(np.log(primal.theta / p.H)) - .5 * np.log1p((n - 1) / t)
            maxima["theta_approximation_violation"] = max(maxima["theta_approximation_violation"], error)
            for name in ["stationarity_scaled", "q_sum_error", "m2_error"]:
                maxima[name] = max(maxima[name], getattr(p, name), getattr(q, name))
            cases.append({"n": n, "t": t, "mask": mask.astype(int).tolist()})
        for t in [2., float(n)]:
            epsilon = 2e-5
            low = CentralPath(n, mask).solve(t * np.exp(-epsilon), full_projector=True)
            mid = CentralPath(n, mask).solve(t, full_projector=True)
            high = CentralPath(n, mask).solve(t * np.exp(epsilon), full_projector=True)
            z_prime = (2 - mid.h) * mid.z * (1 - mid.z) * (1 - 2 * mid.z) + 2 * sqrt(t) * mid.M3 / mid.h
            L_prime = mid.h * (mid.z - .5)
            diagonal = sqrt(t) * mid.P[:, 0]
            diagonal[0] = mid.d - .5
            Z = np.diag(diagonal)
            expected_P_prime = -(np.eye(n) - mid.P) @ Z @ mid.P - mid.P @ Z @ (np.eye(n) - mid.P)
            maxima["z_flow_finite_difference"] = max(maxima["z_flow_finite_difference"], abs((high.z - low.z) / (2 * epsilon) - z_prime))
            maxima["L_flow_finite_difference"] = max(maxima["L_flow_finite_difference"], abs((high.L - low.L) / (2 * epsilon) - L_prime))
            maxima["full_projector_flow_finite_difference"] = max(maxima["full_projector_flow_finite_difference"], float(np.max(abs((high.P - low.P) / (2 * epsilon) - expected_P_prime))))
    tolerance = 2e-5
    assert max(maxima.values()) < tolerance, maxima
    return {"passed": True, "tolerance": tolerance, "maximum_residuals": maxima, "cases": cases}


def monte_carlo(pairs: int) -> dict:
    rng = np.random.default_rng(2026091202)
    summaries, records = [], []
    for n in [31, 32, 63, 64, 127, 128, 255, 256, 511, 512]:
        values = []
        for sample in range(pairs):
            mask = rng.integers(0, 2, n // 2).astype(bool)
            a, b = theta_lp(n, mask), theta_lp(n, ~mask)
            value = (a.theta + b.theta) / (2 * sqrt(n))
            values.append(value)
            records.append({"n": n, "sample": sample, "edge_mask": mask.astype(int).tolist(),
                "theta": a.theta, "theta_complement": b.theta, "paired_ratio": value,
                "log_ratio": float(np.log(a.theta / sqrt(n))),
                "R4_primal_basic_optimizer": float(np.sum(a.f[1:] ** 4)),
                "R4_complement_basic_optimizer": float(np.sum(b.f[1:] ** 4)),
                "product_error": abs(a.theta * b.theta / n - 1)})
        summaries.append({"n": n, "independent_base_graphs": pairs,
            "paired_mean_theta_over_sqrt_n": float(np.mean(values)),
            "standard_error_of_paired_mean": float(np.std(values, ddof=1) / sqrt(pairs))})
        print(f"MC n={n}: paired mean {np.mean(values):.8f}", flush=True)
    return {"seed": 2026091202, "summaries": summaries, "records": records,
            "interpretation": "Each complement pair is one observation; the two graphs in a pair are not independent."}


def path_diagnostics(samples: int) -> dict:
    rng = np.random.default_rng(20260912)
    all_records, summaries = [], []
    for n in [31, 32, 63, 64, 127, 128, 255, 256]:
        values, maxima, bounds = [], [], []
        T = float(n * n)
        grid = np.unique(np.r_[np.geomspace(1, T, 45), float(n)])
        A = energy_weight_mass(n, T)
        for sample in range(samples):
            mask = rng.integers(0, 2, n // 2).astype(bool)
            path = CentralPath(n, mask)
            states = [path.solve(float(t)) for t in grid]
            h = np.array([x.h for x in states]); z = np.array([x.z for x in states])
            M3 = np.array([x.M3 for x in states]); kappa = np.array([x.kappa for x in states])
            weight_in_log_time = h ** 1.5 * np.sqrt(grid) / (2 - h)
            energy = float(np.trapezoid(weight_in_log_time * kappa ** 2, np.log(grid)) / A)
            I = float(np.trapezoid(weight_in_log_time * np.abs(kappa), np.log(grid)))
            D = states[0].z - .5
            bound = (n - 1) / (n + 1) * abs(np.arctanh(2 * D)) + I
            K = float(np.max(sqrt(n) * np.abs(M3) / h ** 1.5))
            values.append(energy); maxima.append(K); bounds.append(bound)
            all_records.append({"n": n, "sample": sample, "edge_mask": mask.astype(int).tolist(),
                "grid_energy": energy, "grid_K_max": K, "grid_abs_force_integral": I,
                "lyapunov_rhs_grid_quadrature": float(bound),
                "abs_L_T": abs(states[-1].L), "points": [x.record() for x in states]})
        summaries.append({"n": n, "independent_base_graphs": samples,
            "n_squared_mean_grid_energy": float(n * n * np.mean(values)),
            "mean_grid_K_max": float(np.mean(maxima)),
            "grid_size": len(grid)})
        print(f"Path n={n}: n^2 mean grid energy {n*n*np.mean(values):.8f}", flush=True)
    return {"seed": 20260912, "summaries": summaries, "records": all_records,
            "warning": "Numerical quadrature and discrete-grid maxima are not bounds for a continuum of t or for the ensemble."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--phase", choices=["all", "identities", "monte-carlo", "paths"], default="all",
                        help="Run all checks, or a single independently reproducible phase.")
    parser.add_argument("--pairs", type=int, default=64)
    parser.add_argument("--path-samples", type=int, default=8)
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parents[1] / "results")
    args = parser.parse_args()
    if args.pairs < 2 or args.path_samples < 1:
        parser.error("--pairs must be >=2 and --path-samples must be >=1")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    jobs = [("identities", "numerical_identities.json", identity_checks),
            ("monte-carlo", "monte_carlo.json", lambda: monte_carlo(args.pairs)),
            ("paths", "central_path_diagnostics.json", lambda: path_diagnostics(args.path_samples))]
    for phase, name, job in jobs:
        if args.phase not in ("all", phase):
            continue
        result = job()
        result["environment"] = {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__}
        (args.output_dir / name).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        print(f"Wrote {name}", flush=True)


if __name__ == "__main__":
    main()
