#!/usr/bin/env python3
"""Exact integer/rational checks for the MD-02 continuation.

No numerical optimizer is used here.  This validates finite instances and
identities; the accompanying manuscript supplies the all-n proofs.
Usage: python code/exact_checks.py --output results/exact_checks.json
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
from itertools import product
import json
from math import comb
from pathlib import Path
from typing import Any

F = Fraction


def choose(n: int, k: int) -> int:
    return comb(n, k) if n >= k >= 0 else 0


def inversion_weights(n: int) -> dict[int, int]:
    if not isinstance(n, int) or n < 2:
        raise ValueError("n must be an integer at least 2")
    return {s: (1 if 2 * s == n else 2) for s in range(1, n // 2 + 1)}


def variance_formula(n: int) -> Fraction:
    """Return the exact E[M_3(1)^2], including the even-order singleton."""
    inversion_weights(n)
    m = n - 1
    alpha = F(m + 2, m * m)
    d3 = int(n % 3 == 0)
    if n % 2:
        k = m // 2
        a = F(-8 * (m - 4), m * m)
        count = F(m * (m - 4) + 4 * d3, 12)
        if count.denominator != 1:
            raise ArithmeticError("Invalid odd cubic count")
        b = -48 * alpha
        numerator = (k * a * a + d3 * (16 - 8 * a)
                     + count * (144 + 24 * b) + choose(k, 3) * b * b)
    else:
        k = (n - 2) // 2
        d4 = int(n % 4 == 0)
        count_h = F(k - d4, 2)
        count = F((n - 2) * (n - 4) + 4 * d3, 12)
        if count_h.denominator != 1 or count.denominator != 1:
            raise ArithmeticError("Invalid even cubic count")
        count_0 = count - count_h
        n_even = (k - d4) // 2
        a = 6 - alpha * (12 * m - 22)
        a_h = 6 * d4 + 3 - alpha * (6 * m - 5)
        numerator = n_even * (a + 12) ** 2 + (k - n_even) * a ** 2 + a_h ** 2
        numerator += d3 * (16 - 8 * (a + 12))
        b_0, b_h = -48 * alpha, -24 * alpha
        numerator += count_0 * (144 + 24 * b_0) + choose(k, 3) * b_0 ** 2
        numerator += count_h * (144 + 24 * b_h) + choose(k, 2) * b_h ** 2
    return numerator / (64 * n ** 4)


def variance_by_walsh_counting(n: int) -> tuple[Fraction, Counter]:
    """Independently enumerate ordered residue triples and Walsh coefficients.

    Complexity is O(n^2); no graph masks are enumerated.  Cubic terms absent
    from T are accounted for via the complete B^3 expansion.
    """
    weights = inversion_weights(n)
    triples: Counter = Counter()
    for s in range(1, n):
        for t in range(1, n):
            v = (-s - t) % n
            if v == 0:
                continue
            classes = Counter((min(s, n - s), min(t, n - t), min(v, n - v)))
            monomial = tuple(sorted(c for c, multiplicity in classes.items() if multiplicity % 2))
            triples[monomial] += 1
    m = n - 1
    alpha = F(m + 2, m * m)
    V = sum(w * w for w in weights.values())
    pairs = sum(w == 2 for w in weights.values())
    b_0, b_h = -48 * alpha, -24 * alpha
    squared_coefficients = choose(pairs, 3) * b_0 ** 2
    if n % 2 == 0:
        squared_coefficients += choose(pairs, 2) * b_h ** 2
    for monomial, coefficient in triples.items():
        if len(monomial) == 3:
            base = -6 * alpha
            for c in monomial:
                base *= weights[c]
            squared_coefficients += (coefficient + base) ** 2 - base ** 2
    for c, w in weights.items():
        linear = triples[(c,)] + 3 * w - alpha * (3 * V * w - 2 * w ** 3)
        squared_coefficients += linear ** 2
    return squared_coefficients / (64 * n ** 4), triples


def initial_from_signs(eta: list[int]) -> tuple[Fraction, int, int]:
    """Exact M_3(1) from an even sign mask, eta[0]=0."""
    n = len(eta)
    inversion_weights(n)
    if eta[0] != 0 or any(x not in (-1, 1) for x in eta[1:]):
        raise ValueError("eta[0] must be 0 and other entries must be signs")
    if any(eta[s] != eta[-s % n] for s in range(n)):
        raise ValueError("eta must be inversion symmetric")
    B = sum(eta)
    T = sum(eta[s] * eta[t] * eta[(-s - t) % n]
            for s in range(1, n) for t in range(1, n))
    m = n - 1
    M3 = F(T + 3 * B, 8 * n * n) - F((m + 2) * B ** 3, 8 * n * n * m * m)
    return M3, B, T


def variance_by_masks(n: int) -> dict[str, Any]:
    weights = inversion_weights(n)
    total = F(0)
    total_square = F(0)
    B_square = 0
    for signs in product((-1, 1), repeat=len(weights)):
        eta = [0] * n
        for s, sign in zip(weights, signs):
            eta[s] = eta[-s % n] = sign
        M3, B, _ = initial_from_signs(eta)
        total += M3
        total_square += M3 ** 2
        B_square += B ** 2
    count = 2 ** len(weights)
    mean, variance = total / count, total_square / count
    expected_B_square = sum(w * w for w in weights.values())
    assert mean == 0
    assert variance == variance_formula(n)
    assert F(B_square, count) == expected_B_square
    return {"n": n, "masks": count, "mean_M3": str(mean),
            "variance_M3": str(variance),
            "variance_D": str(F(expected_B_square, 4 * (n - 1) ** 2))}


def obstruction_17() -> dict[str, Any]:
    n = 17
    allowed = {1, 2, 3, 8}
    eta = [0] + [1 if min(s, n - s) in allowed else -1 for s in range(1, n)]
    M3, B, T = initial_from_signs(eta)
    C = [sum(eta[s] * eta[(v - s) % n] for s in range(n)) for v in range(n)]
    U = sum(eta[v] * C[v] ** 2 for v in range(1, n))
    M3_prime = F(3 * U, 16 * n ** 3)
    L_third = F(3 * U, 8 * n ** 3)
    assert (B, T, M3, U) == (0, 0, 0, 128)
    assert M3_prime == F(24, 4913)
    assert L_third == F(48, 4913)
    return {"n": n, "edge_class_representatives": [4, 5, 6, 7],
            "nonedge_class_representatives": sorted(allowed), "eta": eta,
            "convolution_C": C, "B": B, "T": T, "U": U,
            "M3_at_1": str(M3), "D": "0",
            "M3_log_time_derivative_at_1": str(M3_prime),
            "L_third_log_time_derivative_at_1": str(L_third),
            "coefficient_of_log_time_cubed_in_L": str(L_third / 6)}


def run_checks() -> dict[str, Any]:
    orders = list(range(2, 81)) + [97, 127, 128, 255, 256, 511, 512, 1000]
    walsh_rows = []
    for n in orders:
        exact, coefficients = variance_by_walsh_counting(n)
        assert exact == variance_formula(n), n
        assert all(c == 12 for monomial, c in coefficients.items() if len(monomial) == 3), n
        walsh_rows.append({"n": n, "variance": str(exact),
                           "n_squared_variance": float(n * n * exact)})
    masks = [variance_by_masks(n) for n in range(2, 19)]
    largest = (F(0), 0)
    for n in range(2, 10001):
        scaled = n * n * variance_formula(n)
        assert 0 <= scaled <= F(3, 16), n
        if scaled > largest[0]:
            largest = scaled, n
    return {
        "all_passed": True,
        "scope": "Exact finite validation, not a proof of the MD-02 expectation limit.",
        "independent_walsh_orders": orders,
        "walsh_count_results": walsh_rows,
        "complete_mask_enumerations": masks,
        "sharp_bound_finite_check": {"orders": "2 through 10000 inclusive",
            "upper_bound": "3/16", "largest_checked_value": str(largest[0]),
            "largest_checked_order": largest[1]},
        "obstruction_17": obstruction_17(),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path,
                        default=Path(__file__).resolve().parents[1] / "results" / "exact_checks.json")
    args = parser.parse_args()
    result = run_checks()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"all_passed": True, "walsh_orders_checked": len(result["independent_walsh_orders"]),
                      "mask_enumeration_orders": 17, "output": str(args.output)}, indent=2))


if __name__ == "__main__":
    main()
