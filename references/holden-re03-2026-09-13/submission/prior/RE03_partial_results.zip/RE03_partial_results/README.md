# RE-03: partial research result

**This package is not a complete solution of RE-03.** It contains a proposed
stronger lower bound, a complete written argument for that lower bound, and a
matching characterization in a restricted accuracy regime. The missing
all-parameter upper bound is explicitly identified in the manuscript.

The proof has not been independently reviewed or formally verified. Numerical
checks are included as sanity checks, not as proof certificates.

## Main result developed in the manuscript

For n = 2^L k, k >= 1, L >= 2, and 0 < epsilon < 1/2, the manuscript argues that

    q_*(n,k,epsilon) >= c min{n, k(L+1) + k/epsilon^2},

where c > 0 is a universal constant. The proof covers arbitrary measurable,
randomized adaptive algorithms with exact real-valued queries to both A and
A-transpose. It does not assume finite precision or nonadaptivity.

Combining the lower bound with the exact n-query algorithm gives

    q_*(n,k,epsilon) = Theta(n) when epsilon <= sqrt(k/n).

A further corollary rules out a uniform upper bound of the form
O(min{n, k L^a / epsilon^p}) for any fixed a >= 0 and 0 <= p < 2. Thus,
within this argument, polynomial factors in depth cannot absorb an accuracy
exponent strictly below two.

The conservative explicit constants in the proof are very small; this is a
uniform asymptotic statement, not a practical claim that a large fixed
fraction of n queries is necessary for moderate test sizes.

Outside that regime the manuscript does not close the gap to the cited upper
bound O(min{n, k L^4 / epsilon^3}). It does not assert that its lower-bound
expression is the final optimal complexity.

## Files

- `manuscript/re03_partial_results.pdf`: 13-page mathematical research note.
- `manuscript/re03_partial_results.tex`: editable LaTeX source.
- `code/hodlr.py`: query-counted n-query baseline, optimal blockwise HODLR
  projection, block enumeration, and hard-distribution constructions.
- `code/verify.py`: executable identity, construction, and constant checks.
- `results/verification.json`: machine-readable results, numerical errors,
  random seed, and software versions from the recorded run.
- `results/verification.txt`: test summary.
- `SOURCES.md`: primary source inventory and scope of attribution.
- `PROOF_REVIEW.md`: guide to the critical proof steps and their verification status.
- `requirements.txt`: pinned numerical dependency used for the recorded run.
- `SHA256SUMS.txt`: integrity hashes of the package contents, excluding itself.

No third-party papers or font files are redistributed.

## Run the verification suite

The recorded run used Python 3.13.5 and NumPy 2.3.5. From the package root:

```sh
python -m pip install -r requirements.txt
python code/verify.py --output results/verification.json
```

The run checks 1500 local loss inequalities, 100 graph-projector identities,
12 fixed-query Gaussian KL identities, nine partition/baseline cases, and four
finite hard-instance examples. Important proof constants are also checked
with exact rational arithmetic. Floating-point logarithm spot checks supplement,
but do not replace, the analytic inequalities in the packing proof.

The exact Gaussian KL identity checks are for fixed query matrices. A separate
Monte Carlo check exercises one specified adaptive policy in four configurations
(6000 sampled matrices and 24000 fresh queries). Neither test establishes the
adaptive information lemma for arbitrary policies; its proof is in Section 3
of the manuscript.
The examples use continuously sampled projectors rather than constructing the
exponentially large finite packing used in the proof.

The baseline is mathematically exact in the problem's exact-real model. Its
NumPy implementation is a floating-point numerical reference and uses
scale-aware tolerances. It is not a new sublinear-query algorithm.

## Rebuild the PDF

With a LaTeX installation providing the packages in the source:

```sh
cd manuscript
pdflatex -interaction=nonstopmode -halt-on-error re03_partial_results.tex
pdflatex -interaction=nonstopmode -halt-on-error re03_partial_results.tex
```

A further pass may be needed if the table of contents changes pagination.

## Original problem

RE-03, “Optimal matvec query complexity of HODLR approximation”:

https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/RE-03

The linked public website and its cited public papers were used for the problem
statement and comparison bounds. No connected GitHub account data is involved.
