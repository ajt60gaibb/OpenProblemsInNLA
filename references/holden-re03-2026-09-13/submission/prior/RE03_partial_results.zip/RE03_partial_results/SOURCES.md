# Primary sources and attribution

## Problem specification

**OpenProblemsInNLA, RE-03: Optimal matvec query complexity of HODLR approximation.**
The repository's statement includes the exact-real measurable-computation
model, the 0.99 fixed-input guarantee, the requested joint dependence on rank,
depth, and accuracy, and an audit dated September 10, 2026.

Public page:
https://github.com/ajt60gaibb/OpenProblemsInNLA/tree/main/randomized-and-low-rank-approximation/RE-03

Raw website text:
https://raw.githubusercontent.com/ajt60gaibb/OpenProblemsInNLA/main/randomized-and-low-rank-approximation/RE-03/README.md

Used for: the definition of the problem addressed by the manuscript, its
quantifiers, and the stated comparison bounds. The repository's open status
is not used as a mathematical premise of any theorem.

## Main published comparison

**Tyler Chen, Feyza Duman Keles, Diana Halikias, Cameron Musco, Christopher Musco,
and David Persson. Near-optimal hierarchical matrix approximation from
matrix-vector products.** SODA 2025, pages 2656–2692. ArXiv:2407.04686v2,
October 24, 2024.

HTML: https://arxiv.org/html/2407.04686v2

PDF: https://arxiv.org/pdf/2407.04686v2

Relevant locations: Definition 1.1, Problem 1.1, Theorems 1.1–1.2, Section 6,
and Section 8. These supply the comparison upper bound and earlier lower
bound, including the dimension restriction in the latter's accuracy term.
The exact-recovery linear-family obstruction is also discussed there.

## Attribution of the research claim in this package

The shifted-GOE / small-block projector-packing lower-bound argument in this
package is developed in the accompanying manuscript. It is not attributed to
the sources above. It is an unreviewed proposed result; this package does not
claim that its novelty has been established by an exhaustive literature search.
Its proof is self-contained, including the finite packing and entropy bound.

## Additional primary literature checked for context

These sources are not premises for the lower-bound theorem in the manuscript
and are not substitutes for a matching upper bound for RE-03.

- Noah Amsel et al., **Query Efficient Structured Matrix Learning**,
  arXiv:2507.19290v2, August 21, 2026.
  https://arxiv.org/html/2507.19290v2
- Christopher Musco and Indu Ramesh, **Nearly Instance Optimal Sparse Matrix
  Approximation from Matrix-Vector Products**, arXiv:2606.12179v1, June 10, 2026.
  https://arxiv.org/html/2606.12179v1
- **Quasi-optimal hierarchically semi-separable matrix approximation**,
  arXiv:2505.16937v2.
  https://arxiv.org/html/2505.16937v2

This is a bounded source check, not a certification that no other relevant
result exists. Third-party source files are not included in this ZIP.
