"""Reproducible numerical and exact-arithmetic sanity checks for the note.

Run from the package root: python code/verify.py --output results/verification.json
These tests do not formally verify the packing, adaptive KL argument, or Fano
reduction. Those are mathematical proofs in the manuscript.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path
import platform
import numpy as np
from numpy.linalg import norm, qr, svd

from hodlr import (DenseOracle, depth, hard_instance, is_hodlr, n_query_baseline,
                   off_diagonal_blocks, optimum_squared, project_hodlr,
                   random_projector, goe)

SEED = 6032026


def local_loss_checks(rng: np.random.Generator) -> dict:
    margins: list[float] = []
    for k in [1, 2, 3, 5, 8]:
        for delta in [1e-4, .005, .05, .2, .5]:
            for noise in [0, 1e-7, 1e-3, .02, .2, 1.]:
                for _ in range(10):
                    p = random_projector(2*k, k, rng)
                    q = random_projector(2*k, k, rng)
                    c = (1-delta)*np.eye(2*k) + 2*delta*p
                    w = rng.standard_normal(c.shape) * noise
                    a = c+w
                    b = a@q  # Best approximation with this prescribed row space.
                    s = svd(a, compute_uv=False)
                    excess = norm(a-b, "fro")**2 - float(s[k:]@s[k:])
                    lower = (delta*norm(p-q, "fro")**2
                             - ((1+delta)**2/delta+1)*norm(w, "fro")**2)
                    margin = float(excess-lower)
                    assert margin >= -1e-9*max(1, abs(excess), abs(lower))
                    margins.append(margin)
    return {"cases": len(margins), "minimum_margin": min(margins), "passed": True}


def graph_projector_checks(rng: np.random.Generator) -> dict:
    errors = []
    for k in [1, 2, 3, 5, 8]:
        for _ in range(20):
            t, u = rng.standard_normal((2, k, k))
            t *= .5/max(norm(t, 2), 1e-15)
            u *= .5/max(norm(u, 2), 1e-15)
            xt = np.vstack((np.eye(k), t))
            xu = np.vstack((np.eye(k), u))
            vt, vu = qr(xt, mode="reduced")[0], qr(xu, mode="reduced")[0]
            pt, pu = vt@vt.T, vu@vu.T
            lhs = .5*norm(pt-pu, "fro")**2
            def inv_sqrt(x: np.ndarray) -> np.ndarray:
                ev, evec = np.linalg.eigh(x)
                return (evec*(1/np.sqrt(ev)))@evec.T
            rhs = norm(inv_sqrt(np.eye(k)+t@t.T) @ (u-t)
                       @ inv_sqrt(np.eye(k)+u.T@u), "fro")**2
            assert np.isclose(lhs, rhs, rtol=1e-10, atol=1e-11)
            assert 2*lhs >= (2/(1.25**2))*norm(t-u, "fro")**2 - 1e-10
            errors.append(float(abs(lhs-rhs)))
    return {"cases": len(errors), "maximum_identity_error": max(errors), "passed": True}


def fixed_query_kl_checks(rng: np.random.Generator) -> dict:
    errors = []
    for n in [4, 5, 8, 12]:
        for q in [1, 2, 3]:
            if q >= n:
                continue
            v = qr(rng.standard_normal((n, q)), mode="reduced")[0]
            z = rng.standard_normal((n, n))
            s = (z+z.T)/2
            s /= norm(s, 2)
            response_basis = []
            for i in range(n):
                e = np.zeros((n, n))
                e[i, i] = np.sqrt(2/n)
                response_basis.append((e@v).ravel())
                for j in range(i):
                    e = np.zeros((n, n))
                    e[i, j] = e[j, i] = 1/np.sqrt(n)
                    response_basis.append((e@v).ravel())
            design = np.stack(response_basis, axis=1)
            covariance = design@design.T
            mean = (s@v).ravel()  # delta = 1; KL scales quadratically in delta.
            direct = .5*mean@np.linalg.pinv(covariance)@mean
            r = np.eye(n)-v@v.T
            formula = n/4*(norm(s, "fro")**2-norm(r@s@r, "fro")**2)
            assert np.isclose(direct, formula, rtol=1e-9, atol=1e-9)
            assert direct <= n*q/2+1e-9
            errors.append(float(abs(direct-formula)))
    return {"cases": len(errors), "maximum_kl_formula_error": max(errors), "passed": True,
            "scope": "Nonadaptive fixed-query Gaussian covariance checks only."}


def baseline_and_partition_checks(rng: np.random.Generator) -> dict:
    records = []
    for k in [1, 2, 3]:
        for level in [2, 3, 4]:
            n = k*2**level
            assert depth(n, k) == level
            mask = np.zeros((n, n), dtype=int)
            linear_dimension = 0
            for rows, cols in off_diagonal_blocks(n, k):
                mask[rows, cols] += 1
                linear_dimension += (rows.stop-rows.start)*k
            for lo in range(0, n, k):
                mask[lo:lo+k, lo:lo+k] += 1
                linear_dimension += k*k
            assert np.all(mask == 1)
            assert linear_dimension == n*k*(level+1)
            a = rng.standard_normal((n, n))
            oracle = DenseOracle(a)
            b = n_query_baseline(oracle, k)
            opt2 = optimum_squared(a, k)
            actual2 = norm(a-b, "fro")**2
            assert oracle.queries == n and is_hodlr(b, k)
            assert np.isclose(actual2, opt2, rtol=1e-10, atol=1e-9)
            oracle_exact = DenseOracle(b)
            b2 = n_query_baseline(oracle_exact, k)
            assert np.allclose(b, b2, rtol=1e-10, atol=1e-10)
            records.append({"n": n, "k": k, "L": level, "queries": oracle.queries,
                            "optimum_squared": opt2,
                            "absolute_objective_error": float(abs(actual2-opt2))})
    return {"cases": len(records), "passed": True, "records": records}


def hard_instance_checks(rng: np.random.Generator) -> dict:
    records = []
    for n, k, delta in [(16, 1, .05), (32, 2, .2), (64, 2, .1), (96, 3, .5)]:
        a, a0, g, projectors = hard_instance(n, k, delta, rng)
        clean = a-g
        s = (clean-a0)/delta
        assert np.allclose(s@s, np.eye(n), rtol=1e-10, atol=1e-10)
        clean_opt = optimum_squared(clean, k)
        expected_clean_opt = n*(1-delta)**2/2
        assert np.isclose(clean_opt, expected_clean_opt, rtol=1e-10, atol=1e-10)
        b = project_hodlr(a, k)
        total_excess = norm(a-b, "fro")**2-optimum_squared(a, k)
        radius2, local_excess, t_noise = 0.0, 0.0, 0.0
        for j, p in enumerate(projectors):
            lo = 4*k*j
            rows, cols = slice(lo, lo+2*k), slice(lo+2*k, lo+4*k)
            block, estimate = a[rows, cols], b[rows, cols]
            _, _, vt = svd(estimate, full_matrices=False)
            q = vt[:k, :].T@vt[:k, :]
            ss = svd(block, compute_uv=False)
            local_excess += norm(block-estimate, "fro")**2-float(ss[k:]@ss[k:])
            radius2 += norm(p-q, "fro")**2
            t_noise += norm(g[rows, cols], "fro")**2
        coefficient = ((1+delta)**2/delta+1)
        assert local_excess <= total_excess+1e-8
        assert delta*radius2 <= local_excess+coefficient*t_noise+1e-8
        records.append({"n": n, "k": k, "delta": delta,
                        "clean_optimum_squared": clean_opt,
                        "projector_distance_squared": float(radius2),
                        "target_noise_squared": float(t_noise)})
    return {"cases": len(records), "passed": True, "records": records,
            "scope": "Finite examples; not asymptotic lower-bound experiments."}


def adaptive_exposure_checks(rng: np.random.Generator) -> dict:
    """Monte Carlo checks for one Lanczos-type adaptive policy, not a proof."""
    records = []
    draws = 1500
    query_count = 4
    for n in [8, 12]:
        basis = qr(rng.standard_normal((n, n)))[0]
        signs = np.where(np.arange(n) % 2, -1.0, 1.0)
        shift = (basis*signs)@basis.T
        for delta in [.1, .7]:
            likelihoods, drifts, innovations = [], [], []
            for _ in range(draws):
                a = delta*shift + goe(n, rng)
                previous = np.zeros((n, 0))
                v = np.eye(n)[:, 0]
                log_likelihood = 0.0
                predictable_drift = 0.0
                for step in range(query_count):
                    projection = np.eye(n)-previous@previous.T
                    v = projection@v
                    v /= norm(v)
                    y = projection@(a@v)
                    u = projection@(shift@v)
                    # Inverse covariance on the fresh space is n*(I-vv^T/2).
                    mean = delta*u
                    inv_y = n*(y-.5*v*(v@y))
                    inv_mean = n*(mean-.5*v*(v@mean))
                    log_likelihood += float(mean@inv_y-.5*mean@inv_mean)
                    predictable_drift += float(.5*mean@inv_mean)
                    innovations.append(float(np.sqrt(n/2)*(v@(y-mean))))
                    previous = np.column_stack((previous, v))
                    if step+1 < query_count:
                        v = a@v  # New query depends on the preceding answer.
                likelihoods.append(log_likelihood)
                drifts.append(predictable_drift)
            likelihoods = np.asarray(likelihoods)
            drifts = np.asarray(drifts)
            innovations = np.asarray(innovations)
            centered = likelihoods-drifts
            standard_error = float(np.std(centered, ddof=1)/np.sqrt(draws))
            assert abs(np.mean(centered)) <= 6*standard_error+1e-10
            assert np.max(drifts) <= n*delta**2*query_count/2+1e-9
            assert abs(np.mean(innovations)) < .065
            assert abs(np.mean(innovations**2)-1) < .11
            records.append({"n": n, "delta": delta, "queries_per_draw": query_count,
                            "draws": draws, "mean_log_likelihood_ratio": float(np.mean(likelihoods)),
                            "mean_predictable_drift": float(np.mean(drifts)),
                            "martingale_mean": float(np.mean(centered)),
                            "martingale_standard_error": standard_error,
                            "normalized_innovation_mean": float(np.mean(innovations)),
                            "normalized_innovation_second_moment": float(np.mean(innovations**2))})
    return {"configurations": len(records), "matrices_sampled": len(records)*draws,
            "fresh_query_exposures": len(records)*draws*query_count, "passed": True,
            "records": records,
            "scope": "Monte Carlo sanity check for one specified adaptive policy only; not a proof of the adaptive KL lemma."}


def exact_constant_checks() -> dict:
    d = 2**24
    radius = Fraction(105, 2*d)+Fraction(30, d*d)
    assert radius < Fraction(1, 102400) < Fraction(1, 25600)
    eps0 = Fraction(1, 2*d)
    c0 = Fraction(1, 6400*d*d)
    assert c0/(eps0*eps0) == Fraction(1, 1600)
    assert Fraction(31, 40)-Fraction(1, 100) == Fraction(153, 200)
    assert Fraction(1, 1)-2*Fraction(1, 16) == Fraction(7, 8)
    # Fano's required log(N) >= 16 log(2) follows from nk >= 4 D^2.
    assert 4*d*d/800 > 16*np.log(2)
    for k in range(4, 100):
        h = -.25*np.log(.25)-.75*np.log(.75)
        assert (np.log(2)-h)*k*k-np.log(2) >= k*k/20
    for alphabet in range(2, 1000):
        h = -.25*np.log(.25)-.75*np.log(.75)
        assert np.log(alphabet)-h-.25*np.log(alphabet-1) >= .1*np.log(alphabet)
    return {"D": d, "epsilon_0_exact": str(eps0), "c0_exact": str(c0),
            "combined_lower_constant_exact": str(c0/2),
            "decoder_radius_bound_exact": str(radius),
            "decoder_radius_bound": float(radius),
            "decoding_threshold": 1/25600, "passed": True,
            "scope": "Rational constants are exact; logarithm spot checks use floating point."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("results/verification.json"))
    args = parser.parse_args()
    rng = np.random.default_rng(SEED)
    report = {"seed": SEED, "python": platform.python_version(),
              "numpy": np.__version__, "formal_proof_verification": False,
              "local_loss_lemma": local_loss_checks(rng),
              "graph_projector_identity": graph_projector_checks(rng),
              "fixed_query_KL": fixed_query_kl_checks(rng),
              "baseline_and_partition": baseline_and_partition_checks(rng),
              "hard_instance_reduction": hard_instance_checks(rng),
              "constants": exact_constant_checks(),
              "adaptive_exposure": adaptive_exposure_checks(rng), "all_checks_passed": True}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2)+"\n", encoding="utf-8")
    print("All checks passed.")
    print("1500 local loss inequalities; 100 graph-projector identities;")
    print("12 fixed-query Gaussian KL identities; 9 baseline/partition cases;")
    print("4 hard-instance cases; exact proof-constant checks;")
    print("4 adaptive-exposure configurations (6000 matrices, 24000 fresh queries).")
    print("Numerical checks are not a formal or independent verification of the proof.")
    print(f"Report: {args.output}")


if __name__ == "__main__":
    main()
