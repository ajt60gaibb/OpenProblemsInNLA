# Proof review guide

The manuscript states a proposed theorem and gives its proof. It does not have
an independent review or a formal proof-assistant certificate. The following
map identifies the claims that need mathematical scrutiny, separately from
what the code actually checks.

## 1. Exact-recovery obstruction — Proposition 2.3

The linear family has n k (L+1) free coordinates on disjoint supports. Gaussian
conditioning, rather than an informal count of real-valued transcript entries,
shows that fewer than k(L+1) adaptive queries leave a non-atomic posterior.
The code verifies the partition and the dimension count for nine finite cases.
It does not certify the Gaussian-conditioning argument for all policies.

## 2. Adaptive shifted-GOE information — Lemma 3.1

The key conditional assertion is that the unexplored compression remains a
centered GOE under every fixed shift, even when the query subspace was chosen
adaptively. The proof proceeds by successive orthogonal exposure. At a common
history, the fresh response mean differs by delta (I-Pi) S v, and its covariance
is ((I-Pi) + vv^T)/n on the fresh space. Already exposed response components
are identical functions of the common history under both experiments.

The seed is included in the transcript; transpose queries coincide with forward
queries on the symmetric hard distribution. Exact normalization of arbitrary
query vectors does not discard information. Each fresh query contributes at
most n delta^2 / 2 to KL divergence.

The tests form the full response covariance and check the fixed-query formula
in Appendix A in 12 cases. That test is a normalization check, not an adaptive
lower-bound proof. A separate Monte Carlo test uses one specified adaptive
Lanczos-type policy across 6000 matrices. It checks the Gaussian innovations
and the conditional likelihood-ratio drift, not the universal mathematical
claim over all adaptive policies.

## 3. Approximation excess to subspace loss — Lemma 4.1

The output block need not be symmetric. Extend its row space to a rank-k
projector Q. The clean squared-error difference is exactly
2 delta ||P-Q||_F^2. Bounding its cross term by Young's inequality gives the
stated perturbation penalty. The test suite checks 1500 instances, including
zero noise, small gaps, and large perturbations.

## 4. Finite packing — Lemma 5.1

The proof uses bounded-norm sign matrices, graph subspaces, and a product
Hamming code. Both the entropy and the separation constants are established
analytically, including the cases k = 1, 2, 3 and M = 1. The code checks 100
instances of the graph-projector identity and spot-checks scalar constants.
It does not enumerate the asymptotic packing.

## 5. Hard family and Fano reduction — Section 6

The rank-constrained targets are off-diagonal 2k-by-2k sibling blocks in
4k-by-4k nodes. GOE noise is sampled once as part of A, not afresh at each query.
Its full Frobenius energy and target-block energy are controlled by a single
good event of probability at least 31/40.

Global approximation success bounds the sum of nonnegative target-block
excesses. With delta = 2^24 epsilon and n >= k/epsilon^2, that bound implies
correct nearest-neighbor decoding with probability at least 153/200.
The information bound contradicts that success probability when the query
budget is at most k/(6400 delta^2). The proof never assumes a separate relative
error guarantee on each block.

## 6. All-parameter extension — Section 7

Accuracy monotonicity transfers the core bound to the full-recovery regime.
The exact-recovery obstruction covers the remaining constant-sized parameter
ranges. Combining lower bounds uses a maximum; the sum appears only after a
factor-of-two loss and the cap at n is retained.

## What is still missing

There is no algorithm or theorem in this package proving an upper bound of
O(min{n, kL + k/epsilon^2}) for arbitrary inputs. There is also no theorem here
establishing a larger matching joint depth–accuracy lower bound. The proposed
lower bound and the cited upper bound therefore do not constitute a complete
solution of RE-03 outside the regime proved in Corollary 1.2.
